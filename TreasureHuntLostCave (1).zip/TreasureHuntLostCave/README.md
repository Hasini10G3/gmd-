# Treasure Hunt: Lost Cave

A 3D endless runner for Unity (Android + PC). An explorer races through an ancient underground cave —
crystal caverns, temple ruins, underground rivers, abandoned mine tunnels and treasure chambers —
dodging traps and collecting lost treasure.

## Open and play (Unity Hub)

1. Install **Unity 2022.3 LTS** with Unity Hub (any 2022.3.x works; Unity 6 should also work — see Known limitations in BUILD_REPORT.md).
   For Android also tick **Android Build Support** (+ OpenJDK and Android SDK & NDK Tools).
2. Unzip. In Unity Hub: **Projects → Add → Add project from disk** → select the `TreasureHuntLostCave` folder.
   If Hub says the editor version is missing, pick your installed 2022.3 version and confirm.
3. Open the project. On the first open the Editor automatically runs **Treasure Hunt → Build Complete Game**
   (progress bar for ~10–40 s). It generates materials, textures, meshes, all prefabs, saves `Assets/Scenes/LostCave.unity`,
   sets it as the startup scene and opens it.
4. Press **Play**.

If anything looks off, run **Treasure Hunt → Build Complete Game** from the menu bar again.
The game does not depend on the generated assets to run — the `LostCave` scene contains one `GameBootstrap`
object that creates every system, the explorer, the cave and the UI from code — so pressing Play works even before generation.

## Controls

| Action | PC | Android |
|---|---|---|
| Move left / right | A / D or ← / → | Swipe left / right |
| Jump | Space, W or ↑ | Swipe up |
| Slide (in the air: fast-fall) | S or ↓ | Swipe down |
| Pause | Esc | Pause button (top-right) / Back |

In the Editor you can also swipe with the mouse (click-drag).

## Editor menu: Treasure Hunt

| Item | What it does |
|---|---|
| Build Complete Game | Regenerates everything and validates (writes `ValidationReport.txt`) |
| Open Game Scene | Opens `Assets/Scenes/LostCave.unity` |
| Validate Project | Static checks only |
| Run Play Mode Smoke Test | Enters Play Mode and drives ~45 automated gameplay checks → `SmokeTestResults.txt` |
| Build Android APK | Builds `Builds/Android/TreasureHuntLostCave.apk` (needs Android Build Support) |

Command line (replace the Unity path):

```
Unity -batchmode -quit -projectPath TreasureHuntLostCave -executeMethod TreasureHunt.EditorTools.TreasureHuntBuilder.BuildFromCommandLine
Unity -batchmode -projectPath TreasureHuntLostCave -executeMethod TreasureHunt.EditorTools.TreasureHuntBuilder.BuildAndroidFromCommandLine
Unity -batchmode -projectPath TreasureHuntLostCave -executeMethod TreasureHunt.EditorTools.TreasureHuntBuilder.RunSmokeTestFromCommandLine
```

## Tuning

* `Assets/Scripts/Utilities/GameConfig.cs` — speeds, jump height, slide time, row spacing, power-up durations, magnet radius.
* Revive cost: select **GameBootstrap** in the scene → `Revive Gem Cost` (default 20, doubles per revive in the same run).
* Obstacle mix per biome: `TrackGenerator.Sets`.

## Importing into an existing project (`TreasureHuntLostCave.unitypackage`)

Requirements: built-in render pipeline, **Active Input Handling = Input Manager (Old) or Both**, uGUI package (`com.unity.ugui`).
After import, run **Treasure Hunt → Build Complete Game**. The first-open auto-generation also runs once in the new project;
it adds `LostCave` as build scene 0 but only changes Player Settings (name/package id/orientation) if the product name is still
the default one. URP/HDRP projects: materials use the Standard shader and will render pink unless converted.

## Project layout

```
Assets/
  Scenes/LostCave.unity            startup scene (GameBootstrap)
  Scripts/
    Player/ (PlayerController, PlayerAnimator, PlayerFactory, InputHandler)
    GameManager/ (GameManager, GameBootstrap)
    Camera/ (CameraFollow)
    Environment/ (EnvironmentFactory, EnvironmentAnimator)
    TrackGeneration/ (TrackGenerator, TrackSegment)
    Obstacles/ (Obstacle, ObstacleBehaviours, ObstacleFactory)
    Collectibles/ (Collectible, CollectibleFactory, CollectibleManager)
    PowerUps/ (PowerUpManager, PowerUpVisuals)
    UI/ (UIManager, UIBuilder)
    Audio/ (AudioManager)
    SaveSystem/ (SaveSystem)
    Utilities/ (GameConfig, Util, ObjectPool, MeshFactory, MaterialLibrary, FXManager, SmokeTestRunner)
  Editor/TreasureHuntBuilder.cs    automation, validation, smoke-test & APK commands
  Prefabs/ Materials/ Models/ Textures/   filled by the generator
  Audio/ Settings/
```
