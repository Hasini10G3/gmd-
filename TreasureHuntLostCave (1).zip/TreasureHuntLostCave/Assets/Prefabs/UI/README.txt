The UI is built from code by UIManager/UIBuilder; no UI prefabs are required.
