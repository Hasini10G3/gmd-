using System.Collections.Generic;
using System.IO;
using System.Text;
using TreasureHunt;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TreasureHunt.EditorTools
{
    /// <summary>Runs the full generator once, automatically, the first time the project is opened.</summary>
    [InitializeOnLoad]
    public static class TreasureHuntAutoSetup
    {
        static TreasureHuntAutoSetup()
        {
            EditorApplication.delayCall += () =>
            {
                if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
                if (File.Exists(TreasureHuntBuilder.MarkerPath)) return;
                Debug.Log("[Treasure Hunt] First open detected - generating the complete game...");
                TreasureHuntBuilder.BuildCompleteGame(false);
            };
        }
    }

    /// <summary>
    /// Editor automation: Treasure Hunt > Build Complete Game.
    /// Creates folders, exports procedural textures/materials/meshes, saves prefabs for every
    /// player/obstacle/collectible/power-up/environment piece, creates and saves the LostCave scene,
    /// configures build settings and validates the result.
    /// </summary>
    public static class TreasureHuntBuilder
    {
        public const string ScenePath = "Assets/Scenes/LostCave.unity";
        public const string MarkerPath = "Assets/Settings/TreasureHuntGenerated.txt";
        const string MatFolder = "Assets/Materials/Resources/TH";
        const string TexFolder = "Assets/Textures/Generated";
        const string MeshFolder = "Assets/Models/Generated";
        const string ApkPath = "Builds/Android/TreasureHuntLostCave.apk";
        static int meshCounter;

        [MenuItem("Treasure Hunt/Build Complete Game", priority = 0)]
        public static void BuildMenu()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            BuildCompleteGame(true);
        }

        [MenuItem("Treasure Hunt/Open Game Scene", priority = 1)]
        public static void OpenScene()
        {
            if (!File.Exists(ScenePath)) BuildCompleteGame(false);
            if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) EditorSceneManager.OpenScene(ScenePath);
        }

        [MenuItem("Treasure Hunt/Validate Project", priority = 20)]
        public static void ValidateMenu()
        {
            var log = new StringBuilder();
            bool ok = Validate(log);
            WriteReport(log);
            EditorUtility.DisplayDialog("Treasure Hunt validation", (ok ? "All checks passed.\n\n" : "Some checks FAILED.\n\n") + log, "OK");
        }

        [MenuItem("Treasure Hunt/Run Play Mode Smoke Test", priority = 21)]
        public static void RunSmokeTest()
        {
            if (!File.Exists(ScenePath)) BuildCompleteGame(false);
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            EditorSceneManager.OpenScene(ScenePath);
            PlayerPrefs.SetInt(SmokeTestRunner.PrefKey, 1);
            PlayerPrefs.Save();
            EditorApplication.isPlaying = true;
        }

        [MenuItem("Treasure Hunt/Build Android APK", priority = 40)]
        public static void BuildAndroidMenu()
        {
            bool ok = BuildAndroid();
            EditorUtility.DisplayDialog("Treasure Hunt", ok ? "APK built:\n" + Path.GetFullPath(ApkPath) : "APK build failed - see Console. Android Build Support must be installed via Unity Hub.", "OK");
        }

        // -------------------------------------------------------------- batch-mode entry points
        /// <summary>Unity -batchmode -quit -projectPath . -executeMethod TreasureHunt.EditorTools.TreasureHuntBuilder.BuildFromCommandLine</summary>
        public static void BuildFromCommandLine()
        {
            bool ok = BuildCompleteGame(false);
            EditorApplication.Exit(ok ? 0 : 1);
        }

        /// <summary>Unity -batchmode -projectPath . -executeMethod TreasureHunt.EditorTools.TreasureHuntBuilder.BuildAndroidFromCommandLine</summary>
        public static void BuildAndroidFromCommandLine()
        {
            bool ok = BuildCompleteGame(false) && BuildAndroid();
            EditorApplication.Exit(ok ? 0 : 1);
        }

        /// <summary>Unity -batchmode -projectPath . -executeMethod TreasureHunt.EditorTools.TreasureHuntBuilder.RunSmokeTestFromCommandLine (no -quit)</summary>
        public static void RunSmokeTestFromCommandLine()
        {
            BuildCompleteGame(false);
            string results = Path.Combine(Path.GetDirectoryName(Application.dataPath), SmokeTestRunner.ResultFile);
            if (File.Exists(results)) File.Delete(results);
            EditorSceneManager.OpenScene(ScenePath);
            PlayerPrefs.SetInt(SmokeTestRunner.PrefKey, 1);
            PlayerPrefs.Save();
            double deadline = EditorApplication.timeSinceStartup + 240.0;
            EditorApplication.update += () =>
            {
                if (SmokeTestRunner.Finished || EditorApplication.timeSinceStartup > deadline)
                {
                    bool ok = SmokeTestRunner.Finished && SmokeTestRunner.AllPassed;
                    EditorApplication.Exit(ok ? 0 : 1);
                }
            };
            EditorApplication.EnterPlaymode();
        }

        // -------------------------------------------------------------- main generator
        public static bool BuildCompleteGame(bool interactive)
        {
            var log = new StringBuilder();
            log.AppendLine("Treasure Hunt: Lost Cave - generation report (" + System.DateTime.Now + ")");
            bool ok;
            try
            {
                EditorUtility.DisplayProgressBar("Treasure Hunt", "Creating folders", 0.05f);
                CreateFolders(log);
                EditorUtility.DisplayProgressBar("Treasure Hunt", "Materials & textures", 0.15f);
                ExportMaterials(log);
                CleanGeneratedMeshes();
                EditorUtility.DisplayProgressBar("Treasure Hunt", "Prefabs (player, obstacles, collectibles, power-ups)", 0.35f);
                ExportPrefabs(log);
                EditorUtility.DisplayProgressBar("Treasure Hunt", "Cave environment segments", 0.6f);
                ExportEnvironment(log);
                EditorUtility.DisplayProgressBar("Treasure Hunt", "Scene & project settings", 0.85f);
                CreateScene(log);
                ConfigureProject(log);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                ok = Validate(log);
                File.WriteAllText(MarkerPath, log.ToString());
                AssetDatabase.ImportAsset(MarkerPath);
                WriteReport(log);
            }
            catch (System.Exception e)
            {
                log.AppendLine("ERROR: " + e);
                Debug.LogError("[Treasure Hunt] Generation failed: " + e);
                ok = false;
            }
            finally
            {
                MaterialLibrary.EditorLoader = null;
                EditorUtility.ClearProgressBar();
            }
            Debug.Log(log.ToString());
            if (!Application.isBatchMode && File.Exists(ScenePath) && !EditorApplication.isPlayingOrWillChangePlaymode)
                EditorSceneManager.OpenScene(ScenePath);
            if (interactive)
                EditorUtility.DisplayDialog("Treasure Hunt: Lost Cave", ok ? "Game generated.\n\nThe LostCave scene is open - press Play." : "Generation finished with problems - see Console.", "OK");
            return ok;
        }

        static void CreateFolders(StringBuilder log)
        {
            string[] folders =
            {
                "Assets/Scenes", "Assets/Scripts", "Assets/Prefabs/Player", "Assets/Prefabs/Obstacles", "Assets/Prefabs/Collectibles",
                "Assets/Prefabs/Environment", "Assets/Prefabs/UI", MatFolder, MeshFolder, TexFolder, "Assets/Audio", "Assets/Settings", "Assets/Editor"
            };
            foreach (var f in folders) Directory.CreateDirectory(f);
            AssetDatabase.Refresh();
            log.AppendLine("Folders ok");
        }

        static void ExportMaterials(StringBuilder log)
        {
            MaterialLibrary.EditorLoader = null;
            MaterialLibrary.ClearCache();
            int created = 0;
            foreach (var key in Mat.All)
            {
                string path = MatFolder + "/" + key + ".mat";
                if (AssetDatabase.LoadAssetAtPath<Material>(path) != null) continue;
                var m = MaterialLibrary.CreateFresh(key);
                var tex = m.mainTexture as Texture2D;
                if (tex != null && !EditorUtility.IsPersistent(tex))
                {
                    string tp = TexFolder + "/" + tex.name + ".asset";
                    var existing = AssetDatabase.LoadAssetAtPath<Texture2D>(tp);
                    if (existing == null) AssetDatabase.CreateAsset(tex, tp); else m.mainTexture = existing;
                }
                AssetDatabase.CreateAsset(m, path);
                created++;
            }
            AssetDatabase.SaveAssets();
            MaterialLibrary.ClearCache();
            MaterialLibrary.EditorLoader = k => AssetDatabase.LoadAssetAtPath<Material>(MatFolder + "/" + k + ".mat");
            log.AppendLine("Materials: " + Mat.All.Length + " (" + created + " newly created) in " + MatFolder);
        }

        static void CleanGeneratedMeshes()
        {
            // Generated meshes are rebuilt every run; remove old ones so they don't pile up.
            var scene = SceneManager.GetActiveScene();
            if (scene.path == ScenePath) EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            foreach (var guid in AssetDatabase.FindAssets("t:Mesh", new[] { MeshFolder }))
                AssetDatabase.DeleteAsset(AssetDatabase.GUIDToAssetPath(guid));
        }

        static void ExportPrefabs(StringBuilder log)
        {
            int n = 0;
            SavePrefab(PlayerFactory.Create(), "Assets/Prefabs/Player/Explorer.prefab"); n++;
            foreach (ObstacleKind k in System.Enum.GetValues(typeof(ObstacleKind)))
            {
                SavePrefab(ObstacleFactory.Create(k).gameObject, "Assets/Prefabs/Obstacles/" + k + ".prefab"); n++;
            }
            foreach (CollectibleType t in System.Enum.GetValues(typeof(CollectibleType)))
            {
                if (t == CollectibleType.PowerUp) continue;
                SavePrefab(CollectibleFactory.Create(t, 0), "Assets/Prefabs/Collectibles/" + t + ".prefab"); n++;
            }
            foreach (PowerUpType p in System.Enum.GetValues(typeof(PowerUpType)))
            {
                SavePrefab(CollectibleFactory.Create(CollectibleType.PowerUp, p), "Assets/Prefabs/Collectibles/PowerUp_" + p + ".prefab"); n++;
            }
            log.AppendLine("Prefabs (player/obstacles/collectibles/power-ups): " + n);
        }

        static void ExportEnvironment(StringBuilder log)
        {
            int n = 0;
            var state = Random.state;
            Random.InitState(12345);
            foreach (Biome b in System.Enum.GetValues(typeof(Biome)))
                for (int v = 0; v < 3; v++)
                {
                    var seg = EnvironmentFactory.BuildSegment(b, v);
                    SavePrefab(seg.gameObject, "Assets/Prefabs/Environment/Segment_" + b + "_" + v + ".prefab");
                    n++;
                }
            Random.state = state;
            log.AppendLine("Environment segment prefabs (5 biomes x 3 variants): " + n);
        }

        static void SavePrefab(GameObject go, string path)
        {
            foreach (var mf in go.GetComponentsInChildren<MeshFilter>(true)) PersistMesh(mf.sharedMesh);
            foreach (var pr in go.GetComponentsInChildren<ParticleSystemRenderer>(true)) if (pr.mesh != null) PersistMesh(pr.mesh);
            foreach (var r in go.GetComponentsInChildren<Renderer>(true))
            {
                var mats = r.sharedMaterials;
                for (int i = 0; i < mats.Length; i++)
                    if (mats[i] != null && !EditorUtility.IsPersistent(mats[i]))
                        AssetDatabase.CreateAsset(mats[i], "Assets/Materials/Generated_" + mats[i].name + "_" + (meshCounter++) + ".mat");
            }
            PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }

        static void PersistMesh(Mesh m)
        {
            if (m == null || EditorUtility.IsPersistent(m)) return;
            string name = m.name.Replace(" ", "_").Replace("/", "_");
            AssetDatabase.CreateAsset(m, MeshFolder + "/" + name + "_" + (meshCounter++) + ".asset");
        }

        static void CreateScene(StringBuilder log)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var boot = new GameObject("GameBootstrap");
            boot.AddComponent<GameBootstrap>();
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = EnvironmentAnimator.FogFor(Biome.CrystalCave);
            RenderSettings.fogStartDistance = 22f;
            RenderSettings.fogEndDistance = 125f;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = EnvironmentAnimator.AmbientFor(Biome.CrystalCave);
            RenderSettings.skybox = null;
            // Static preview of the cave so the Scene view isn't empty. Tagged EditorOnly (stripped from builds)
            // and hidden by GameBootstrap when Play starts.
            var preview = new GameObject(GameBootstrap.EditorPreviewName);
            preview.tag = "EditorOnly";
            for (int i = 0; i < 3; i++)
            {
                var seg = EnvironmentFactory.BuildSegment((Biome)i, i == 0 ? 0 : 1);
                seg.transform.SetParent(preview.transform, false);
                seg.transform.position = new Vector3(0, 0, i * GameConfig.SegmentLength);
                foreach (var mf in seg.GetComponentsInChildren<MeshFilter>(true)) PersistMesh(mf.sharedMesh);
            }
            var player = PlayerFactory.Create();
            Object.DestroyImmediate(player.GetComponent<PlayerController>());
            Object.DestroyImmediate(player.GetComponent<PowerUpVisuals>());
            player.transform.SetParent(preview.transform, false);
            foreach (var mf in player.GetComponentsInChildren<MeshFilter>(true)) PersistMesh(mf.sharedMesh);
            preview.SetActive(true);
            EditorSceneManager.SaveScene(scene, ScenePath);
            log.AppendLine("Scene saved: " + ScenePath);
        }

        static void ConfigureProject(StringBuilder log)
        {
            var scenes = new List<EditorBuildSettingsScene>();
            scenes.Add(new EditorBuildSettingsScene(ScenePath, true));
            foreach (var s in EditorBuildSettings.scenes) if (s.path != ScenePath) scenes.Add(s);
            EditorBuildSettings.scenes = scenes.ToArray();
            log.AppendLine("Build settings: LostCave is scene 0 (startup scene)");

            if (PlayerSettings.productName == "TreasureHuntLostCave" || PlayerSettings.productName == "New Unity Project" || PlayerSettings.productName == "Treasure Hunt: Lost Cave")
            {
                PlayerSettings.productName = "Treasure Hunt: Lost Cave";
                PlayerSettings.companyName = "SRU Game Lab";
                PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.srugamelab.treasurehunt.lostcave");
                PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
                PlayerSettings.allowedAutorotateToPortrait = true;
                PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
                PlayerSettings.allowedAutorotateToLandscapeLeft = true;
                PlayerSettings.allowedAutorotateToLandscapeRight = true;
                log.AppendLine("Player settings: product name, Android package id, auto-rotation");
            }
            AddAlwaysIncludedShader("Standard", log);
            AddAlwaysIncludedShader("Legacy Shaders/Particles/Additive", log);
        }

        static void AddAlwaysIncludedShader(string name, StringBuilder log)
        {
            var shader = Shader.Find(name);
            if (shader == null) return;
            var assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");
            if (assets == null || assets.Length == 0) return;
            var so = new SerializedObject(assets[0]);
            var arr = so.FindProperty("m_AlwaysIncludedShaders");
            if (arr == null) return;
            for (int i = 0; i < arr.arraySize; i++)
                if (arr.GetArrayElementAtIndex(i).objectReferenceValue == shader) return;
            arr.InsertArrayElementAtIndex(arr.arraySize);
            arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = shader;
            so.ApplyModifiedProperties();
            log.AppendLine("Always-included shader: " + name);
        }

        // -------------------------------------------------------------- validation
        static bool Validate(StringBuilder log)
        {
            bool ok = true;
            log.AppendLine();
            log.AppendLine("VALIDATION (static checks, Edit Mode):");
            System.Action<string, bool> check = (n, c) => { log.AppendLine((c ? "  PASS  " : "  FAIL  ") + n); ok &= c; };
            check("Scene exists at " + ScenePath, File.Exists(ScenePath));
            bool inBuild = false;
            foreach (var s in EditorBuildSettings.scenes) if (s.path == ScenePath && s.enabled) inBuild = true;
            check("Scene is in Build Settings", inBuild);
            check("Scene is the startup scene (index 0)", EditorBuildSettings.scenes.Length > 0 && EditorBuildSettings.scenes[0].path == ScenePath);
            int matCount = 0;
            foreach (var k in Mat.All)
            {
                var m = AssetDatabase.LoadAssetAtPath<Material>(MatFolder + "/" + k + ".mat");
                if (m != null && m.shader != null && m.shader.isSupported) matCount++;
            }
            check("All " + Mat.All.Length + " materials exported with a supported shader (" + matCount + ")", matCount == Mat.All.Length);
            check("Explorer prefab", AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Player/Explorer.prefab") != null);
            int obs = 0;
            foreach (ObstacleKind k in System.Enum.GetValues(typeof(ObstacleKind)))
            {
                var p = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Obstacles/" + k + ".prefab");
                if (p == null) continue;
                var o = p.GetComponent<Obstacle>();
                if (o != null && o.hitBox != null && o.hitBox.isTrigger) obs++;
            }
            check("12 obstacle prefabs with trigger colliders (" + obs + ")", obs == 12);
            int env = AssetDatabase.FindAssets("t:Prefab", new[] { "Assets/Prefabs/Environment" }).Length;
            check("15 environment segment prefabs (" + env + ")", env >= 15);
            int col = AssetDatabase.FindAssets("t:Prefab", new[] { "Assets/Prefabs/Collectibles" }).Length;
            check("13 collectible + power-up prefabs (" + col + ")", col >= 13);
            check("Physics: default gravity untouched / kinematic player", AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Player/Explorer.prefab") != null
                && AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Player/Explorer.prefab").GetComponent<Rigidbody>().isKinematic);
            log.AppendLine(ok ? "VALIDATION RESULT: PASS" : "VALIDATION RESULT: FAIL");
            return ok;
        }

        static void WriteReport(StringBuilder log)
        {
            try { File.WriteAllText(Path.Combine(Path.GetDirectoryName(Application.dataPath), "ValidationReport.txt"), log.ToString()); }
            catch (System.Exception) { }
        }

        // -------------------------------------------------------------- Android
        static bool BuildAndroid()
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogError("[Treasure Hunt] Android Build Support is not installed. Add it in Unity Hub > Installs > (version) > Add modules.");
                return false;
            }
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            EditorUserBuildSettings.buildAppBundle = false;
            Directory.CreateDirectory(Path.GetDirectoryName(ApkPath));
            var options = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = ApkPath,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            bool ok = report.summary.result == BuildResult.Succeeded;
            Debug.Log("[Treasure Hunt] Android build " + report.summary.result + " -> " + Path.GetFullPath(ApkPath));
            return ok;
        }
    }
}
