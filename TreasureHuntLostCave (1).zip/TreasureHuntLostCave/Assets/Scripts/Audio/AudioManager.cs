using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// All sound is synthesised at start-up, so the game never depends on audio files.
    /// Optional override: drop clips into any Resources/Audio folder with the same names (e.g. "coin") and they are used instead.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        const int Rate = 22050;
        AudioSource[] sfx;
        int sfxIndex;
        AudioSource ambience, water;
        float dripTimer = 2f, waterTarget = 0.05f, waterfallBoost;

        public AudioClip coin, crystal, chest, key, jump, slide, rockFall, collision, powerUp, gameOver, footstep, drip,
            ambienceLoop, waterLoop, click, shieldBreak, beep, swoosh, rumble;

        void Awake()
        {
            Instance = this;
            sfx = new AudioSource[8];
            for (int i = 0; i < sfx.Length; i++) { sfx[i] = gameObject.AddComponent<AudioSource>(); sfx[i].playOnAwake = false; }
            ambience = gameObject.AddComponent<AudioSource>();
            water = gameObject.AddComponent<AudioSource>();
            Generate();
            ambience.clip = ambienceLoop; ambience.loop = true; ambience.volume = 0.55f; ambience.Play();
            water.clip = waterLoop; water.loop = true; water.volume = 0.05f; water.Play();
            ApplySoundSetting();
        }

        public void ApplySoundSetting() { AudioListener.volume = SaveSystem.SoundOn ? 1f : 0f; }

        public void ToggleSound()
        {
            SaveSystem.SoundOn = !SaveSystem.SoundOn;
            SaveSystem.Save();
            ApplySoundSetting();
            Play(click);
        }

        public void Play(AudioClip c, float volume = 1f, float pitch = 1f)
        {
            if (c == null) return;
            var s = sfx[sfxIndex];
            sfxIndex = (sfxIndex + 1) % sfx.Length;
            s.pitch = pitch;
            s.PlayOneShot(c, volume);
        }

        public void PlayVaried(AudioClip c, float volume = 1f) { Play(c, volume, Random.Range(0.9f, 1.1f)); }

        /// <summary>0..1 how close the player is to running water (set by the environment animator).</summary>
        public void SetWaterProximity(float v, bool waterfall) { waterTarget = Mathf.Lerp(0.04f, 0.5f, v); waterfallBoost = waterfall ? 0.2f : 0f; }

        void Update()
        {
            water.volume = Mathf.MoveTowards(water.volume, Mathf.Clamp01(waterTarget + waterfallBoost), Time.unscaledDeltaTime * 0.5f);
            var gm = GameManager.Instance;
            if (gm != null && gm.State == GameState.Paused) return;
            dripTimer -= Time.deltaTime;
            if (dripTimer <= 0f)
            {
                dripTimer = Random.Range(1.5f, 5f);
                Play(drip, Random.Range(0.15f, 0.35f), Random.Range(0.8f, 1.25f));
            }
        }

        // ---------------------------------------------------------------- synthesis
        void Generate()
        {
            coin = Load("coin") ?? Make("coin", 0.18f, t => Sine(t < 0.06f ? 1318f : 1760f, t) * Mathf.Exp(-t * 16f) * 0.45f);
            crystal = Load("crystal") ?? Echo(Make("crystal", 0.7f, t => (Sine(1568f, t) + 0.6f * Sine(2349f, t) + 0.4f * Sine(3136f, t)) * Mathf.Exp(-t * 6f) * 0.28f), 0.11f, 0.3f);
            key = Load("key") ?? Make("key", 0.5f, t => (Sine(t < 0.12f ? 988f : 1480f, t) + 0.5f * Sine(2960f, t)) * Mathf.Exp(-t * 7f) * 0.35f);
            chest = Load("chest") ?? Make("chest", 1.0f, t =>
            {
                float s = 0f;
                float[] notes = { 523f, 659f, 784f, 1046f };
                for (int i = 0; i < 4; i++) { float st = i * 0.1f; if (t >= st) s += Sine(notes[i], t - st) * Mathf.Exp(-(t - st) * 4f); }
                return s * 0.22f + Noise() * Mathf.Exp(-t * 30f) * 0.25f;
            });
            jump = Load("jump") ?? Make("jump", 0.2f, t => Sweep(260f, 640f, 0.2f, t) * Env(t, 0.2f) * 0.35f);
            swoosh = Load("swoosh") ?? LowPass(Make("swoosh", 0.16f, t => Noise() * Env(t, 0.16f) * 0.3f), 0.25f);
            slide = Load("slide") ?? LowPass(Make("slide", 0.35f, t => Noise() * Env(t, 0.35f) * 0.45f), 0.15f);
            rockFall = Load("rockfall") ?? LowPass(Make("rockfall", 0.9f, t => (Noise() * 0.8f + Sine(55f, t)) * Mathf.Exp(-t * 4f) * 0.7f), 0.06f);
            rumble = Load("rumble") ?? LowPass(Make("rumble", 1.2f, t => (Noise() + Sine(40f, t)) * Env(t, 1.2f) * 0.6f), 0.04f);
            collision = Load("collision") ?? LowPass(Make("collision", 0.5f, t => (Noise() + Sine(80f, t) * 1.5f) * Mathf.Exp(-t * 9f) * 0.7f), 0.2f);
            powerUp = Load("powerup") ?? Make("powerup", 0.55f, t =>
            {
                float[] n = { 523f, 659f, 784f, 1046f, 1318f };
                int i = Mathf.Min(4, (int)(t / 0.09f));
                return Square(n[i], t) * 0.18f * Env(t, 0.55f);
            });
            gameOver = Load("gameover") ?? Make("gameover", 1.3f, t =>
            {
                float[] n = { 392f, 330f, 262f, 196f };
                int i = Mathf.Min(3, (int)(t / 0.25f));
                return Tri(n[i], t) * 0.35f * Env(t, 1.3f);
            });
            footstep = Load("footstep") ?? Echo(LowPass(Make("footstep", 0.3f, t => t < 0.08f ? (Noise() * 0.6f + Sine(90f, t)) * Mathf.Exp(-t * 40f) * 0.6f : 0f), 0.12f), 0.09f, 0.35f);
            drip = Load("drip") ?? Echo(Make("drip", 0.6f, t => t < 0.15f ? Sweep(1500f, 700f, 0.15f, t) * Mathf.Exp(-t * 25f) * 0.5f : 0f), 0.13f, 0.45f);
            click = Load("click") ?? Make("click", 0.06f, t => Sine(1200f, t) * Mathf.Exp(-t * 60f) * 0.4f);
            beep = Load("beep") ?? Make("beep", 0.18f, t => Sine(880f, t) * Env(t, 0.18f) * 0.35f);
            shieldBreak = Load("shieldbreak") ?? Make("shieldbreak", 0.6f, t => (Noise() * 0.5f * Mathf.Exp(-t * 12f) + (Sine(2093f, t) + Sine(2637f, t)) * 0.3f * Mathf.Exp(-t * 5f)) * 0.45f);
            ambienceLoop = Load("ambience") ?? LoopFade(LowPass(Make("ambience", 6f, t =>
                Brown() * 0.6f + (Sine(55f, t) * 0.25f + Sine(82.4f, t) * 0.15f) * (0.6f + 0.4f * Mathf.Sin(t * 2f * Mathf.PI / 6f))), 0.05f), 0.6f);
            waterLoop = Load("water") ?? LoopFade(LowPass(Make("water", 4f, t => Noise() * 0.5f), 0.3f), 0.5f);
        }

        static AudioClip Load(string name) { return Resources.Load<AudioClip>("Audio/" + name); }

        static float brown;
        static float Noise() { return Random.value * 2f - 1f; }
        static float Brown() { brown = Mathf.Clamp(brown + Noise() * 0.08f, -1f, 1f); return brown; }
        static float Sine(float f, float t) { return Mathf.Sin(2f * Mathf.PI * f * t); }
        static float Square(float f, float t) { return Mathf.Sign(Mathf.Sin(2f * Mathf.PI * f * t)) * 0.6f + Mathf.Sin(2f * Mathf.PI * f * t) * 0.4f; }
        static float Tri(float f, float t) { float p = t * f - Mathf.Floor(t * f); return 4f * Mathf.Abs(p - 0.5f) - 1f; }
        static float Sweep(float f0, float f1, float d, float t) { return Mathf.Sin(2f * Mathf.PI * (f0 * t + (f1 - f0) * t * t / (2f * d))); }
        static float Env(float t, float d) { float a = Mathf.Clamp01(t / 0.01f); float r = Mathf.Clamp01((d - t) / (d * 0.6f)); return a * r; }

        static AudioClip Make(string name, float dur, System.Func<float, float> f)
        {
            int n = Mathf.Max(1, (int)(dur * Rate));
            var data = new float[n];
            for (int i = 0; i < n; i++) data[i] = Mathf.Clamp(f(i / (float)Rate), -1f, 1f);
            var clip = AudioClip.Create("TH_" + name, n, 1, Rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        static float[] Data(AudioClip c) { var d = new float[c.samples]; c.GetData(d, 0); return d; }

        static AudioClip LowPass(AudioClip c, float a)
        {
            var d = Data(c); float y = 0f;
            for (int i = 0; i < d.Length; i++) { y += a * (d[i] - y); d[i] = y; }
            Normalize(d, 0.8f);
            c.SetData(d, 0); return c;
        }

        static AudioClip Echo(AudioClip c, float delay, float feedback)
        {
            var d = Data(c); int k = (int)(delay * Rate);
            for (int i = k; i < d.Length; i++) d[i] += d[i - k] * feedback;
            Normalize(d, 0.8f);
            c.SetData(d, 0); return c;
        }

        static AudioClip LoopFade(AudioClip c, float fade)
        {
            var d = Data(c); int k = Mathf.Min(d.Length / 2, (int)(fade * Rate));
            for (int i = 0; i < k; i++)
            {
                float w = i / (float)k;
                d[i] = d[i] * w + d[d.Length - k + i] * (1f - w);
            }
            var outData = new float[d.Length - k];
            System.Array.Copy(d, outData, outData.Length);
            var clip = AudioClip.Create(c.name, outData.Length, 1, Rate, false);
            clip.SetData(outData, 0);
            return clip;
        }

        static void Normalize(float[] d, float peak)
        {
            float m = 0.0001f;
            for (int i = 0; i < d.Length; i++) m = Mathf.Max(m, Mathf.Abs(d[i]));
            float s = peak / m;
            for (int i = 0; i < d.Length; i++) d[i] *= s;
        }
    }
}
