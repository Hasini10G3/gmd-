using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Third-person runner camera: smooth lane follow, partial jump follow, speed FOV, shake, menu orbit.</summary>
    public class CameraFollow : MonoBehaviour
    {
        public static CameraFollow Instance { get; private set; }

        public Transform target;
        public float height = 4.2f, distance = 7.4f, lookAhead = 7f, lateralFollow = 0.75f, baseFov = 62f;

        Camera cam;
        float camX, camXVel, shakeTime, shakeDuration, shakeMag, transition = 1f;
        Vector3 transFromPos;
        Quaternion transFromRot;

        void Awake()
        {
            Instance = this;
            cam = GetComponent<Camera>();
        }

        public void BeginTransition()
        {
            transFromPos = transform.position;
            transFromRot = transform.rotation;
            transition = 0f;
        }

        public void Snap()
        {
            transition = 1f;
            if (target != null) { camX = target.position.x * lateralFollow; camXVel = 0f; }
            LateUpdate();
        }

        public void Shake(float magnitude, float duration)
        {
            if (!SaveSystem.ShakeOn) return;
            if (magnitude < shakeMag * (shakeTime / Mathf.Max(0.01f, shakeDuration))) return;
            shakeMag = magnitude; shakeTime = duration; shakeDuration = duration;
        }

        void LateUpdate()
        {
            if (target == null) return;
            var gm = GameManager.Instance;
            float dt = Time.unscaledDeltaTime;
            Vector3 tp = target.position;
            Vector3 pos; Quaternion rot;

            if (gm != null && gm.State == GameState.Menu)
            {
                float t = Time.unscaledTime;
                float ang = 28f * Mathf.Sin(t * 0.18f);
                Quaternion orbit = Quaternion.Euler(0f, ang, 0f);
                pos = tp + orbit * new Vector3(0f, 3.4f, -6.2f);
                rot = Quaternion.LookRotation((tp + new Vector3(0f, 1.6f, 6f)) - pos, Vector3.up);
                camX = tp.x * lateralFollow;
            }
            else
            {
                if (Time.timeScale > 0f) camX = Mathf.SmoothDamp(camX, tp.x * lateralFollow, ref camXVel, 0.12f, Mathf.Infinity, dt);
                float y = height + Mathf.Max(tp.y, -2f) * 0.35f;
                pos = new Vector3(camX, y, tp.z - distance);
                Vector3 look = new Vector3(camX * 0.9f + (tp.x - camX) * 0.3f, 1.2f + Mathf.Max(tp.y, -1f) * 0.5f, tp.z + lookAhead);
                if (gm != null && (gm.State == GameState.Dying || gm.State == GameState.GameOver) && tp.y < -1f)
                    look = new Vector3(tp.x, tp.y, tp.z + 2f);
                rot = Quaternion.LookRotation(look - pos, Vector3.up);
            }

            if (transition < 1f)
            {
                transition = Mathf.Min(1f, transition + dt / 0.9f);
                float s = transition * transition * (3f - 2f * transition);
                pos = Vector3.Lerp(transFromPos, pos, s);
                rot = Quaternion.Slerp(transFromRot, rot, s);
            }

            if (shakeTime > 0f)
            {
                shakeTime -= dt;
                float k = shakeMag * Mathf.Clamp01(shakeTime / Mathf.Max(0.01f, shakeDuration));
                pos += new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0f) * k;
            }

            transform.SetPositionAndRotation(pos, rot);

            if (cam != null)
            {
                float targetFov = baseFov;
                if (gm != null && gm.State == GameState.Playing)
                {
                    targetFov += (gm.CurrentSpeed - GameConfig.StartSpeed) * 0.3f;
                    if (PowerUpManager.Instance != null && PowerUpManager.Instance.IsActive(PowerUpType.SpeedBoost)) targetFov += 8f;
                }
                cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, Mathf.Min(targetFov, 82f), 1f - Mathf.Exp(-dt * 3f));
            }
        }
    }
}
