using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Persistent progress (PlayerPrefs). Coins/gems/keys are banked as soon as they are collected.</summary>
    public static class SaveSystem
    {
        const string KBest = "TH_BestScore", KCoins = "TH_Coins", KGems = "TH_Gems", KKeys = "TH_Keys",
            KSound = "TH_Sound", KShake = "TH_Shake", KRuns = "TH_Runs";

        public static int BestScore { get { return PlayerPrefs.GetInt(KBest, 0); } set { PlayerPrefs.SetInt(KBest, value); } }
        public static int Coins { get { return PlayerPrefs.GetInt(KCoins, 0); } set { PlayerPrefs.SetInt(KCoins, Mathf.Max(0, value)); } }
        public static int Gems { get { return PlayerPrefs.GetInt(KGems, 0); } set { PlayerPrefs.SetInt(KGems, Mathf.Max(0, value)); } }
        public static int Keys { get { return PlayerPrefs.GetInt(KKeys, 0); } set { PlayerPrefs.SetInt(KKeys, Mathf.Max(0, value)); } }
        public static int RunsPlayed { get { return PlayerPrefs.GetInt(KRuns, 0); } set { PlayerPrefs.SetInt(KRuns, value); } }
        public static bool SoundOn { get { return PlayerPrefs.GetInt(KSound, 1) == 1; } set { PlayerPrefs.SetInt(KSound, value ? 1 : 0); } }
        public static bool ShakeOn { get { return PlayerPrefs.GetInt(KShake, 1) == 1; } set { PlayerPrefs.SetInt(KShake, value ? 1 : 0); } }

        /// <summary>Returns true when the score is a new best.</summary>
        public static bool SubmitScore(int score)
        {
            bool best = score > BestScore;
            if (best) BestScore = score;
            Save();
            return best;
        }

        public static bool SpendGems(int amount)
        {
            if (Gems < amount) return false;
            Gems -= amount;
            Save();
            return true;
        }

        public static void ResetProgress()
        {
            PlayerPrefs.DeleteKey(KBest); PlayerPrefs.DeleteKey(KCoins); PlayerPrefs.DeleteKey(KGems);
            PlayerPrefs.DeleteKey(KKeys); PlayerPrefs.DeleteKey(KRuns);
            Save();
        }

        public static void Save() { PlayerPrefs.Save(); }
    }
}
