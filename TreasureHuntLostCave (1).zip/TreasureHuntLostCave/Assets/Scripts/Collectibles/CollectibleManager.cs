using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Animates all live collectibles in a single loop (no per-coin Update), runs the Coin Magnet,
    /// and applies the reward when the player touches a collectible.
    /// </summary>
    public class CollectibleManager : MonoBehaviour
    {
        public static CollectibleManager Instance { get; private set; }

        readonly List<Collectible> active = new List<Collectible>(256);
        public int ActiveCount { get { return active.Count; } }
        public int TotalCollected { get; private set; }

        void Awake() { Instance = this; }

        public void Register(Collectible c)
        {
            if (c.activeIndex >= 0 && c.activeIndex < active.Count && active[c.activeIndex] == c) return;
            c.activeIndex = active.Count;
            active.Add(c);
        }

        public void Unregister(Collectible c)
        {
            int i = c.activeIndex;
            if (i < 0 || i >= active.Count || active[i] != c) return;
            int last = active.Count - 1;
            active[i] = active[last];
            active[i].activeIndex = i;
            active.RemoveAt(last);
            c.activeIndex = -1;
        }

        void Update()
        {
            var pu = PowerUpManager.Instance;
            var gm = GameManager.Instance;
            var player = PlayerController.Instance;
            bool vision = pu != null && pu.IsActive(PowerUpType.AncientVision);
            bool magnet = pu != null && pu.IsActive(PowerUpType.CoinMagnet) && gm != null && gm.State == GameState.Playing && player != null;
            float t = Time.time;
            Vector3 target = magnet ? player.transform.position + Vector3.up * 0.9f : Vector3.zero;
            float r2 = GameConfig.MagnetRadius * GameConfig.MagnetRadius;
            float step = magnet ? (gm.CurrentSpeed + 22f) * Time.deltaTime : 0f;
            for (int i = active.Count - 1; i >= 0; i--)
            {
                var c = active[i];
                c.Animate(t, vision);
                if (!magnet || c.type != CollectibleType.Coin) continue;
                Vector3 p = c.transform.position;
                if (!c.magnetized)
                {
                    float dz = p.z - target.z;
                    if (dz > -1f && (p - target).sqrMagnitude < r2) c.magnetized = true;
                }
                if (c.magnetized) c.transform.position = Vector3.MoveTowards(p, target, step);
            }
        }

        public void Collect(Collectible c)
        {
            var gm = GameManager.Instance;
            var fx = FXManager.Instance;
            var au = AudioManager.Instance;
            if (gm == null || !c.IsCollectable) return;
            Vector3 pos = c.transform.position;
            TotalCollected++;
            switch (c.type)
            {
                case CollectibleType.Coin:
                    gm.AddCoins(1); gm.AddScore(10);
                    if (fx != null) fx.Sparkle(pos, new Color(1f, 0.85f, 0.3f), 6);
                    if (au != null) au.Play(au.coin, 0.6f, 1f + (gm.RunCoins % 5) * 0.03f);
                    break;
                case CollectibleType.BlueCrystal:
                    gm.AddGems(1); gm.AddScore(50);
                    if (fx != null) fx.Sparkle(pos, new Color(0.3f, 0.7f, 1f), 14);
                    if (au != null) au.Play(au.crystal, 0.7f);
                    break;
                case CollectibleType.PurpleGem:
                    gm.AddGems(2); gm.AddScore(100);
                    if (fx != null) fx.Sparkle(pos, new Color(0.8f, 0.4f, 1f), 16);
                    if (au != null) au.Play(au.crystal, 0.7f, 0.85f);
                    break;
                case CollectibleType.AncientKey:
                    gm.AddKeys(1); gm.AddScore(250);
                    if (fx != null) fx.Burst(pos, new Color(1f, 0.85f, 0.3f), 18);
                    if (au != null) au.Play(au.key, 0.8f);
                    gm.ShowToast("ANCIENT KEY FOUND", new Color(1f, 0.85f, 0.3f));
                    break;
                case CollectibleType.TreasureChest:
                    gm.AddCoins(25); gm.AddGems(3); gm.AddScore(500);
                    if (fx != null) { fx.Burst(pos, new Color(1f, 0.8f, 0.2f), 40); fx.Sparkle(pos, new Color(0.6f, 0.4f, 1f), 20); }
                    if (au != null) au.Play(au.chest, 0.9f);
                    gm.ShowToast("TREASURE CHEST!  +25 COINS  +3 GEMS", new Color(1f, 0.8f, 0.3f));
                    break;
                case CollectibleType.Artifact:
                    gm.AddGems(5); gm.AddScore(1000);
                    if (fx != null) fx.Burst(pos, new Color(0.3f, 1f, 0.6f), 30);
                    if (au != null) au.Play(au.chest, 0.8f, 1.2f);
                    gm.ShowToast("RARE ARTIFACT!  +1000", new Color(0.4f, 1f, 0.7f));
                    break;
                case CollectibleType.HiddenRelic:
                    gm.AddGems(10); gm.AddScore(2000);
                    if (fx != null) fx.Burst(pos, new Color(0.8f, 1f, 1f), 45);
                    if (au != null) au.Play(au.crystal, 1f, 0.7f);
                    gm.ShowToast("GLOWING ANCIENT RELIC!  +2000", new Color(0.7f, 1f, 1f));
                    break;
                case CollectibleType.PowerUp:
                    if (fx != null) fx.Burst(pos, GameConfig.PowerUpColor(c.powerUp), 30);
                    if (PowerUpManager.Instance != null) PowerUpManager.Instance.Activate(c.powerUp);
                    break;
            }
            if (c.pooled != null) c.pooled.pool.Release(c.pooled);
            else c.gameObject.SetActive(false);
        }
    }
}
