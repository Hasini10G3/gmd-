using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Coin / gem / key / chest / artifact / relic / power-up pickup. Animated centrally by CollectibleManager.</summary>
    public class Collectible : MonoBehaviour, IPoolable
    {
        public CollectibleType type;
        public PowerUpType powerUp;
        public Transform visual;
        public float spinSpeed = 180f;
        public float bobAmplitude = 0.12f;
        public bool hidden;          // only visible during Ancient Vision
        public bool highlightable;   // pulses during Ancient Vision
        public Renderer[] renderers;

        [System.NonSerialized] public int activeIndex = -1;
        [System.NonSerialized] public bool magnetized;
        [System.NonSerialized] public PooledItem pooled;
        float phase;
        bool shown = true;

        public static int PoolKey(CollectibleType t, PowerUpType p) { return (int)t * 10 + (t == CollectibleType.PowerUp ? (int)p : 0); }

        public bool IsCollectable { get { return pooled == null || pooled.inUse; } }

        public void OnSpawned()
        {
            if (pooled == null) pooled = GetComponent<PooledItem>();
            magnetized = false;
            phase = Random.value * 6.283f;
            visual.localScale = Vector3.one;
            shown = true;
            SetShown(!hidden);
            if (CollectibleManager.Instance != null) CollectibleManager.Instance.Register(this);
        }

        public void OnDespawned()
        {
            if (CollectibleManager.Instance != null) CollectibleManager.Instance.Unregister(this);
        }

        void SetShown(bool v)
        {
            if (shown == v) return;
            shown = v;
            for (int i = 0; i < renderers.Length; i++) renderers[i].enabled = v;
        }

        public void Animate(float t, bool vision)
        {
            visual.localRotation = Quaternion.Euler(0f, t * spinSpeed + phase * 57.3f, 0f);
            visual.localPosition = new Vector3(0f, Mathf.Sin(t * 3f + phase) * bobAmplitude, 0f);
            if (hidden) SetShown(vision);
            if (highlightable)
            {
                float s = vision ? 1.15f + 0.2f * Mathf.Sin(t * 8f + phase) : 1f;
                visual.localScale = new Vector3(s, s, s);
            }
        }
    }
}
