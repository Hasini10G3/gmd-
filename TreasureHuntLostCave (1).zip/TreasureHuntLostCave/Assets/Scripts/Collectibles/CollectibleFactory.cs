using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Builds treasure and power-up pickups from procedural geometry.</summary>
    public static class CollectibleFactory
    {
        static Material M(string k) { return MaterialLibrary.Get(k); }

        public static GameObject CreateFromKey(int key)
        {
            return Create((CollectibleType)(key / 10), (PowerUpType)(key % 10));
        }

        public static GameObject Create(CollectibleType type, PowerUpType pu)
        {
            string name = type == CollectibleType.PowerUp ? "PowerUp_" + pu : type.ToString();
            var go = new GameObject(name);
            var c = go.AddComponent<Collectible>();
            c.type = type;
            c.powerUp = pu;
            var col = go.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = 0.65f;
            var v = Util.Node("Visual", go.transform, Vector3.zero).transform;
            c.visual = v;
            switch (type)
            {
                case CollectibleType.Coin:
                    Util.Prim(PrimitiveType.Cylinder, v, Vector3.zero, new Vector3(0.62f, 0.05f, 0.62f), M(Mat.Gold), new Vector3(90, 0, 0));
                    Util.Prim(PrimitiveType.Cylinder, v, Vector3.zero, new Vector3(0.38f, 0.06f, 0.38f), M(Mat.GoldPile), new Vector3(90, 0, 0));
                    c.spinSpeed = 220f; c.bobAmplitude = 0.05f;
                    break;
                case CollectibleType.BlueCrystal:
                    Util.MeshObj(MeshFactory.Crystal(), v, new Vector3(0, -0.4f, 0), new Vector3(0.55f, 0.85f, 0.55f), M(Mat.CrystalBlue), Vector3.zero);
                    c.spinSpeed = 120f;
                    break;
                case CollectibleType.PurpleGem:
                    Util.MeshObj(MeshFactory.Gem(), v, Vector3.zero, Vector3.one * 0.75f, M(Mat.CrystalPurple), Vector3.zero);
                    c.spinSpeed = 150f;
                    break;
                case CollectibleType.AncientKey:
                    Util.Prim(PrimitiveType.Cylinder, v, new Vector3(0, 0.3f, 0), new Vector3(0.38f, 0.04f, 0.38f), M(Mat.Gold), new Vector3(90, 0, 0));
                    Util.Prim(PrimitiveType.Cylinder, v, new Vector3(0, 0.3f, 0), new Vector3(0.2f, 0.05f, 0.2f), M(Mat.CrystalTeal), new Vector3(90, 0, 0));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.15f, 0), new Vector3(0.08f, 0.6f, 0.06f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0.1f, -0.38f, 0), new Vector3(0.14f, 0.07f, 0.06f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0.08f, -0.24f, 0), new Vector3(0.1f, 0.06f, 0.06f), M(Mat.Gold));
                    c.spinSpeed = 140f; c.highlightable = true;
                    break;
                case CollectibleType.TreasureChest:
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.2f, 0), new Vector3(1.2f, 0.7f, 0.8f), M(Mat.ChestWood));
                    Util.Prim(PrimitiveType.Cylinder, v, new Vector3(0, 0.15f, 0), new Vector3(0.8f, 0.6f, 0.8f), M(Mat.ChestWood), new Vector3(0, 0, 90));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(-0.5f, -0.05f, 0), new Vector3(0.08f, 1f, 0.85f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0.5f, -0.05f, 0), new Vector3(0.08f, 1f, 0.85f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, 0.05f, -0.42f), new Vector3(0.2f, 0.25f, 0.05f), M(Mat.Gold));
                    col.radius = 1f;
                    c.spinSpeed = 0f; c.bobAmplitude = 0.04f; c.highlightable = true;
                    break;
                case CollectibleType.Artifact:
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.35f, 0), new Vector3(0.45f, 0.12f, 0.45f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.05f, 0), new Vector3(0.32f, 0.5f, 0.25f), M(Mat.Artifact));
                    Util.Prim(PrimitiveType.Sphere, v, new Vector3(0, 0.32f, 0), new Vector3(0.32f, 0.32f, 0.32f), M(Mat.Artifact));
                    Util.MeshObj(MeshFactory.Cone(4), v, new Vector3(0, 0.45f, 0), new Vector3(0.36f, 0.3f, 0.36f), M(Mat.Gold), new Vector3(0, 45, 0));
                    c.spinSpeed = 90f; c.highlightable = true;
                    break;
                case CollectibleType.HiddenRelic:
                    Util.Prim(PrimitiveType.Sphere, v, Vector3.zero, Vector3.one * 0.45f, M(Mat.Relic));
                    Util.Prim(PrimitiveType.Cylinder, v, Vector3.zero, new Vector3(0.8f, 0.015f, 0.8f), M(Mat.Gold), new Vector3(70, 0, 0));
                    Util.Prim(PrimitiveType.Cylinder, v, Vector3.zero, new Vector3(0.8f, 0.015f, 0.8f), M(Mat.Gold), new Vector3(-70, 0, 0));
                    Util.Prim(PrimitiveType.Cylinder, v, new Vector3(0, 3f, 0), new Vector3(0.1f, 3f, 0.1f), M(Mat.Shield));
                    c.spinSpeed = 100f; c.hidden = true;
                    break;
                default:
                    BuildPowerUp(v, pu);
                    c.spinSpeed = 110f; c.bobAmplitude = 0.18f;
                    col.radius = 0.8f;
                    break;
            }
            c.renderers = go.GetComponentsInChildren<Renderer>(true);
            return go;
        }

        static void BuildPowerUp(Transform v, PowerUpType pu)
        {
            Util.Prim(PrimitiveType.Sphere, v, Vector3.zero, Vector3.one * 1.3f, M(Mat.Bubble));
            switch (pu)
            {
                case PowerUpType.CoinMagnet:
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(-0.22f, 0.05f, 0), new Vector3(0.16f, 0.5f, 0.16f), M(Mat.PowerMagnet));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0.22f, 0.05f, 0), new Vector3(0.16f, 0.5f, 0.16f), M(Mat.PowerMagnet));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.25f, 0), new Vector3(0.6f, 0.16f, 0.16f), M(Mat.PowerMagnet));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(-0.22f, 0.36f, 0), new Vector3(0.17f, 0.14f, 0.17f), M(Mat.Silver));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0.22f, 0.36f, 0), new Vector3(0.17f, 0.14f, 0.17f), M(Mat.Silver));
                    break;
                case PowerUpType.CrystalShield:
                    Util.Prim(PrimitiveType.Cylinder, v, Vector3.zero, new Vector3(0.6f, 0.06f, 0.7f), M(Mat.CrystalBlue), new Vector3(90, 0, 0));
                    Util.MeshObj(MeshFactory.Crystal(), v, new Vector3(0, -0.2f, -0.05f), new Vector3(0.25f, 0.4f, 0.25f), M(Mat.Silver), Vector3.zero);
                    break;
                case PowerUpType.SpeedBoost:
                    Util.MeshObj(MeshFactory.Cone(4), v, new Vector3(0, 0.05f, 0), new Vector3(0.5f, 0.4f, 0.2f), M(Mat.PowerSpeed), Vector3.zero);
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.15f, 0), new Vector3(0.18f, 0.4f, 0.12f), M(Mat.PowerSpeed));
                    Util.MeshObj(MeshFactory.Cone(4), v, new Vector3(0, -0.35f, 0), new Vector3(0.3f, 0.25f, 0.15f), M(Mat.Fire), Vector3.zero);
                    break;
                case PowerUpType.ScoreMultiplier:
                    for (int i = 0; i < 5; i++)
                        Util.MeshObj(MeshFactory.Cone(3), v, Vector3.zero, new Vector3(0.22f, 0.45f, 0.1f), M(Mat.PowerMulti), new Vector3(0, 0, i * 72f));
                    Util.Prim(PrimitiveType.Sphere, v, Vector3.zero, Vector3.one * 0.25f, M(Mat.PowerMulti));
                    break;
                case PowerUpType.AncientVision:
                    Util.Prim(PrimitiveType.Sphere, v, Vector3.zero, new Vector3(0.6f, 0.35f, 0.25f), M(Mat.Silver));
                    Util.Prim(PrimitiveType.Sphere, v, new Vector3(0, 0, -0.1f), new Vector3(0.24f, 0.24f, 0.1f), M(Mat.PowerVision));
                    Util.Prim(PrimitiveType.Sphere, v, new Vector3(0, 0, -0.15f), new Vector3(0.1f, 0.1f, 0.05f), M(Mat.Pit));
                    break;
                default:
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, -0.1f, 0), new Vector3(0.6f, 0.36f, 0.4f), M(Mat.ChestWood));
                    Util.Prim(PrimitiveType.Cube, v, new Vector3(0, 0.12f, 0), new Vector3(0.62f, 0.1f, 0.42f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Sphere, v, new Vector3(0, 0.2f, 0), new Vector3(0.45f, 0.18f, 0.3f), M(Mat.GoldPile));
                    break;
            }
        }
    }
}
