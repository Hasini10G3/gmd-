using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TreasureHunt
{
    /// <summary>Game state machine, score/distance/speed, pause, countdown, game over, revive, retry, home.</summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Tooltip("Gems needed for the first revive in a run. Each further revive in the same run doubles the cost.")]
        public int reviveGemCost = GameConfig.DefaultReviveCost;

        public GameState State { get; private set; }
        public float Distance { get; private set; }
        public float Score { get; private set; }
        public float BaseSpeed { get; private set; }
        public int RunCoins { get; private set; }
        public int RunGems { get; private set; }
        public int RunKeys { get; private set; }
        public int RevivesUsed { get; private set; }
        public bool NewBest { get; private set; }
        public DeathCause LastDeath { get; private set; }
        public int RunsStarted { get; private set; }

        public event System.Action<GameState> StateChanged;
        public event System.Action<int> CountdownTick;
        public event System.Action<string, Color> ToastRequested;

        Coroutine routine;

        public float CurrentSpeed
        {
            get { return BaseSpeed * (PowerUpManager.Instance != null ? PowerUpManager.Instance.SpeedFactor : 1f); }
        }
        public float Difficulty { get { return Mathf.Clamp01(Distance / GameConfig.DifficultyDistance); } }
        public int ReviveCost { get { return reviveGemCost * (1 << Mathf.Min(RevivesUsed, 4)); } }
        public bool CanRevive { get { return SaveSystem.Gems >= ReviveCost; } }
        public int ScoreInt { get { return Mathf.FloorToInt(Score); } }

        void Awake()
        {
            Instance = this;
            State = GameState.Menu;
            BaseSpeed = GameConfig.StartSpeed;
        }

        public static float SpeedAtDistance(float d)
        {
            return Mathf.Min(GameConfig.MaxSpeed, GameConfig.StartSpeed + d * GameConfig.SpeedPerMeter);
        }

        void Update()
        {
            if (State != GameState.Playing) return;
            BaseSpeed = SpeedAtDistance(Distance);
            var p = PlayerController.Instance;
            if (p != null && p.transform.position.z > GameConfig.OriginShiftThreshold) ShiftOrigin(GameConfig.OriginShiftThreshold);
        }

        void SetState(GameState s)
        {
            State = s;
            if (StateChanged != null) StateChanged(s);
        }

        // ------------------------------------------------------------------ scoring
        public void AddDistance(float meters)
        {
            Distance += meters;
            Score += meters * (PowerUpManager.Instance != null ? PowerUpManager.Instance.ScoreFactor : 1f);
        }

        public void AddScore(int points)
        {
            Score += points * (PowerUpManager.Instance != null ? PowerUpManager.Instance.ScoreFactor : 1f);
        }

        public void AddCoins(int n) { RunCoins += n; SaveSystem.Coins += n; }
        public void AddGems(int n) { RunGems += n; SaveSystem.Gems += n; }
        public void AddKeys(int n) { RunKeys += n; SaveSystem.Keys += n; }

        public void ShowToast(string msg, Color c) { if (ToastRequested != null) ToastRequested(msg, c); }

        // ------------------------------------------------------------------ flow
        void ResetWorld()
        {
            StopRoutine();
            Time.timeScale = 1f;
            Distance = 0f; Score = 0f;
            RunCoins = 0; RunGems = 0; RunKeys = 0;
            RevivesUsed = 0; NewBest = false;
            BaseSpeed = GameConfig.StartSpeed;
            if (PowerUpManager.Instance != null) PowerUpManager.Instance.ClearAll();
            if (PlayerController.Instance != null) PlayerController.Instance.ResetPlayer();
            if (TrackGenerator.Instance != null) TrackGenerator.Instance.ResetTrack();
        }

        /// <summary>Main-menu Play button.</summary>
        public void StartRun()
        {
            if (State == GameState.Playing || State == GameState.Countdown) return;
            ResetWorld();
            RunsStarted++;
            SaveSystem.RunsPlayed++;
            if (CameraFollow.Instance != null) CameraFollow.Instance.BeginTransition();
            SetState(GameState.Playing);
        }

        public void Retry()
        {
            ResetWorld();
            RunsStarted++;
            SaveSystem.RunsPlayed++;
            if (CameraFollow.Instance != null) CameraFollow.Instance.Snap();
            SetState(GameState.Playing);
        }

        public void GoHome()
        {
            SaveSystem.Save();
            ResetWorld();
            if (CameraFollow.Instance != null) CameraFollow.Instance.BeginTransition();
            SetState(GameState.Menu);
        }

        public void Pause()
        {
            if (State != GameState.Playing) return;
            Time.timeScale = 0f;
            SaveSystem.Save();
            SetState(GameState.Paused);
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            StartCountdown();
        }

        void StartCountdown()
        {
            StopRoutine();
            Time.timeScale = 1f;
            SetState(GameState.Countdown);
            routine = StartCoroutine(CountdownRoutine());
        }

        IEnumerator CountdownRoutine()
        {
            var au = AudioManager.Instance;
            for (int i = 3; i >= 1; i--)
            {
                if (CountdownTick != null) CountdownTick(i);
                if (au != null) au.Play(au.beep, 0.6f);
                yield return new WaitForSecondsRealtime(0.6f);
            }
            if (CountdownTick != null) CountdownTick(0);
            if (au != null) au.Play(au.beep, 0.7f, 1.5f);
            routine = null;
            SetState(GameState.Playing);
        }

        public void PlayerDied(DeathCause cause)
        {
            if (State != GameState.Playing) return;
            LastDeath = cause;
            SetState(GameState.Dying);
            StopRoutine();
            routine = StartCoroutine(GameOverRoutine());
        }

        IEnumerator GameOverRoutine()
        {
            yield return new WaitForSeconds(1.1f);
            NewBest = SaveSystem.SubmitScore(ScoreInt);
            var au = AudioManager.Instance;
            if (au != null) au.Play(au.gameOver, 0.8f);
            routine = null;
            SetState(GameState.GameOver);
        }

        /// <summary>Spends gems, clears nearby hazards and resumes after a 3-2-1 countdown.</summary>
        public bool Revive()
        {
            if (State != GameState.GameOver || !CanRevive) return false;
            if (!SaveSystem.SpendGems(ReviveCost)) return false;
            RevivesUsed++;
            var p = PlayerController.Instance;
            if (TrackGenerator.Instance != null && p != null)
            {
                float z = p.transform.position.z;
                TrackGenerator.Instance.ClearObstaclesBetween(z - 6f, z + 45f);
            }
            if (p != null) p.Revive();
            if (CameraFollow.Instance != null) CameraFollow.Instance.Snap();
            StartCountdown();
            return true;
        }

        void StopRoutine()
        {
            if (routine != null) { StopCoroutine(routine); routine = null; }
        }

        // ------------------------------------------------------------------ floating origin
        void ShiftOrigin(float d)
        {
            var shift = new Vector3(0f, 0f, d);
            var roots = SceneManager.GetActiveScene().GetRootGameObjects();
            for (int i = 0; i < roots.Length; i++)
            {
                if (roots[i].GetComponent<Canvas>() != null) continue;
                roots[i].transform.position -= shift;
            }
            if (TrackGenerator.Instance != null) TrackGenerator.Instance.ShiftOrigin(d);
            Physics.SyncTransforms();
        }

        void OnApplicationPause(bool paused)
        {
            if (!paused) return;
            if (State == GameState.Playing) Pause();
            SaveSystem.Save();
        }

        void OnApplicationQuit() { SaveSystem.Save(); }
    }
}
