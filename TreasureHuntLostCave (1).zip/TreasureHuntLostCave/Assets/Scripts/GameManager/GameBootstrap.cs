using UnityEngine;
using UnityEngine.SceneManagement;

namespace TreasureHunt
{
    /// <summary>
    /// Entry point. The LostCave scene contains a single GameObject with this component;
    /// everything else (managers, explorer, camera, cave, UI, audio) is created and wired here,
    /// so there are no Inspector references that can break.
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public class GameBootstrap : MonoBehaviour
    {
        public const string MainSceneName = "LostCave";
        static bool booted;

        [Tooltip("Gems required for the first revive (doubles for each extra revive in a run).")]
        public int reviveGemCost = GameConfig.DefaultReviveCost;
        [Tooltip("Target frame rate on device.")]
        public int targetFrameRate = 60;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoCreate()
        {
            // Safety net: if the LostCave scene is opened but its bootstrap object is missing, create it.
            if (SceneManager.GetActiveScene().name != MainSceneName) return;
            if (FindObjectOfType<GameBootstrap>() != null) return;
            new GameObject("GameBootstrap (auto)").AddComponent<GameBootstrap>();
        }

        void Awake()
        {
            if (booted && GameManager.Instance != null) { Destroy(gameObject); return; }
            booted = true;
            EnvironmentAnimator.ResetRegistry();
            MaterialLibrary.ClearCache();

            Application.targetFrameRate = targetFrameRate;
            QualitySettings.vSyncCount = 0;
            QualitySettings.pixelLightCount = 4;
            QualitySettings.shadows = ShadowQuality.Disable;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Input.multiTouchEnabled = true;
            Time.timeScale = 1f;
            DisableSceneDefaults();

            var managers = new GameObject("Managers");
            managers.AddComponent<AudioManager>();
            managers.AddComponent<FXManager>();
            managers.AddComponent<PowerUpManager>();
            managers.AddComponent<CollectibleManager>();
            var gm = managers.AddComponent<GameManager>();
            gm.reviveGemCost = reviveGemCost;
            managers.AddComponent<EnvironmentAnimator>();

            PlayerFactory.Create();

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = EnvironmentAnimator.FogFor(Biome.CrystalCave);
            cam.nearClipPlane = 0.2f;
            cam.farClipPlane = 150f;
            cam.fieldOfView = 62f;
            camGo.AddComponent<AudioListener>();
            var follow = camGo.AddComponent<CameraFollow>();
            follow.target = PlayerController.Instance.transform;
            EnvironmentAnimator.Instance.SetCamera(cam);
            FXManager.Instance.AttachCameraEffects(camGo.transform);

            var track = new GameObject("Track");
            track.AddComponent<TrackGenerator>();

            managers.AddComponent<InputHandler>();
            new GameObject("UI").AddComponent<UIManager>();
            follow.Snap();

            SmokeTestRunner.StartIfRequested(managers);
        }

        void OnDestroy()
        {
            if (GameManager.Instance == null) booted = false;
        }

        /// <summary>A default Unity scene has a camera and a bright sun; neither belongs in a dark cave.</summary>
        static void DisableSceneDefaults()
        {
            foreach (var c in FindObjectsOfType<Camera>()) c.gameObject.SetActive(false);
            foreach (var l in FindObjectsOfType<Light>()) if (l.type == LightType.Directional) l.gameObject.SetActive(false);
            RenderSettings.skybox = null;
            // The Editor builder leaves a static cave preview in the scene for the Scene view; hide it at runtime.
            var preview = GameObject.Find(EditorPreviewName);
            if (preview != null) preview.SetActive(false);
        }

        public const string EditorPreviewName = "EditorPreview (EditorOnly)";
    }
}
