using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Builds the 12 cave hazards from procedural geometry with correct trigger volumes.</summary>
    public static class ObstacleFactory
    {
        static Material M(string k) { return MaterialLibrary.Get(k); }

        public static Obstacle Create(ObstacleKind kind)
        {
            var go = new GameObject("Obstacle_" + kind);
            var ob = go.AddComponent<Obstacle>();
            ob.kind = kind;
            ob.requirement = GameConfig.RequirementOf(kind);
            var box = go.AddComponent<BoxCollider>();
            box.isTrigger = true;
            ob.hitBox = box;
            switch (ob.requirement)
            {
                case Requirement.ChangeLane: box.center = new Vector3(0, 1.15f, 0); box.size = new Vector3(1.9f, 2.3f, 1.4f); break;
                case Requirement.Jump: box.center = new Vector3(0, 0.3f, 0); box.size = new Vector3(2.0f, 0.6f, 1.4f); break;
                default: box.center = new Vector3(0, 2.6f, 0); box.size = new Vector3(2.2f, 3.2f, 0.9f); break;
            }
            var t = go.transform;
            switch (kind)
            {
                case ObstacleKind.FallingBoulder: FallingBoulder(ob, t); break;
                case ObstacleKind.Stalagmite: Stalagmite(t); break;
                case ObstacleKind.Stalactite: Stalactite(t); break;
                case ObstacleKind.SpikeTrap: SpikeTrap(t); break;
                case ObstacleKind.CollapsingBridge: CollapsingBridge(ob, t, box); break;
                case ObstacleKind.Gap: Gap(t, box); break;
                case ObstacleKind.RollingRock: RollingRock(ob, t); break;
                case ObstacleKind.MineCart: MineCart(t); break;
                case ObstacleKind.AncientGuard: AncientGuard(ob, t); break;
                case ObstacleKind.CaveCrystal: CaveCrystal(t); break;
                case ObstacleKind.FallingDebris: FallingDebris(t); break;
                case ObstacleKind.WaterHazard: WaterHazard(t, box); break;
            }
            if (ob.behaviour != null) ob.behaviour.obstacle = ob;
            return ob;
        }

        static void FallingBoulder(Obstacle ob, Transform t)
        {
            var b = t.gameObject.AddComponent<FallingBoulderBehaviour>();
            ob.behaviour = b;
            var warn = Util.Prim(PrimitiveType.Cylinder, t, new Vector3(0, 0.03f, 0), new Vector3(2.2f, 0.01f, 2.2f), M(Mat.Warning));
            b.warning = warn.transform;
            var rock = Util.Node("Boulder", t, new Vector3(0, 10f, 0));
            Util.MeshObj(MeshFactory.Rock(3), rock.transform, Vector3.zero, Vector3.one * 2.3f, M(Mat.RockWall), Vector3.zero);
            b.boulder = rock.transform;
            ob.hitBox.center = new Vector3(0, 1.15f, 0);
            ob.hitBox.size = new Vector3(2f, 2.3f, 2f);
        }

        static void Stalagmite(Transform t)
        {
            Util.MeshObj(MeshFactory.Cone(7), t, new Vector3(0, -0.1f, 0), new Vector3(1.5f, 3.2f, 1.5f), M(Mat.RockWall), new Vector3(0, Util.R(0, 360), 0));
            Util.MeshObj(MeshFactory.Cone(7), t, new Vector3(-0.55f, -0.1f, 0.2f), new Vector3(0.8f, 2.1f, 0.8f), M(Mat.RockWall), new Vector3(0, 0, 8));
            Util.MeshObj(MeshFactory.Cone(7), t, new Vector3(0.6f, -0.1f, -0.2f), new Vector3(0.7f, 2.5f, 0.7f), M(Mat.RockWall), new Vector3(0, 0, -6));
            Util.MeshObj(MeshFactory.Rock(0), t, new Vector3(0, 0.2f, 0), new Vector3(2f, 0.7f, 1.6f), M(Mat.RockDark), Vector3.zero);
        }

        static void Stalactite(Transform t)
        {
            // a rock curtain hanging from the ceiling, jagged tips end at ~1.15 m: slide under it
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 9.6f, 0), new Vector3(2.4f, 15f, 0.9f), M(Mat.RockDark));
            Util.MeshObj(MeshFactory.Rock(4), t, new Vector3(0, 2.5f, 0), new Vector3(2.7f, 1.4f, 1.3f), M(Mat.RockWall), Vector3.zero);
            for (int i = 0; i < 4; i++)
            {
                float x = -0.9f + i * 0.6f;
                float len = 0.6f + (i % 2) * 0.35f;
                Util.MeshObj(MeshFactory.Cone(6), t, new Vector3(x, 2.15f, 0), new Vector3(0.45f, len, 0.45f), M(Mat.RockWall), new Vector3(180, 0, 0));
            }
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 1.95f, 0.47f), new Vector3(2.2f, 0.08f, 0.02f), M(Mat.RuneOrange));
        }

        static void SpikeTrap(Transform t)
        {
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.05f, 0), new Vector3(2.2f, 0.1f, 1.5f), M(Mat.RuinStoneDark));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.06f, 0), new Vector3(2.3f, 0.08f, 1.6f), M(Mat.Warning));
            for (int x = 0; x < 5; x++)
                for (int z = 0; z < 3; z++)
                    Util.MeshObj(MeshFactory.Cone(5), t, new Vector3(-0.8f + x * 0.4f, 0.08f, -0.45f + z * 0.45f), new Vector3(0.22f, 0.55f, 0.22f), M(Mat.Metal), Vector3.zero);
        }

        static void CollapsingBridge(Obstacle ob, Transform t, BoxCollider box)
        {
            box.center = new Vector3(0, -0.2f, 0); box.size = new Vector3(2.1f, 1f, 2.8f);
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.012f, 0), new Vector3(2.3f, 0.02f, 3.2f), M(Mat.Pit));
            var b = t.gameObject.AddComponent<CollapsingBridgeBehaviour>();
            ob.behaviour = b;
            b.planks = new Transform[6];
            for (int i = 0; i < 6; i++)
            {
                var p = Util.Node("Plank" + i, t, new Vector3(0, 0.06f, -1.25f + i * 0.5f));
                Util.Prim(PrimitiveType.Cube, p.transform, Vector3.zero, new Vector3(2.2f, 0.1f, 0.42f), M(i % 2 == 0 ? Mat.Wood : Mat.WoodDark), new Vector3(0, Util.R(-4, 4), 0));
                Util.Prim(PrimitiveType.Cube, p.transform, new Vector3(Util.R(-0.6f, 0.6f), 0.055f, 0), new Vector3(0.5f, 0.01f, 0.05f), M(Mat.Warning));
                b.planks[i] = p.transform;
            }
            for (int s = -1; s <= 1; s += 2)
                Util.Prim(PrimitiveType.Cylinder, t, new Vector3(s * 1.15f, 0.25f, 0), new Vector3(0.08f, 1.6f, 0.08f), M(Mat.Wood), new Vector3(90, 0, 0));
        }

        static void Gap(Transform t, BoxCollider box)
        {
            box.center = new Vector3(0, -0.2f, 0); box.size = new Vector3(2.1f, 1f, 2.6f);
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.012f, 0), new Vector3(2.3f, 0.02f, 3f), M(Mat.Pit));
            for (int s = -1; s <= 1; s += 2)
                for (int i = 0; i < 3; i++)
                    Util.MeshObj(MeshFactory.Rock(i), t, new Vector3(-0.8f + i * 0.8f, 0.02f, s * 1.55f), new Vector3(0.8f, 0.25f, 0.5f), M(Mat.RockWall), new Vector3(0, Util.R(0, 360), 0));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.02f, -1.45f), new Vector3(2.3f, 0.02f, 0.1f), M(Mat.Warning));
        }

        static void RollingRock(Obstacle ob, Transform t)
        {
            var b = t.gameObject.AddComponent<RollingRockBehaviour>();
            ob.behaviour = b;
            var rock = Util.Node("Rock", t, new Vector3(0, 0.95f, 2f));
            Util.MeshObj(MeshFactory.Rock(2), rock.transform, Vector3.zero, Vector3.one * 2.0f, M(Mat.RockWall), Vector3.zero);
            Util.Prim(PrimitiveType.Cube, rock.transform, new Vector3(0, 0, 0.98f), new Vector3(0.6f, 0.15f, 0.02f), M(Mat.RuneOrange));
            b.rock = rock.transform;
            ob.hitBox.size = new Vector3(1.9f, 2f, 1.8f);
        }

        static void MineCart(Transform t)
        {
            for (int s = -1; s <= 1; s += 2)
                Util.Prim(PrimitiveType.Cube, t, new Vector3(s * 0.55f, 0.04f, 0), new Vector3(0.08f, 0.08f, 4f), M(Mat.Metal));
            EnvironmentFactory.Cart(t, Vector3.zero, 0f, 0f, true);
            Util.Prim(PrimitiveType.Cylinder, t, new Vector3(0.7f, 1.9f, 0.9f), new Vector3(0.06f, 0.5f, 0.06f), M(Mat.Wood));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0.7f, 2.4f, 0.9f), new Vector3(0.22f, 0.3f, 0.22f), M(Mat.Fire));
        }

        static void AncientGuard(Obstacle ob, Transform t)
        {
            var g = Util.Node("Guard", t, Vector3.zero).transform;
            Util.Prim(PrimitiveType.Cube, g, new Vector3(0, 0.2f, 0), new Vector3(1.5f, 0.4f, 1.2f), M(Mat.RuinStoneDark));
            Util.Prim(PrimitiveType.Cube, g, new Vector3(-0.25f, 0.9f, 0), new Vector3(0.35f, 1f, 0.45f), M(Mat.Guard));
            Util.Prim(PrimitiveType.Cube, g, new Vector3(0.25f, 0.9f, 0), new Vector3(0.35f, 1f, 0.45f), M(Mat.Guard));
            Util.Prim(PrimitiveType.Cube, g, new Vector3(0, 1.85f, 0), new Vector3(1f, 1f, 0.55f), M(Mat.Guard));
            Util.Prim(PrimitiveType.Cube, g, new Vector3(-0.68f, 1.8f, 0.1f), new Vector3(0.28f, 0.9f, 0.3f), M(Mat.Guard));
            Util.Prim(PrimitiveType.Cube, g, new Vector3(0.68f, 1.8f, 0.1f), new Vector3(0.28f, 0.9f, 0.3f), M(Mat.Guard));
            // spear and shield
            Util.Prim(PrimitiveType.Cylinder, g, new Vector3(0.85f, 1.9f, -0.15f), new Vector3(0.08f, 1.6f, 0.08f), M(Mat.WoodDark));
            Util.MeshObj(MeshFactory.Cone(4), g, new Vector3(0.85f, 3.45f, -0.15f), new Vector3(0.22f, 0.45f, 0.22f), M(Mat.Metal), Vector3.zero);
            Util.Prim(PrimitiveType.Cylinder, g, new Vector3(-0.85f, 1.7f, -0.35f), new Vector3(0.9f, 0.06f, 0.9f), M(Mat.Gold), new Vector3(90, 0, 0));
            var head = Util.Node("Head", g, new Vector3(0, 2.65f, 0)).transform;
            Util.Prim(PrimitiveType.Cube, head, Vector3.zero, new Vector3(0.6f, 0.6f, 0.55f), M(Mat.Guard));
            Util.MeshObj(MeshFactory.Cone(4), head, new Vector3(0, 0.3f, 0), new Vector3(0.85f, 0.55f, 0.85f), M(Mat.Gold), new Vector3(0, 45, 0));
            Util.Prim(PrimitiveType.Cube, head, new Vector3(-0.14f, 0.05f, 0.28f), new Vector3(0.12f, 0.07f, 0.02f), M(Mat.GuardEyes));
            Util.Prim(PrimitiveType.Cube, head, new Vector3(0.14f, 0.05f, 0.28f), new Vector3(0.12f, 0.07f, 0.02f), M(Mat.GuardEyes));
            g.localRotation = Quaternion.Euler(0, 180f, 0); // face the player
            var b = t.gameObject.AddComponent<GuardBehaviour>();
            b.head = head;
            ob.behaviour = b;
        }

        static void CaveCrystal(Transform t)
        {
            Util.MeshObj(MeshFactory.Crystal(), t, new Vector3(0, 0, 0), new Vector3(1.1f, 2.6f, 1.1f), M(Mat.CrystalPurple), new Vector3(0, 15, 0));
            Util.MeshObj(MeshFactory.Crystal(), t, new Vector3(-0.6f, 0, 0.1f), new Vector3(0.7f, 1.8f, 0.7f), M(Mat.CrystalPurple), new Vector3(0, 0, 22));
            Util.MeshObj(MeshFactory.Crystal(), t, new Vector3(0.6f, 0, -0.1f), new Vector3(0.7f, 2f, 0.7f), M(Mat.CrystalBlue), new Vector3(0, 40, -20));
            Util.MeshObj(MeshFactory.Crystal(), t, new Vector3(0.1f, 0, 0.5f), new Vector3(0.5f, 1.2f, 0.5f), M(Mat.CrystalBlue), new Vector3(25, 0, 0));
            Util.MeshObj(MeshFactory.Rock(1), t, new Vector3(0, 0.1f, 0), new Vector3(1.9f, 0.5f, 1.4f), M(Mat.RockDark), Vector3.zero);
        }

        static void FallingDebris(Transform t)
        {
            for (int i = 0; i < 7; i++)
                Util.MeshObj(MeshFactory.Rock(i), t, new Vector3(Util.R(-0.85f, 0.85f), 0.15f, Util.R(-0.5f, 0.5f)), Vector3.one * Util.R(0.35f, 0.65f), M(Mat.RockWall), new Vector3(0, Util.R(0, 360), 0));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.02f, 0), new Vector3(2.2f, 0.02f, 1.5f), M(Mat.Warning));
            FXManager.CreateAmbient(t, new Vector3(0, 6f, 0), new Vector3(1.6f, 0.2f, 1f), new Color(0.75f, 0.7f, 0.6f, 0.9f), 10f, 0.1f, 0.12f, 1.2f, 1.6f, M(Mat.Particle));
        }

        static void WaterHazard(Transform t, BoxCollider box)
        {
            box.center = new Vector3(0, -0.2f, 0); box.size = new Vector3(2.1f, 1f, 2.6f);
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, -0.6f, 0), new Vector3(2.3f, 0.05f, 3f), M(Mat.Pit));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, -0.12f, 0), new Vector3(2.3f, 0.06f, 3f), M(Mat.Water));
            for (int s = -1; s <= 1; s += 2)
                Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.03f, s * 1.5f), new Vector3(2.3f, 0.06f, 0.15f), M(Mat.EdgeGreen));
            FXManager.CreateAmbient(t, new Vector3(0, 0f, 0), new Vector3(2f, 0.1f, 2.6f), new Color(0.7f, 0.95f, 1f, 0.5f), 8f, 0.6f, 0.25f, 0.3f, 1f, M(Mat.Particle));
        }
    }
}
