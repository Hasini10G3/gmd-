using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Boulder drops from the ceiling when the player approaches; a red warning circle marks the lane.</summary>
    public class FallingBoulderBehaviour : ObstacleBehaviour
    {
        public Transform boulder, warning;
        const float StartY = 10f, RestY = 1.1f;
        float y, vy;
        bool falling, landed;

        public override void ResetState()
        {
            y = StartY; vy = 0f; falling = false; landed = false;
            boulder.localPosition = new Vector3(0, y, 0);
            warning.gameObject.SetActive(true);
            obstacle.hitBox.enabled = false;
        }

        void Update()
        {
            if (landed) return;
            float ws = 2.2f + 0.25f * Mathf.Sin(Time.time * 12f);
            warning.localScale = new Vector3(ws, 0.01f, ws);
            if (!Running) return;
            if (!falling && DistanceAhead() < Speed * 1.35f + 4f)
            {
                falling = true;
                if (AudioManager.Instance != null) AudioManager.Instance.Play(AudioManager.Instance.rumble, 0.6f);
            }
            if (!falling) return;
            vy += 45f * Time.deltaTime;
            y -= vy * Time.deltaTime;
            boulder.Rotate(200f * Time.deltaTime, 90f * Time.deltaTime, 0f, Space.Self);
            if (y < 3.3f && !obstacle.smashed) obstacle.hitBox.enabled = true;
            if (y <= RestY)
            {
                y = RestY; landed = true;
                warning.gameObject.SetActive(false);
                if (FXManager.Instance != null) FXManager.Instance.Debris(transform.position + Vector3.up * 0.3f, 10);
                if (AudioManager.Instance != null) AudioManager.Instance.Play(AudioManager.Instance.rockFall, 0.9f);
                if (CameraFollow.Instance != null && DistanceAhead() < 25f) CameraFollow.Instance.Shake(0.25f, 0.35f);
            }
            boulder.localPosition = new Vector3(0, y, 0);
        }
    }

    /// <summary>Rock rolls 6 m toward the player inside its own lane.</summary>
    public class RollingRockBehaviour : ObstacleBehaviour
    {
        public Transform rock;
        const float StartZ = 2f, EndZ = -4f;
        float z;
        bool rolling;

        public override void ResetState()
        {
            z = StartZ; rolling = false;
            rock.localPosition = new Vector3(0, 0.95f, z);
            obstacle.hitBox.center = new Vector3(0, 1f, z);
        }

        void Update()
        {
            if (!Running) return;
            if (!rolling && DistanceAhead() < Speed * 1.5f + 6f)
            {
                rolling = true;
                if (AudioManager.Instance != null) AudioManager.Instance.Play(AudioManager.Instance.rumble, 0.5f, 1.3f);
            }
            if (!rolling || z <= EndZ) return;
            float step = 7f * Time.deltaTime;
            z = Mathf.Max(EndZ, z - step);
            rock.localPosition = new Vector3(0, 0.95f, z);
            rock.Rotate(Vector3.right, -step / 0.95f * Mathf.Rad2Deg, Space.World);
            obstacle.hitBox.center = new Vector3(0, 1f, z);
        }
    }

    /// <summary>Planks shake, then fall away into the pit before the player arrives. Must be jumped.</summary>
    public class CollapsingBridgeBehaviour : ObstacleBehaviour
    {
        public Transform[] planks;
        Vector3[] basePos;
        float[] fallV;
        bool collapsing;
        float collapseTime;

        public override void ResetState()
        {
            if (basePos == null)
            {
                basePos = new Vector3[planks.Length];
                fallV = new float[planks.Length];
                for (int i = 0; i < planks.Length; i++) basePos[i] = planks[i].localPosition;
            }
            for (int i = 0; i < planks.Length; i++)
            {
                planks[i].localPosition = basePos[i];
                planks[i].localRotation = Quaternion.identity;
                planks[i].gameObject.SetActive(true);
                fallV[i] = 0f;
            }
            collapsing = false;
        }

        void Update()
        {
            if (!Running) return;
            float d = DistanceAhead();
            if (!collapsing)
            {
                if (d < Speed * 2.4f + 6f)
                    for (int i = 0; i < planks.Length; i++)
                        planks[i].localPosition = basePos[i] + new Vector3(0, Mathf.Sin(Time.time * 40f + i) * 0.03f, 0);
                if (d < Speed * 1.3f + 4f)
                {
                    collapsing = true;
                    collapseTime = 0f;
                    if (AudioManager.Instance != null) AudioManager.Instance.Play(AudioManager.Instance.rockFall, 0.5f, 1.4f);
                }
                return;
            }
            collapseTime += Time.deltaTime;
            for (int i = 0; i < planks.Length; i++)
            {
                if (!planks[i].gameObject.activeSelf || collapseTime < i * 0.06f) continue;
                fallV[i] += 25f * Time.deltaTime;
                planks[i].localPosition += Vector3.down * fallV[i] * Time.deltaTime;
                planks[i].Rotate((i % 2 == 0 ? 90f : -70f) * Time.deltaTime, 0, 40f * Time.deltaTime);
                if (planks[i].localPosition.y < -8f) planks[i].gameObject.SetActive(false);
            }
        }
    }

    /// <summary>Stone guardian turns its head toward the approaching explorer.</summary>
    public class GuardBehaviour : ObstacleBehaviour
    {
        public Transform head;

        public override void ResetState() { head.localRotation = Quaternion.identity; }

        void Update()
        {
            var p = PlayerController.Instance;
            if (p == null) return;
            float d = DistanceAhead();
            if (d > 40f || d < 0f) return;
            Vector3 to = p.transform.position - head.position; to.y = 0f;
            if (to.sqrMagnitude < 0.01f) return;
            Quaternion target = Quaternion.LookRotation(to.normalized, Vector3.up);
            head.rotation = Quaternion.Slerp(head.rotation, target, Time.deltaTime * 3f);
        }
    }
}
