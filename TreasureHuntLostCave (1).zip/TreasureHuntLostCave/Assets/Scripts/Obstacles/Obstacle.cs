using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Base obstacle. The trigger box encodes how it is avoided:
    /// ChangeLane = tall box (y 0..2.3), Jump = low box (top at 0.3-0.6), Slide = high box (bottom at y 1.0).
    /// </summary>
    public class Obstacle : MonoBehaviour, IPoolable
    {
        public ObstacleKind kind;
        public Requirement requirement;
        public BoxCollider hitBox;
        public ObstacleBehaviour behaviour;
        [System.NonSerialized] public bool smashed;
        Renderer[] renderers;
        ParticleSystem[] particles;

        public bool IsArmed { get { return hitBox != null && hitBox.enabled && !smashed; } }

        void CacheRenderers()
        {
            if (renderers == null) renderers = GetComponentsInChildren<Renderer>(true);
            if (particles == null) particles = GetComponentsInChildren<ParticleSystem>(true);
        }

        public void OnSpawned()
        {
            CacheRenderers();
            smashed = false;
            for (int i = 0; i < renderers.Length; i++) renderers[i].enabled = true;
            for (int i = 0; i < particles.Length; i++) particles[i].Play();
            hitBox.enabled = true;
            if (behaviour != null) { behaviour.enabled = true; behaviour.ResetState(); }
        }

        public void OnDespawned() { }

        /// <summary>Destroyed by shield/speed boost.</summary>
        public void Smash(bool effects)
        {
            if (smashed) return;
            CacheRenderers();
            smashed = true;
            hitBox.enabled = false;
            for (int i = 0; i < renderers.Length; i++) renderers[i].enabled = false;
            for (int i = 0; i < particles.Length; i++) particles[i].Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            if (behaviour != null) behaviour.enabled = false;
            if (effects && FXManager.Instance != null)
            {
                FXManager.Instance.Debris(transform.position + Vector3.up, 14);
                if (AudioManager.Instance != null) AudioManager.Instance.Play(AudioManager.Instance.collision, 0.7f, 1.2f);
            }
        }
    }

    /// <summary>Optional moving part of an obstacle (falling, rolling, collapsing...). Only enabled while spawned.</summary>
    public abstract class ObstacleBehaviour : MonoBehaviour
    {
        public Obstacle obstacle;
        public abstract void ResetState();

        /// <summary>Distance (m) from the player to this obstacle along the track; large when no player.</summary>
        protected float DistanceAhead()
        {
            var p = PlayerController.Instance;
            if (p == null) return 9999f;
            return transform.position.z - p.transform.position.z;
        }

        protected static bool Running
        {
            get { var gm = GameManager.Instance; return gm != null && gm.State == GameState.Playing; }
        }

        protected static float Speed
        {
            get { var gm = GameManager.Instance; return gm != null ? gm.CurrentSpeed : GameConfig.StartSpeed; }
        }
    }
}
