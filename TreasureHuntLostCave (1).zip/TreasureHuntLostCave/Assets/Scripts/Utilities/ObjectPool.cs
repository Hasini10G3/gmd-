using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Implemented by pooled components that must reset when reused.</summary>
    public interface IPoolable
    {
        void OnSpawned();
        void OnDespawned();
    }

    /// <summary>Attached automatically to every pooled object.</summary>
    public class PooledItem : MonoBehaviour
    {
        [System.NonSerialized] public KeyedPool pool;
        [System.NonSerialized] public int key;
        [System.NonSerialized] public bool inUse;
        [System.NonSerialized] public TrackSegment owner;
        [System.NonSerialized] public IPoolable[] hooks;
    }

    /// <summary>Object pool keyed by an int (e.g. obstacle kind). No allocations after warm-up.</summary>
    public class KeyedPool
    {
        readonly Dictionary<int, Stack<PooledItem>> free = new Dictionary<int, Stack<PooledItem>>();
        readonly System.Func<int, GameObject> factory;
        readonly Transform root;

        public int Created { get; private set; }
        public int Reused { get; private set; }
        public Transform Root { get { return root; } }

        public KeyedPool(string name, System.Func<int, GameObject> factory, Transform parent)
        {
            this.factory = factory;
            root = new GameObject(name).transform;
            root.SetParent(parent, false);
        }

        public PooledItem Spawn(int key, Transform parent, Vector3 worldPos)
        {
            PooledItem it = null;
            Stack<PooledItem> stack;
            if (free.TryGetValue(key, out stack) && stack.Count > 0)
            {
                it = stack.Pop();
                Reused++;
            }
            else
            {
                var go = factory(key);
                it = go.AddComponent<PooledItem>();
                it.pool = this;
                it.key = key;
                it.hooks = go.GetComponents<IPoolable>();
                Created++;
            }
            it.transform.SetParent(parent, false);
            it.transform.position = worldPos;
            it.transform.rotation = Quaternion.identity;
            it.inUse = true;
            it.gameObject.SetActive(true);
            for (int i = 0; i < it.hooks.Length; i++) it.hooks[i].OnSpawned();
            return it;
        }

        public void Release(PooledItem it)
        {
            if (it == null || !it.inUse) return;
            it.inUse = false;
            it.owner = null;
            for (int i = 0; i < it.hooks.Length; i++) it.hooks[i].OnDespawned();
            it.gameObject.SetActive(false);
            it.transform.SetParent(root, false);
            Stack<PooledItem> stack;
            if (!free.TryGetValue(it.key, out stack))
            {
                stack = new Stack<PooledItem>();
                free[it.key] = stack;
            }
            stack.Push(it);
        }
    }
}
