using UnityEngine;

namespace TreasureHunt
{
    public enum GameState { Menu, Countdown, Playing, Paused, Dying, GameOver }
    public enum Biome { CrystalCave = 0, AncientRuins = 1, UndergroundRiver = 2, DarkTunnel = 3, TreasureChamber = 4 }
    public enum ObstacleKind
    {
        FallingBoulder, Stalagmite, Stalactite, SpikeTrap, CollapsingBridge, Gap,
        RollingRock, MineCart, AncientGuard, CaveCrystal, FallingDebris, WaterHazard
    }
    /// <summary>How the player must avoid an obstacle.</summary>
    public enum Requirement { ChangeLane, Jump, Slide }
    public enum CollectibleType { Coin, BlueCrystal, PurpleGem, AncientKey, TreasureChest, Artifact, HiddenRelic, PowerUp }
    public enum PowerUpType { CoinMagnet, CrystalShield, SpeedBoost, ScoreMultiplier, AncientVision, TreasureBonus }
    public enum DeathCause { Crash, Fall }

    /// <summary>Central tuning values. Change numbers here to rebalance the game.</summary>
    public static class GameConfig
    {
        public const float LaneWidth = 2.5f;
        public const float SegmentLength = 30f;
        public const int SegmentsAhead = 7;
        public const int SafeStartSegments = 2;

        public const float StartSpeed = 12f;
        public const float MaxSpeed = 32f;
        public const float SpeedPerMeter = 0.006f;
        public const float SpeedBoostMultiplier = 1.6f;

        public const float JumpHeight = 2.0f;
        public const float JumpAirTime = 0.62f;
        public const float SlideDuration = 0.75f;
        public const float LaneSwitchSmooth = 0.07f;

        public const float MinRowSpacing = 14f;
        public const float RowSpacingPerSpeed = 0.9f;
        public const float OriginShiftThreshold = 1000f;
        public const float MagnetRadius = 9f;
        public const float DifficultyDistance = 2500f;
        public const int DefaultReviveCost = 20;

        /// <summary>Durations in seconds, indexed by PowerUpType. TreasureBonus is instant (value = indicator time).</summary>
        public static readonly float[] PowerUpDurations = { 10f, 15f, 5f, 10f, 10f, 2.5f };
        /// <summary>Global multiplier for power-up durations (the smoke test shortens them).</summary>
        public static float DurationScale = 1f;

        public static float LaneX(int lane) { return (lane - 1) * LaneWidth; }
        public static float Gravity { get { return 8f * JumpHeight / (JumpAirTime * JumpAirTime); } }
        public static float JumpVelocity { get { return 4f * JumpHeight / JumpAirTime; } }

        public static Requirement RequirementOf(ObstacleKind k)
        {
            switch (k)
            {
                case ObstacleKind.Stalactite: return Requirement.Slide;
                case ObstacleKind.SpikeTrap:
                case ObstacleKind.CollapsingBridge:
                case ObstacleKind.Gap:
                case ObstacleKind.FallingDebris:
                case ObstacleKind.WaterHazard: return Requirement.Jump;
                default: return Requirement.ChangeLane;
            }
        }

        public static bool IsPit(ObstacleKind k)
        {
            return k == ObstacleKind.Gap || k == ObstacleKind.CollapsingBridge || k == ObstacleKind.WaterHazard;
        }

        public static string PowerUpName(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.CoinMagnet: return "COIN MAGNET";
                case PowerUpType.CrystalShield: return "CRYSTAL SHIELD";
                case PowerUpType.SpeedBoost: return "SPEED BOOST";
                case PowerUpType.ScoreMultiplier: return "SCORE x2";
                case PowerUpType.AncientVision: return "ANCIENT VISION";
                default: return "TREASURE BONUS";
            }
        }

        public static Color PowerUpColor(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.CoinMagnet: return new Color(1f, 0.3f, 0.3f);
                case PowerUpType.CrystalShield: return new Color(0.3f, 0.85f, 1f);
                case PowerUpType.SpeedBoost: return new Color(1f, 0.6f, 0.15f);
                case PowerUpType.ScoreMultiplier: return new Color(1f, 0.9f, 0.25f);
                case PowerUpType.AncientVision: return new Color(0.35f, 1f, 0.5f);
                default: return new Color(1f, 0.75f, 0.2f);
            }
        }
    }
}
