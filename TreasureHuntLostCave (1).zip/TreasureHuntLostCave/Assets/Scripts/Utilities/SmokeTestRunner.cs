using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Automated Play Mode smoke test. Start it with the menu "Treasure Hunt > Run Play Mode Smoke Test"
    /// (or batch mode, see README). It drives the real game systems and writes SmokeTestResults.txt
    /// next to the Assets folder. Player progress is restored afterwards.
    /// </summary>
    public class SmokeTestRunner : MonoBehaviour
    {
        public const string PrefKey = "TH_RunSmokeTest";
        public const string ResultFile = "SmokeTestResults.txt";
        public static bool Finished { get; private set; }
        public static bool AllPassed { get; private set; }

        readonly List<string> lines = new List<string>();
        int pass, fail;

        public static void StartIfRequested(GameObject host)
        {
            Finished = false;
            if (PlayerPrefs.GetInt(PrefKey, 0) != 1) return;
            PlayerPrefs.SetInt(PrefKey, 0);
            PlayerPrefs.Save();
            host.AddComponent<SmokeTestRunner>();
        }

        void Check(string name, bool ok, string detail = "")
        {
            if (ok) pass++; else fail++;
            string line = (ok ? "PASS  " : "FAIL  ") + name + (string.IsNullOrEmpty(detail) ? "" : "  (" + detail + ")");
            lines.Add(line);
            if (ok) Debug.Log("[TH-TEST] " + line); else Debug.LogError("[TH-TEST] " + line);
        }

        static IEnumerator Wait(float s) { yield return new WaitForSeconds(s); }

        IEnumerator Start()
        {
            yield return null; yield return null;
            int savedBest = SaveSystem.BestScore, savedCoins = SaveSystem.Coins, savedGems = SaveSystem.Gems, savedKeys = SaveSystem.Keys;
            var gm = GameManager.Instance; var p = PlayerController.Instance; var tg = TrackGenerator.Instance;
            var pu = PowerUpManager.Instance; var cm = CollectibleManager.Instance;

            Check("Scene bootstrapped: all managers exist", gm != null && p != null && tg != null && pu != null && cm != null
                && UIManager.Instance != null && AudioManager.Instance != null && CameraFollow.Instance != null && FXManager.Instance != null);
            Check("Starts in main menu", gm.State == GameState.Menu);
            Check("Main menu visible", UIManager.Instance.MenuPanel.activeSelf);
            Check("Track generated behind main menu", tg.ActiveSegments.Count >= GameConfig.SegmentsAhead, tg.ActiveSegments.Count + " segments");

            GameConfig.DurationScale = 0.15f;
            gm.StartRun();
            tg.SpawnHazards = false;
            tg.ResetTrack();
            p.GodMode = true;
            yield return null;
            Check("Play starts a run", gm.State == GameState.Playing);
            Check("HUD visible during play", UIManager.Instance.HudPanel.activeSelf);

            float z0 = p.transform.position.z;
            yield return Wait(0.6f);
            Check("Player runs forward automatically", p.transform.position.z > z0 + 4f, "dz=" + (p.transform.position.z - z0).ToString("F1"));
            Check("Distance & score increase", gm.Distance > 4f && gm.Score > 4f);

            p.MoveLeft();
            yield return Wait(0.45f);
            Check("Lane switch left", p.Lane == 0 && Mathf.Abs(p.transform.position.x - GameConfig.LaneX(0)) < 0.25f, "x=" + p.transform.position.x.ToString("F2"));
            p.MoveLeft();
            Check("Cannot leave track on the left", p.Lane == 0);
            p.MoveRight(); p.MoveRight();
            yield return Wait(0.6f);
            Check("Lane switch right", p.Lane == 2 && Mathf.Abs(p.transform.position.x - GameConfig.LaneX(2)) < 0.25f, "x=" + p.transform.position.x.ToString("F2"));
            p.MoveRight();
            Check("Cannot leave track on the right", p.Lane == 2);
            var cam = Camera.main;
            Check("Camera follows behind player", cam != null && Mathf.Abs(cam.transform.position.z - (p.transform.position.z - 7.4f)) < 1f
                && cam.transform.position.x > 0.5f);
            p.MoveLeft();
            yield return Wait(0.4f);

            p.Jump();
            float maxY = 0f;
            for (float t = 0f; t < 0.5f; t += Time.deltaTime) { maxY = Mathf.Max(maxY, p.transform.position.y); yield return null; }
            Check("Jump reaches clearance height", maxY > 1.5f, "peak=" + maxY.ToString("F2"));
            yield return Wait(0.4f);
            Check("Player lands after jump", p.IsGrounded && p.transform.position.y == 0f);

            p.Slide();
            yield return null;
            Check("Slide lowers collider", p.IsSliding && p.ColliderHeight < 1f, "h=" + p.ColliderHeight);
            yield return Wait(GameConfig.SlideDuration + 0.2f);
            Check("Slide ends and collider restored", !p.IsSliding && p.ColliderHeight > 1.5f);

            // collectibles
            int c0 = gm.RunCoins, bank0 = SaveSystem.Coins;
            tg.TestSpawnCollectible(CollectibleType.Coin, 0, p.Lane, 0.85f, p.transform.position.z + 5f);
            yield return Wait(0.9f);
            Check("Coin collected", gm.RunCoins == c0 + 1, gm.RunCoins + " coins");
            Check("Coin banked to persistent currency", SaveSystem.Coins == bank0 + 1);
            int g0 = gm.RunGems;
            tg.TestSpawnCollectible(CollectibleType.PurpleGem, 0, p.Lane, 1f, p.transform.position.z + 5f);
            yield return Wait(0.9f);
            Check("Gem collected", gm.RunGems == g0 + 2);
            int k0 = gm.RunKeys;
            tg.TestSpawnCollectible(CollectibleType.AncientKey, 0, p.Lane, 1f, p.transform.position.z + 5f);
            yield return Wait(0.9f);
            Check("Key collected", gm.RunKeys == k0 + 1);

            // power-ups
            foreach (PowerUpType t in System.Enum.GetValues(typeof(PowerUpType)))
            {
                int before = pu.ActivationCount;
                tg.TestSpawnCollectible(CollectibleType.PowerUp, t, p.Lane, 1.1f, p.transform.position.z + 5f);
                for (float w = 0f; w < 1.2f && pu.ActivationCount == before; w += Time.deltaTime) yield return null;
                Check("Power-up pickup activates: " + t, pu.ActivationCount == before + 1 && pu.IsActive(t));
                yield return Wait(0.3f);
            }
            float speedNormal = gm.BaseSpeed;
            pu.Activate(PowerUpType.SpeedBoost);
            Check("Speed Boost increases speed", gm.CurrentSpeed > speedNormal * 1.3f);
            pu.Activate(PowerUpType.ScoreMultiplier);
            float s0 = gm.Score; gm.AddScore(100);
            Check("Score Multiplier doubles points", Mathf.Abs(gm.Score - s0 - 200f) < 0.01f);
            pu.Activate(PowerUpType.CoinMagnet);
            int cm0 = gm.RunCoins;
            int otherLane = p.Lane == 1 ? 0 : 1;
            tg.TestSpawnCollectible(CollectibleType.Coin, 0, otherLane, 0.85f, p.transform.position.z + 6f);
            yield return Wait(0.6f);
            Check("Coin Magnet pulls coin from another lane", gm.RunCoins > cm0);
            pu.Activate(PowerUpType.AncientVision);
            var relic = tg.TestSpawnCollectible(CollectibleType.HiddenRelic, 0, otherLane, 1.2f, p.transform.position.z + 30f);
            yield return null;
            Check("Ancient Vision reveals hidden relic", relic != null && relic.renderers[0].enabled);
            float maxDur = 0f;
            foreach (var d in GameConfig.PowerUpDurations) maxDur = Mathf.Max(maxDur, d);
            yield return Wait(maxDur * GameConfig.DurationScale + 0.5f);
            bool anyActive = false;
            foreach (PowerUpType t in System.Enum.GetValues(typeof(PowerUpType))) anyActive |= pu.IsActive(t);
            Check("All power-ups expire", !anyActive);
            yield return null;
            Check("Hidden relic hidden again after Vision expires", relic == null || !relic.gameObject.activeInHierarchy || !relic.renderers[0].enabled);

            // obstacles: shield absorbs one hit
            p.GodMode = false;
            p.InvulnerableTime = 0f;
            pu.Activate(PowerUpType.CrystalShield);
            var ob1 = tg.TestSpawnObstacle(ObstacleKind.Stalagmite, p.Lane, p.transform.position.z + 6f);
            yield return Wait(0.9f);
            Check("Crystal Shield absorbs one collision", gm.State == GameState.Playing && !pu.IsActive(PowerUpType.CrystalShield) && ob1 != null && ob1.smashed);
            yield return Wait(1.1f);
            // jump over spikes, slide under stalactite
            tg.TestSpawnObstacle(ObstacleKind.SpikeTrap, p.Lane, p.transform.position.z + gm.CurrentSpeed * 0.45f + 1f);
            yield return Wait(0.3f); p.Jump();
            yield return Wait(1.0f);
            Check("Jumping clears a spike trap", gm.State == GameState.Playing);
            tg.TestSpawnObstacle(ObstacleKind.Stalactite, p.Lane, p.transform.position.z + gm.CurrentSpeed * 0.45f + 1f);
            yield return Wait(0.25f); p.Slide();
            yield return Wait(1.0f);
            Check("Sliding passes under a stalactite", gm.State == GameState.Playing);

            // track recycling
            p.GodMode = true;
            int recycled0 = tg.SegmentsRecycled;
            yield return Wait(4f);
            Check("Track segments recycled behind the player", tg.SegmentsRecycled > recycled0, tg.SegmentsRecycled + " recycled");
            Check("Track stays generated ahead", tg.ActiveSegments.Count >= GameConfig.SegmentsAhead);

            // pause / resume
            gm.Pause();
            Check("Pause freezes time", gm.State == GameState.Paused && Time.timeScale == 0f && UIManager.Instance.PausePanel.activeSelf);
            gm.Resume();
            yield return new WaitForSecondsRealtime(2.3f);
            Check("Resume after countdown", gm.State == GameState.Playing && Time.timeScale == 1f);

            // collision -> game over
            p.GodMode = false; p.InvulnerableTime = 0f;
            tg.TestSpawnObstacle(ObstacleKind.MineCart, p.Lane, p.transform.position.z + 6f);
            yield return Wait(1f);
            Check("Obstacle collision kills player", p.IsDead);
            yield return Wait(1.3f);
            Check("Game Over screen shown", gm.State == GameState.GameOver && UIManager.Instance.GameOverPanel.activeSelf);
            Check("High score persisted", SaveSystem.BestScore == Mathf.Max(savedBest, gm.ScoreInt) && PlayerPrefs.GetInt("TH_BestScore") == SaveSystem.BestScore);

            // revive
            SaveSystem.Gems = gm.ReviveCost;
            float zDead = p.transform.position.z;
            bool revived = gm.Revive();
            Check("Revive accepted with enough gems (gems spent)", revived && SaveSystem.Gems == 0);
            yield return new WaitForSecondsRealtime(2.3f);
            Check("Revive resumes gameplay", gm.State == GameState.Playing && !p.IsDead && p.transform.position.y == 0f);
            yield return Wait(1f);
            Check("Revived player keeps running safely", gm.State == GameState.Playing && p.transform.position.z > zDead + 5f);
            p.ForceDeath();
            yield return Wait(1.4f);
            Check("Revive refused without gems", !gm.Revive() && gm.State == GameState.GameOver);

            // fall into a gap
            gm.Retry();
            tg.SpawnHazards = false; tg.ResetTrack();
            yield return null;
            Check("Retry restarts run", gm.State == GameState.Playing && gm.Distance < 2f && !p.IsDead);
            p.InvulnerableTime = 0f;
            yield return Wait(0.3f);
            tg.TestSpawnObstacle(ObstacleKind.Gap, p.Lane, p.transform.position.z + 6f);
            yield return Wait(1.2f);
            Check("Falling into a gap ends the run", p.IsDead && gm.LastDeath == DeathCause.Fall);
            yield return Wait(1.2f);

            gm.GoHome();
            yield return null;
            Check("Home returns to main menu", gm.State == GameState.Menu && UIManager.Instance.MenuPanel.activeSelf);

            // full random run with hazards on: generator must produce obstacles
            tg.SpawnHazards = true;
            int obs0 = tg.ObstaclesSpawned;
            gm.StartRun();
            p.GodMode = true;
            yield return Wait(3f);
            Check("Procedural obstacles spawned", tg.ObstaclesSpawned > obs0, (tg.ObstaclesSpawned - obs0) + " spawned");
            Check("Object pools reuse instances", tg.ObstaclePool.Reused + tg.CollectiblePool.Reused > 0);
            p.GodMode = false;
            gm.GoHome();

            // restore progress
            GameConfig.DurationScale = 1f;
            SaveSystem.BestScore = savedBest; SaveSystem.Coins = savedCoins; SaveSystem.Gems = savedGems; SaveSystem.Keys = savedKeys;
            SaveSystem.Save();

            var sb = new StringBuilder();
            sb.AppendLine("Treasure Hunt: Lost Cave - Play Mode smoke test");
            sb.AppendLine("Unity " + Application.unityVersion + "  |  " + System.DateTime.Now);
            sb.AppendLine("Result: " + pass + " passed, " + fail + " failed");
            sb.AppendLine();
            foreach (var l in lines) sb.AppendLine(l);
            try { File.WriteAllText(Path.Combine(Path.GetDirectoryName(Application.dataPath), ResultFile), sb.ToString()); }
            catch (System.Exception e) { Debug.LogWarning("Could not write results: " + e.Message); }
            Debug.Log("[TH-TEST] DONE: " + pass + " passed, " + fail + " failed");
            AllPassed = fail == 0;
            Finished = true;
        }
    }
}
