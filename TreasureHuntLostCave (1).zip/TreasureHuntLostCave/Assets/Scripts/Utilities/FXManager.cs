using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Shared particle systems driven with Emit() — no per-effect GameObjects, no allocations.</summary>
    public class FXManager : MonoBehaviour
    {
        public static FXManager Instance { get; private set; }

        ParticleSystem sparkle, burst, debris, dust, speedLines, splash;

        void Awake()
        {
            Instance = this;
            sparkle = Make("Sparkle", 300, 0.5f, 0.9f, 2f, 5f, 0.08f, 0.22f, 0f, MaterialLibrary.Get(Mat.Particle), 0.4f);
            burst = Make("Burst", 200, 0.7f, 1.3f, 4f, 9f, 0.15f, 0.4f, 0.6f, MaterialLibrary.Get(Mat.Particle), 0.6f);
            debris = Make("Debris", 120, 0.8f, 1.4f, 3f, 8f, 0.15f, 0.4f, 2.5f, MaterialLibrary.Get(Mat.RockWall), 0.5f);
            var dr = debris.GetComponent<ParticleSystemRenderer>();
            dr.renderMode = ParticleSystemRenderMode.Mesh;
            dr.mesh = MeshFactory.Rock(2);
            var dm = debris.main; dm.startRotation3D = true;
            dm.startRotationX = new ParticleSystem.MinMaxCurve(0f, 6f);
            dm.startRotationY = new ParticleSystem.MinMaxCurve(0f, 6f);
            dm.startRotationZ = new ParticleSystem.MinMaxCurve(0f, 6f);
            splash = Make("Splash", 120, 0.5f, 0.9f, 3f, 6f, 0.1f, 0.3f, 1.5f, MaterialLibrary.Get(Mat.Particle), 0.3f);
        }

        /// <summary>Ambient falling dust that follows the camera.</summary>
        public void AttachCameraEffects(Transform cam)
        {
            dust = Make("FallingDust", 260, 5f, 8f, 0.05f, 0.25f, 0.03f, 0.08f, 0.02f, MaterialLibrary.Get(Mat.Particle), 0.4f);
            dust.transform.SetParent(cam, false);
            dust.transform.localPosition = new Vector3(0f, 2f, 16f);
            var sh = dust.shape; sh.enabled = true; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(16f, 8f, 26f);
            var em = dust.emission; em.enabled = true; em.rateOverTime = 30f;
            var m = dust.main; m.startColor = new Color(1f, 0.9f, 0.7f, 0.5f);
            dust.Play();

            speedLines = Make("SpeedLines", 120, 0.25f, 0.4f, 25f, 35f, 0.04f, 0.07f, 0f, MaterialLibrary.Get(Mat.Particle), 0.2f);
            speedLines.transform.SetParent(cam, false);
            speedLines.transform.localPosition = new Vector3(0f, 0f, 14f);
            speedLines.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            var ssh = speedLines.shape; ssh.enabled = true; ssh.shapeType = ParticleSystemShapeType.Box; ssh.scale = new Vector3(9f, 6f, 1f);
            var sm = speedLines.main; sm.simulationSpace = ParticleSystemSimulationSpace.Local; sm.startColor = new Color(1f, 0.8f, 0.45f, 0.8f);
            var sr = speedLines.GetComponent<ParticleSystemRenderer>();
            sr.renderMode = ParticleSystemRenderMode.Stretch; sr.velocityScale = 0.06f; sr.lengthScale = 2f;
            var sem = speedLines.emission; sem.enabled = true; sem.rateOverTime = 0f;
            speedLines.Play();
        }

        public void SetSpeedLines(bool on)
        {
            if (speedLines == null) return;
            var em = speedLines.emission; em.rateOverTime = on ? 70f : 0f;
        }

        ParticleSystem Make(string name, int max, float lifeMin, float lifeMax, float speedMin, float speedMax,
            float sizeMin, float sizeMax, float gravity, Material mat, float shapeRadius)
        {
            var go = new GameObject("FX_" + name);
            go.transform.SetParent(transform, false);
            var ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var m = ps.main;
            m.loop = true;
            m.playOnAwake = false;
            m.maxParticles = max;
            m.startLifetime = new ParticleSystem.MinMaxCurve(lifeMin, lifeMax);
            m.startSpeed = new ParticleSystem.MinMaxCurve(speedMin, speedMax);
            m.startSize = new ParticleSystem.MinMaxCurve(sizeMin, sizeMax);
            m.gravityModifier = gravity;
            m.simulationSpace = ParticleSystemSimulationSpace.World;
            var em = ps.emission; em.enabled = false;
            var sh = ps.shape; sh.enabled = true; sh.shapeType = ParticleSystemShapeType.Sphere; sh.radius = shapeRadius;
            var col = ps.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(1f, 0.6f), new GradientAlphaKey(0f, 1f) });
            col.color = g;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = mat;
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = false;
            ps.Play();
            return ps;
        }

        static void Emit(ParticleSystem ps, Vector3 pos, Color c, int count)
        {
            if (ps == null) return;
            var ep = new ParticleSystem.EmitParams();
            ep.position = pos;
            ep.applyShapeToPosition = true;
            ep.startColor = c;
            ps.Emit(ep, count);
        }

        public void Sparkle(Vector3 pos, Color c, int count) { Emit(sparkle, pos, c, count); }
        public void Burst(Vector3 pos, Color c, int count) { Emit(burst, pos, c, count); }
        public void Debris(Vector3 pos, int count) { Emit(debris, pos, new Color(0.6f, 0.55f, 0.5f), count); Emit(burst, pos, new Color(0.7f, 0.6f, 0.5f, 0.6f), count); }
        public void Splash(Vector3 pos, int count) { Emit(splash, pos, new Color(0.6f, 0.9f, 1f, 0.8f), count); }

        /// <summary>Looping flame used by torches/braziers (one small system per torch).</summary>
        public static ParticleSystem CreateFlame(Transform parent, Vector3 pos, float scale)
        {
            var go = new GameObject("Flame");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localRotation = Quaternion.Euler(-90f, 0f, 0f);
            var ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var m = ps.main;
            m.loop = true; m.playOnAwake = true; m.maxParticles = 30;
            m.startLifetime = new ParticleSystem.MinMaxCurve(0.35f, 0.6f);
            m.startSpeed = new ParticleSystem.MinMaxCurve(1.2f * scale, 2f * scale);
            m.startSize = new ParticleSystem.MinMaxCurve(0.3f * scale, 0.55f * scale);
            m.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.55f, 0.1f), new Color(1f, 0.85f, 0.3f));
            m.simulationSpace = ParticleSystemSimulationSpace.Local;
            var em = ps.emission; em.rateOverTime = 22f;
            var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Cone; sh.angle = 12f; sh.radius = 0.12f * scale;
            var sz = ps.sizeOverLifetime; sz.enabled = true; sz.size = new ParticleSystem.MinMaxCurve(1f, AnimationCurve.Linear(0f, 1f, 1f, 0.2f));
            var col = ps.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(new Color(1f, 0.3f, 0.05f), 1f) },
                      new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0f, 1f) });
            col.color = g;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = MaterialLibrary.Get(Mat.Particle);
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            ps.Play();
            return ps;
        }

        /// <summary>Looping soft particles (waterfall mist, falling pebbles, sparkles around crystals).</summary>
        public static ParticleSystem CreateAmbient(Transform parent, Vector3 pos, Vector3 boxSize, Color color, float rate,
            float speed, float size, float gravity, float life, Material mat)
        {
            var go = new GameObject("Ambient");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            var ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var m = ps.main;
            m.loop = true; m.playOnAwake = true; m.maxParticles = 60;
            m.startLifetime = new ParticleSystem.MinMaxCurve(life * 0.7f, life);
            m.startSpeed = new ParticleSystem.MinMaxCurve(speed * 0.5f, speed);
            m.startSize = new ParticleSystem.MinMaxCurve(size * 0.6f, size);
            m.startColor = color;
            m.gravityModifier = gravity;
            m.simulationSpace = ParticleSystemSimulationSpace.Local;
            var em = ps.emission; em.rateOverTime = rate;
            var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = boxSize;
            var col = ps.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(1f, 0.2f), new GradientAlphaKey(0f, 1f) });
            col.color = g;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = mat;
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            ps.Play();
            return ps;
        }
    }
}
