using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace TreasureHunt
{
    /// <summary>Small helpers for building geometry from code (works in Play Mode and in the Editor).</summary>
    public static class Util
    {
        public static void Kill(Object o)
        {
            if (o == null) return;
            if (Application.isPlaying) Object.Destroy(o); else Object.DestroyImmediate(o);
        }

        public static GameObject Node(string name, Transform parent, Vector3 localPos)
        {
            var g = new GameObject(name);
            g.transform.SetParent(parent, false);
            g.transform.localPosition = localPos;
            return g;
        }

        public static GameObject Prim(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Material mat)
        {
            return Prim(type, parent, pos, scale, mat, Vector3.zero);
        }

        public static GameObject Prim(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Material mat, Vector3 euler)
        {
            var g = GameObject.CreatePrimitive(type);
            var c = g.GetComponent<Collider>();
            if (c != null) Object.DestroyImmediate(c);
            Place(g.transform, parent, pos, scale, euler);
            SetupRenderer(g.GetComponent<MeshRenderer>(), mat);
            return g;
        }

        public static GameObject MeshObj(Mesh mesh, Transform parent, Vector3 pos, Vector3 scale, Material mat, Vector3 euler)
        {
            var g = new GameObject(mesh.name);
            g.AddComponent<MeshFilter>().sharedMesh = mesh;
            SetupRenderer(g.AddComponent<MeshRenderer>(), mat);
            Place(g.transform, parent, pos, scale, euler);
            return g;
        }

        static void Place(Transform t, Transform parent, Vector3 pos, Vector3 scale, Vector3 euler)
        {
            t.SetParent(parent, false);
            t.localPosition = pos;
            t.localEulerAngles = euler;
            t.localScale = scale;
        }

        static void SetupRenderer(MeshRenderer r, Material mat)
        {
            r.sharedMaterial = mat;
            r.shadowCastingMode = ShadowCastingMode.Off;
            r.receiveShadows = false;
            r.lightProbeUsage = LightProbeUsage.Off;
            r.reflectionProbeUsage = ReflectionProbeUsage.Off;
        }

        public static Light PointLight(Transform parent, Vector3 pos, Color c, float range, float intensity)
        {
            var g = Node("Light", parent, pos);
            var l = g.AddComponent<Light>();
            l.type = LightType.Point;
            l.color = c;
            l.range = range;
            l.intensity = intensity;
            l.shadows = LightShadows.None;
            l.renderMode = LightRenderMode.Auto;
            return l;
        }

        /// <summary>Merges every static mesh under the container into one mesh per material (big draw-call saving on mobile).</summary>
        public static void CombineStatic(Transform container)
        {
            var filters = container.GetComponentsInChildren<MeshFilter>(true);
            var groups = new Dictionary<Material, List<CombineInstance>>();
            var order = new List<Material>();
            Matrix4x4 toLocal = container.worldToLocalMatrix;
            var toKill = new List<GameObject>();
            foreach (var mf in filters)
            {
                var mr = mf.GetComponent<MeshRenderer>();
                if (mr == null || mf.sharedMesh == null || mr.sharedMaterial == null) continue;
                List<CombineInstance> list;
                if (!groups.TryGetValue(mr.sharedMaterial, out list))
                {
                    list = new List<CombineInstance>();
                    groups[mr.sharedMaterial] = list;
                    order.Add(mr.sharedMaterial);
                }
                var ci = new CombineInstance();
                ci.mesh = mf.sharedMesh;
                ci.subMeshIndex = 0;
                ci.transform = toLocal * mf.transform.localToWorldMatrix;
                list.Add(ci);
                toKill.Add(mf.gameObject);
            }
            foreach (var mat in order)
            {
                var mesh = new Mesh();
                mesh.name = "Combined_" + mat.name;
                mesh.indexFormat = IndexFormat.UInt32;
                mesh.CombineMeshes(groups[mat].ToArray(), true, true);
                mesh.RecalculateBounds();
                var g = new GameObject(mesh.name);
                g.transform.SetParent(container, false);
                g.AddComponent<MeshFilter>().sharedMesh = mesh;
                SetupRenderer(g.AddComponent<MeshRenderer>(), mat);
            }
            for (int i = toKill.Count - 1; i >= 0; i--)
            {
                var g = toKill[i];
                if (g == null) continue;
                g.SetActive(false);
                Kill(g);
            }
        }

        static Font font;
        public static Font UIFont
        {
            get
            {
                if (font != null) return font;
                try { font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { font = null; }
                if (font == null)
                {
                    try { font = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { font = null; }
                }
                if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 32);
                return font;
            }
        }

        public static float R(float a, float b) { return Random.Range(a, b); }
        public static int Ri(int a, int bExclusive) { return Random.Range(a, bExclusive); }
        public static bool Chance(float p) { return Random.value < p; }
        public static float Side() { return Random.value < 0.5f ? -1f : 1f; }
    }
}
