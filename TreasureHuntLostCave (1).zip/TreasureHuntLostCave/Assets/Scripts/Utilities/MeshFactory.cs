using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Procedural low-poly meshes (cones, crystals, gems, rocks). Cached and shared.</summary>
    public static class MeshFactory
    {
        static readonly Dictionary<string, Mesh> cache = new Dictionary<string, Mesh>();
        public static IEnumerable<Mesh> All { get { return cache.Values; } }

        public static Mesh Cone(int sides)
        {
            string key = "TH_Cone" + sides;
            Mesh m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            var t = new List<Vector3>();
            var apex = new Vector3(0, 1, 0);
            for (int i = 0; i < sides; i++)
            {
                Vector3 a = Ring(i, sides, 0.5f, 0f), b = Ring(i + 1, sides, 0.5f, 0f);
                Tri(t, a, b, apex);
                Tri(t, Vector3.zero, b, a);
            }
            return Store(key, Build(key, t, new Vector3(0, 0.3f, 0)));
        }

        public static Mesh Crystal()
        {
            const string key = "TH_Crystal";
            Mesh m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            var t = new List<Vector3>();
            int s = 6;
            var apex = new Vector3(0, 1f, 0);
            for (int i = 0; i < s; i++)
            {
                Vector3 b0 = Ring(i, s, 0.32f, 0f), b1 = Ring(i + 1, s, 0.32f, 0f);
                Vector3 u0 = Ring(i, s, 0.4f, 0.65f), u1 = Ring(i + 1, s, 0.4f, 0.65f);
                Tri(t, b0, b1, u1); Tri(t, b0, u1, u0);
                Tri(t, u0, u1, apex);
                Tri(t, Vector3.zero, b1, b0);
            }
            return Store(key, Build(key, t, new Vector3(0, 0.45f, 0)));
        }

        public static Mesh Gem()
        {
            const string key = "TH_Gem";
            Mesh m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            var t = new List<Vector3>();
            var top = new Vector3(0, 0.6f, 0); var bot = new Vector3(0, -0.6f, 0);
            int s = 6;
            for (int i = 0; i < s; i++)
            {
                Vector3 a = Ring(i, s, 0.45f, 0.1f), b = Ring(i + 1, s, 0.45f, 0.1f);
                Tri(t, a, b, top); Tri(t, b, a, bot);
            }
            return Store(key, Build(key, t, Vector3.zero));
        }

        /// <summary>Jagged boulder, radius ~0.5. Five variants.</summary>
        public static Mesh Rock(int variant)
        {
            variant = Mathf.Abs(variant) % 5;
            string key = "TH_Rock" + variant;
            Mesh m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            var dirs = new List<Vector3>
            {
                Vector3.right, Vector3.left, Vector3.up, Vector3.down, Vector3.forward, Vector3.back
            };
            var faces = new List<Vector3>();
            int[,] f = { { 2, 4, 0 }, { 2, 0, 5 }, { 2, 5, 1 }, { 2, 1, 4 }, { 3, 0, 4 }, { 3, 5, 0 }, { 3, 1, 5 }, { 3, 4, 1 } };
            for (int i = 0; i < 8; i++) Tri(faces, dirs[f[i, 0]], dirs[f[i, 1]], dirs[f[i, 2]], Vector3.zero, true);
            for (int level = 0; level < 2; level++)
            {
                var next = new List<Vector3>();
                for (int i = 0; i < faces.Count; i += 3)
                {
                    Vector3 a = faces[i], b = faces[i + 1], c = faces[i + 2];
                    Vector3 ab = (a + b).normalized, bc = (b + c).normalized, ca = (c + a).normalized;
                    next.Add(a); next.Add(ab); next.Add(ca);
                    next.Add(ab); next.Add(b); next.Add(bc);
                    next.Add(ca); next.Add(bc); next.Add(c);
                    next.Add(ab); next.Add(bc); next.Add(ca);
                }
                faces = next;
            }
            float seed = 13.7f * (variant + 1);
            for (int i = 0; i < faces.Count; i++)
            {
                Vector3 p = faces[i];
                float n = Mathf.PerlinNoise(p.x * 1.6f + seed, p.y * 1.6f + p.z * 1.3f + seed * 0.37f);
                float r = 0.5f * (0.78f + 0.45f * n);
                faces[i] = new Vector3(p.x * r, p.y * r * 0.85f, p.z * r);
            }
            return Store(key, Build(key, faces, Vector3.zero, false));
        }

        static Vector3 Ring(int i, int sides, float radius, float y)
        {
            float a = (i % sides) * Mathf.PI * 2f / sides;
            return new Vector3(Mathf.Cos(a) * radius, y, Mathf.Sin(a) * radius);
        }

        static void Tri(List<Vector3> t, Vector3 a, Vector3 b, Vector3 c) { t.Add(a); t.Add(b); t.Add(c); }

        static void Tri(List<Vector3> t, Vector3 a, Vector3 b, Vector3 c, Vector3 center, bool fix)
        {
            if (fix && Vector3.Dot(Vector3.Cross(b - a, c - a), (a + b + c) / 3f - center) < 0f) { var tmp = b; b = c; c = tmp; }
            t.Add(a); t.Add(b); t.Add(c);
        }

        static Mesh Store(string key, Mesh m) { cache[key] = m; return m; }

        static Mesh Build(string name, List<Vector3> tris, Vector3 center, bool fixWinding = true)
        {
            int n = tris.Count;
            var v = new Vector3[n];
            var uv = new Vector2[n];
            var idx = new int[n];
            for (int i = 0; i < n; i += 3)
            {
                Vector3 a = tris[i], b = tris[i + 1], c = tris[i + 2];
                if (fixWinding && Vector3.Dot(Vector3.Cross(b - a, c - a), (a + b + c) / 3f - center) < 0f) { var tmp = b; b = c; c = tmp; }
                v[i] = a; v[i + 1] = b; v[i + 2] = c;
            }
            for (int i = 0; i < n; i++)
            {
                idx[i] = i;
                uv[i] = new Vector2(v[i].x + v[i].z, v[i].y + v[i].z * 0.5f);
            }
            var m = new Mesh();
            m.name = name;
            m.vertices = v;
            m.uv = uv;
            m.triangles = idx;
            m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }
    }
}
