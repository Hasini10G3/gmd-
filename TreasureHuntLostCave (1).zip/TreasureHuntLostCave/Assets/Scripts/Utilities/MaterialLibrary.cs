using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace TreasureHunt
{
    /// <summary>Material keys used across the game.</summary>
    public static class Mat
    {
        public const string RockWall = "RockWall", RockDark = "RockDark", Floor = "Floor", FloorRuins = "FloorRuins", FloorDark = "FloorDark",
            LaneLine = "LaneLine", EdgeBlue = "EdgeGlowBlue", EdgeGold = "EdgeGlowGold", EdgeGreen = "EdgeGlowGreen",
            RuinStone = "RuinStone", RuinStoneDark = "RuinStoneDark", Wood = "Wood", WoodDark = "WoodDark", Metal = "Metal", Rust = "Rust",
            CrystalBlue = "CrystalBlue", CrystalPurple = "CrystalPurple", CrystalTeal = "CrystalTeal", Biolum = "Bioluminescent",
            Fire = "Fire", Gold = "Gold", GoldPile = "GoldPile", Water = "Water", Waterfall = "Waterfall",
            RuneBlue = "RuneBlue", RuneOrange = "RuneOrange", Pit = "Pit", Warning = "Warning", ShadowBlob = "ShadowBlob",
            Guard = "GuardStone", GuardEyes = "GuardEyes", ChestWood = "ChestWood", Cloth = "Cloth", Shirt = "Shirt", Skin = "Skin",
            Hat = "Hat", Leather = "Leather", Boots = "Boots", Lamp = "Lamp", Relic = "Relic", Artifact = "Artifact",
            Shield = "ShieldBubble", Bubble = "PickupBubble", Particle = "ParticleAdditive",
            PowerMagnet = "PowerMagnet", PowerSpeed = "PowerSpeed", PowerMulti = "PowerMulti", PowerVision = "PowerVision", Silver = "Silver";

        public static readonly string[] All =
        {
            RockWall, RockDark, Floor, FloorRuins, FloorDark, LaneLine, EdgeBlue, EdgeGold, EdgeGreen, RuinStone, RuinStoneDark,
            Wood, WoodDark, Metal, Rust, CrystalBlue, CrystalPurple, CrystalTeal, Biolum, Fire, Gold, GoldPile, Water, Waterfall,
            RuneBlue, RuneOrange, Pit, Warning, ShadowBlob, Guard, GuardEyes, ChestWood, Cloth, Shirt, Skin, Hat, Leather, Boots,
            Lamp, Relic, Artifact, Shield, Bubble, Particle, PowerMagnet, PowerSpeed, PowerMulti, PowerVision, Silver
        };
    }

    /// <summary>
    /// Creates every material from code (original procedural textures, no external assets).
    /// If the Editor builder exported them to Assets/Materials/Resources/TH, those assets are used instead
    /// (this guarantees shader variants are included in Android builds).
    /// </summary>
    public static class MaterialLibrary
    {
        static readonly Dictionary<string, Material> cache = new Dictionary<string, Material>();
        static Shader standard;
        static Texture2D rockTex, tileTex, waterTex, dotTex;

        /// <summary>Set by the Editor builder so it can load exported assets without Resources.</summary>
        public static System.Func<string, Material> EditorLoader;

        public static void ClearCache() { cache.Clear(); }

        public static Material Get(string key)
        {
            Material m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            Material asset = null;
            if (EditorLoader != null && !Application.isPlaying) asset = EditorLoader(key);
            if (asset == null) asset = Resources.Load<Material>("TH/" + key);
            if (asset != null) m = Application.isPlaying ? new Material(asset) { name = key } : asset;
            else m = CreateFresh(key);
            cache[key] = m;
            return m;
        }

        public static Shader StandardShader
        {
            get
            {
                if (standard == null) standard = Shader.Find("Standard");
                if (standard == null)
                {
                    var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    standard = g.GetComponent<Renderer>().sharedMaterial.shader;
                    Object.DestroyImmediate(g);
                }
                return standard;
            }
        }

        public static Material CreateFresh(string key)
        {
            switch (key)
            {
                case Mat.RockWall: return Opaque(key, new Color(0.36f, 0.32f, 0.33f), 0.15f, 0f, RockTex, new Vector2(2, 2));
                case Mat.RockDark: return Opaque(key, new Color(0.2f, 0.19f, 0.22f), 0.1f, 0f, RockTex, new Vector2(3, 3));
                case Mat.Floor: return Opaque(key, new Color(0.58f, 0.54f, 0.5f), 0.25f, 0f, TileTex, new Vector2(3, 10));
                case Mat.FloorRuins: return Opaque(key, new Color(0.72f, 0.6f, 0.43f), 0.2f, 0f, TileTex, new Vector2(3, 10));
                case Mat.FloorDark: return Opaque(key, new Color(0.42f, 0.38f, 0.36f), 0.2f, 0f, TileTex, new Vector2(3, 10));
                case Mat.LaneLine: return Opaque(key, new Color(0.08f, 0.07f, 0.07f), 0f, 0f, null, Vector2.one);
                case Mat.EdgeBlue: return Emissive(key, new Color(0.1f, 0.35f, 0.5f), new Color(0.25f, 0.85f, 1.5f));
                case Mat.EdgeGold: return Emissive(key, new Color(0.5f, 0.3f, 0.1f), new Color(1.4f, 0.75f, 0.2f));
                case Mat.EdgeGreen: return Emissive(key, new Color(0.15f, 0.45f, 0.2f), new Color(0.35f, 1.3f, 0.5f));
                case Mat.RuinStone: return Opaque(key, new Color(0.68f, 0.58f, 0.44f), 0.15f, 0f, RockTex, new Vector2(1, 2));
                case Mat.RuinStoneDark: return Opaque(key, new Color(0.44f, 0.37f, 0.3f), 0.1f, 0f, RockTex, new Vector2(1, 2));
                case Mat.Wood: return Opaque(key, new Color(0.46f, 0.3f, 0.17f), 0.2f, 0f, RockTex, new Vector2(0.5f, 3));
                case Mat.WoodDark: return Opaque(key, new Color(0.27f, 0.17f, 0.1f), 0.15f, 0f, RockTex, new Vector2(0.5f, 3));
                case Mat.Metal: return Opaque(key, new Color(0.5f, 0.5f, 0.54f), 0.55f, 0.8f, null, Vector2.one);
                case Mat.Silver: return Emissive(key, new Color(0.85f, 0.88f, 0.92f), new Color(0.25f, 0.25f, 0.3f), 0.8f, 0.9f);
                case Mat.Rust: return Opaque(key, new Color(0.48f, 0.27f, 0.15f), 0.3f, 0.3f, RockTex, Vector2.one);
                case Mat.CrystalBlue: return Emissive(key, new Color(0.2f, 0.55f, 1f), new Color(0.15f, 0.6f, 1.5f), 0.9f);
                case Mat.CrystalPurple: return Emissive(key, new Color(0.6f, 0.25f, 1f), new Color(0.8f, 0.25f, 1.5f), 0.9f);
                case Mat.CrystalTeal: return Emissive(key, new Color(0.2f, 0.9f, 0.8f), new Color(0.1f, 0.95f, 0.75f), 0.9f);
                case Mat.Biolum: return Emissive(key, new Color(0.3f, 0.9f, 0.35f), new Color(0.25f, 1.3f, 0.4f));
                case Mat.Fire: return Emissive(key, new Color(1f, 0.55f, 0.1f), new Color(2.4f, 1.1f, 0.25f));
                case Mat.Gold: return Emissive(key, new Color(1f, 0.78f, 0.25f), new Color(0.6f, 0.4f, 0.06f), 0.75f, 0.9f);
                case Mat.GoldPile: return Emissive(key, new Color(0.95f, 0.72f, 0.2f), new Color(0.35f, 0.22f, 0.03f), 0.6f, 0.85f);
                case Mat.Water: return Transparent(key, new Color(0.12f, 0.5f, 0.6f, 0.75f), new Color(0.03f, 0.16f, 0.2f), WaterTex, new Vector2(1, 4), true);
                case Mat.Waterfall: return Transparent(key, new Color(0.65f, 0.88f, 1f, 0.7f), new Color(0.2f, 0.38f, 0.45f), WaterTex, new Vector2(1, 2), true);
                case Mat.RuneBlue: return Emissive(key, new Color(0.05f, 0.2f, 0.3f), new Color(0.2f, 1f, 1.8f));
                case Mat.RuneOrange: return Emissive(key, new Color(0.3f, 0.12f, 0.02f), new Color(1.8f, 0.7f, 0.12f));
                case Mat.Pit: return Opaque(key, new Color(0.01f, 0.01f, 0.015f), 0f, 0f, null, Vector2.one);
                case Mat.Warning: return Transparent(key, new Color(1f, 0.12f, 0.05f, 0.55f), new Color(1.3f, 0.12f, 0.05f), DotTex, Vector2.one, false);
                case Mat.ShadowBlob: return Transparent(key, new Color(0f, 0f, 0f, 0.6f), Color.black, DotTex, Vector2.one, false);
                case Mat.Guard: return Opaque(key, new Color(0.46f, 0.5f, 0.44f), 0.15f, 0f, RockTex, Vector2.one);
                case Mat.GuardEyes: return Emissive(key, new Color(1f, 0.1f, 0.05f), new Color(2.5f, 0.2f, 0.1f));
                case Mat.ChestWood: return Opaque(key, new Color(0.5f, 0.27f, 0.11f), 0.3f, 0f, RockTex, new Vector2(0.5f, 2));
                case Mat.Cloth: return Opaque(key, new Color(0.7f, 0.6f, 0.42f), 0.1f, 0f, null, Vector2.one);
                case Mat.Shirt: return Opaque(key, new Color(0.38f, 0.46f, 0.32f), 0.1f, 0f, null, Vector2.one);
                case Mat.Skin: return Opaque(key, new Color(0.87f, 0.65f, 0.5f), 0.3f, 0f, null, Vector2.one);
                case Mat.Hat: return Opaque(key, new Color(0.5f, 0.36f, 0.22f), 0.15f, 0f, null, Vector2.one);
                case Mat.Leather: return Opaque(key, new Color(0.38f, 0.22f, 0.11f), 0.3f, 0f, null, Vector2.one);
                case Mat.Boots: return Opaque(key, new Color(0.22f, 0.14f, 0.08f), 0.3f, 0f, null, Vector2.one);
                case Mat.Lamp: return Emissive(key, new Color(1f, 0.95f, 0.8f), new Color(2.5f, 2.2f, 1.5f));
                case Mat.Relic: return Emissive(key, new Color(0.85f, 1f, 1f), new Color(0.9f, 1.8f, 2f), 0.9f);
                case Mat.Artifact: return Emissive(key, new Color(0.25f, 0.8f, 0.5f), new Color(0.12f, 0.7f, 0.4f), 0.85f, 0.3f);
                case Mat.Shield: return Transparent(key, new Color(0.3f, 0.85f, 1f, 0.28f), new Color(0.12f, 0.45f, 0.7f), null, Vector2.one, true);
                case Mat.Bubble: return Transparent(key, new Color(0.85f, 0.95f, 1f, 0.2f), new Color(0.15f, 0.25f, 0.3f), null, Vector2.one, true);
                case Mat.PowerMagnet: return Emissive(key, new Color(1f, 0.2f, 0.2f), new Color(1.2f, 0.1f, 0.1f));
                case Mat.PowerSpeed: return Emissive(key, new Color(1f, 0.55f, 0.1f), new Color(1.4f, 0.6f, 0.1f));
                case Mat.PowerMulti: return Emissive(key, new Color(1f, 0.9f, 0.2f), new Color(1.4f, 1.2f, 0.2f));
                case Mat.PowerVision: return Emissive(key, new Color(0.3f, 1f, 0.5f), new Color(0.3f, 1.3f, 0.5f));
                case Mat.Particle: return ParticleMat(key);
                default: return Opaque(key, Color.magenta, 0f, 0f, null, Vector2.one);
            }
        }

        static Material Opaque(string name, Color c, float smooth, float metal, Texture2D tex, Vector2 tiling)
        {
            var m = new Material(StandardShader);
            m.name = name;
            m.color = c;
            m.SetFloat("_Glossiness", smooth);
            m.SetFloat("_Metallic", metal);
            if (tex != null) { m.mainTexture = tex; m.mainTextureScale = tiling; }
            m.enableInstancing = true;
            return m;
        }

        static Material Emissive(string name, Color c, Color emission, float smooth = 0.4f, float metal = 0f)
        {
            var m = Opaque(name, c, smooth, metal, null, Vector2.one);
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", emission);
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.None;
            return m;
        }

        static Material Transparent(string name, Color c, Color emission, Texture2D tex, Vector2 tiling, bool premultiplied)
        {
            var m = Opaque(name, c, premultiplied ? 0.95f : 0f, 0f, tex, tiling);
            m.SetFloat("_Mode", premultiplied ? 3f : 2f);
            m.SetInt("_SrcBlend", (int)(premultiplied ? BlendMode.One : BlendMode.SrcAlpha));
            m.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            m.SetInt("_ZWrite", 0);
            m.DisableKeyword("_ALPHATEST_ON");
            if (premultiplied) { m.DisableKeyword("_ALPHABLEND_ON"); m.EnableKeyword("_ALPHAPREMULTIPLY_ON"); }
            else { m.EnableKeyword("_ALPHABLEND_ON"); m.DisableKeyword("_ALPHAPREMULTIPLY_ON"); }
            if (emission != Color.black)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", emission);
                m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.None;
            }
            m.renderQueue = (int)RenderQueue.Transparent;
            return m;
        }

        static Material ParticleMat(string name)
        {
            Shader s = Shader.Find("Legacy Shaders/Particles/Additive");
            if (s == null) s = Shader.Find("Particles/Standard Unlit");
            if (s == null) return Transparent(name, Color.white, Color.white, DotTex, Vector2.one, false);
            var m = new Material(s);
            m.name = name;
            m.mainTexture = DotTex;
            if (m.HasProperty("_TintColor")) m.SetColor("_TintColor", new Color(0.5f, 0.5f, 0.5f, 0.5f));
            return m;
        }

        // ---------- Procedural textures ----------
        public static Texture2D RockTex { get { if (rockTex == null) rockTex = MakeNoise("TH_RockTex", 128, 0.55f, 1f); return rockTex; } }
        public static Texture2D DotTex { get { if (dotTex == null) dotTex = MakeDot("TH_DotTex", 64); return dotTex; } }

        public static Texture2D TileTex
        {
            get
            {
                if (tileTex != null) return tileTex;
                int s = 128;
                var t = NewTex("TH_StoneTiles", s);
                var px = new Color[s * s];
                for (int y = 0; y < s; y++)
                    for (int x = 0; x < s; x++)
                    {
                        int row = y / 32;
                        int xo = (x + (row % 2) * 16) % 32;
                        bool grout = (y % 32) < 2 || xo < 2;
                        float n = 0.75f + 0.25f * Mathf.PerlinNoise(x * 0.11f, y * 0.11f) + 0.08f * (Mathf.PerlinNoise(x * 0.5f, y * 0.5f) - 0.5f);
                        float tileShade = 0.9f + 0.1f * Mathf.PerlinNoise(row * 3.1f, ((x + (row % 2) * 16) / 32) * 2.7f);
                        float v = grout ? 0.35f : n * tileShade;
                        px[y * s + x] = new Color(v, v, v, 1f);
                    }
                t.SetPixels(px); t.Apply(true);
                tileTex = t;
                return tileTex;
            }
        }

        public static Texture2D WaterTex
        {
            get
            {
                if (waterTex != null) return waterTex;
                int s = 128;
                var t = NewTex("TH_WaterTex", s);
                var px = new Color[s * s];
                for (int y = 0; y < s; y++)
                    for (int x = 0; x < s; x++)
                    {
                        float n = Mathf.PerlinNoise(x * 0.18f, y * 0.04f) * 0.6f + Mathf.PerlinNoise(x * 0.05f + 7f, y * 0.12f) * 0.4f;
                        float streak = Mathf.Pow(Mathf.Clamp01(n), 3f) * 1.6f;
                        float v = 0.7f + streak * 0.6f;
                        px[y * s + x] = new Color(v, v, v, 0.85f + 0.15f * n);
                    }
                t.SetPixels(px); t.Apply(true);
                waterTex = t;
                return waterTex;
            }
        }

        static Texture2D NewTex(string name, int s)
        {
            var t = new Texture2D(s, s, TextureFormat.RGBA32, true);
            t.name = name;
            t.wrapMode = TextureWrapMode.Repeat;
            t.filterMode = FilterMode.Bilinear;
            return t;
        }

        static Texture2D MakeNoise(string name, int s, float lo, float hi)
        {
            var t = NewTex(name, s);
            var px = new Color[s * s];
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++)
                {
                    // tileable fractal noise by sampling on a torus-like wrap
                    float n = 0f, amp = 0.5f, freq = 4f;
                    for (int o = 0; o < 4; o++)
                    {
                        float u = x / (float)s, v = y / (float)s;
                        float a = Mathf.PerlinNoise(u * freq, v * freq);
                        float b = Mathf.PerlinNoise((u - 1f) * freq, v * freq);
                        float c = Mathf.PerlinNoise(u * freq, (v - 1f) * freq);
                        float d = Mathf.PerlinNoise((u - 1f) * freq, (v - 1f) * freq);
                        float mix = Mathf.Lerp(Mathf.Lerp(a, b, u), Mathf.Lerp(c, d, u), v);
                        n += mix * amp; amp *= 0.5f; freq *= 2f;
                    }
                    float val = Mathf.Lerp(lo, hi, Mathf.Clamp01(n * 1.1f));
                    px[y * s + x] = new Color(val, val, val, 1f);
                }
            t.SetPixels(px); t.Apply(true);
            return t;
        }

        static Texture2D MakeDot(string name, int s)
        {
            var t = new Texture2D(s, s, TextureFormat.RGBA32, true);
            t.name = name;
            t.wrapMode = TextureWrapMode.Clamp;
            var px = new Color[s * s];
            float h = (s - 1) * 0.5f;
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++)
                {
                    float d = Mathf.Sqrt((x - h) * (x - h) + (y - h) * (y - h)) / h;
                    float a = Mathf.Clamp01(1f - d);
                    a = a * a;
                    px[y * s + x] = new Color(a, a, a, a);
                }
            t.SetPixels(px); t.Apply(true);
            return t;
        }
    }
}
