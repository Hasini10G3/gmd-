using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Builds the original low-poly explorer: khaki outfit, backpack, boots, hat with headlamp, pickaxe.</summary>
    public static class PlayerFactory
    {
        static Material M(string k) { return MaterialLibrary.Get(k); }

        public static GameObject Create()
        {
            var root = new GameObject("Explorer");
            var body = root.AddComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;
            var box = root.AddComponent<BoxCollider>();
            box.center = new Vector3(0, 0.95f, 0);
            box.size = new Vector3(0.7f, 1.7f, 0.6f);

            var anim = root.AddComponent<PlayerAnimator>();
            var vis = Util.Node("Visual", root.transform, Vector3.zero).transform;
            anim.visual = vis;
            var torso = Util.Node("Body", vis, Vector3.zero).transform;
            anim.body = torso;

            // legs (pivot at hips)
            anim.legL = Leg(vis, -0.15f);
            anim.legR = Leg(vis, 0.15f);
            // hips, torso, belt
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0, 0.98f, 0), new Vector3(0.46f, 0.22f, 0.28f), M(Mat.Cloth));
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0, 1.3f, 0), new Vector3(0.5f, 0.56f, 0.3f), M(Mat.Shirt));
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0, 1.06f, 0), new Vector3(0.5f, 0.07f, 0.32f), M(Mat.Leather));
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0.12f, 1.06f, 0.165f), new Vector3(0.08f, 0.06f, 0.01f), M(Mat.Gold));
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0, 1.3f, 0.12f), new Vector3(0.08f, 0.56f, 0.08f), M(Mat.Leather), new Vector3(0, 0, 35));
            // backpack with bedroll and pickaxe
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0, 1.3f, -0.28f), new Vector3(0.42f, 0.5f, 0.24f), M(Mat.Leather));
            Util.Prim(PrimitiveType.Cylinder, torso, new Vector3(0, 1.6f, -0.28f), new Vector3(0.16f, 0.24f, 0.16f), M(Mat.Cloth), new Vector3(0, 0, 90));
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0, 1.2f, -0.41f), new Vector3(0.3f, 0.18f, 0.04f), M(Mat.Hat));
            Util.Prim(PrimitiveType.Cylinder, torso, new Vector3(0.22f, 1.35f, -0.43f), new Vector3(0.035f, 0.38f, 0.035f), M(Mat.Wood), new Vector3(0, 0, 18));
            Util.Prim(PrimitiveType.Cube, torso, new Vector3(0.33f, 1.7f, -0.43f), new Vector3(0.4f, 0.06f, 0.06f), M(Mat.Metal), new Vector3(0, 0, 18));
            // arms (pivot at shoulders)
            anim.armL = Arm(vis, -0.33f);
            anim.armR = Arm(vis, 0.33f);
            // head, hat, headlamp
            var head = Util.Node("Head", vis, new Vector3(0, 1.66f, 0)).transform;
            anim.head = head;
            Util.Prim(PrimitiveType.Cube, head, new Vector3(0, 0.02f, 0), new Vector3(0.12f, 0.1f, 0.12f), M(Mat.Skin));
            Util.Prim(PrimitiveType.Sphere, head, new Vector3(0, 0.16f, 0), new Vector3(0.32f, 0.34f, 0.32f), M(Mat.Skin));
            Util.Prim(PrimitiveType.Cube, head, new Vector3(0, 0.12f, 0.15f), new Vector3(0.05f, 0.08f, 0.06f), M(Mat.Skin));
            Util.Prim(PrimitiveType.Cylinder, head, new Vector3(0, 0.29f, 0), new Vector3(0.52f, 0.02f, 0.52f), M(Mat.Hat));
            Util.Prim(PrimitiveType.Cylinder, head, new Vector3(0, 0.37f, 0), new Vector3(0.3f, 0.08f, 0.3f), M(Mat.Hat));
            Util.Prim(PrimitiveType.Cylinder, head, new Vector3(0, 0.31f, 0), new Vector3(0.31f, 0.02f, 0.31f), M(Mat.Leather));
            Util.Prim(PrimitiveType.Cylinder, head, new Vector3(0, 0.33f, 0.16f), new Vector3(0.11f, 0.03f, 0.11f), M(Mat.Lamp), new Vector3(90, 0, 0));
            var lampGo = Util.Node("Headlamp", head, new Vector3(0, 0.36f, 0.2f));
            lampGo.transform.localRotation = Quaternion.Euler(16f, 0f, 0f);
            var lamp = lampGo.AddComponent<Light>();
            lamp.type = LightType.Spot;
            lamp.range = 26f;
            lamp.spotAngle = 72f;
            lamp.intensity = 2.6f;
            lamp.color = new Color(1f, 0.95f, 0.82f);
            lamp.renderMode = LightRenderMode.ForcePixel;
            lamp.shadows = LightShadows.None;
            // soft glow around the explorer so they stay readable in dark tunnels
            var glow = Util.PointLight(root.transform, new Vector3(0, 2.6f, -1.2f), new Color(1f, 0.85f, 0.65f), 7f, 0.9f);
            glow.renderMode = LightRenderMode.ForcePixel;
            // blob shadow
            Util.Prim(PrimitiveType.Quad, root.transform, new Vector3(0, 0.02f, 0), new Vector3(1.1f, 1.1f, 1f), M(Mat.ShadowBlob), new Vector3(90, 0, 0)).name = "BlobShadow";

            root.AddComponent<PowerUpVisuals>().Build();
            root.AddComponent<PlayerController>();
            return root;
        }

        static Transform Leg(Transform vis, float x)
        {
            var pivot = Util.Node(x < 0 ? "LegL" : "LegR", vis, new Vector3(x, 0.95f, 0)).transform;
            Util.Prim(PrimitiveType.Capsule, pivot, new Vector3(0, -0.42f, 0), new Vector3(0.2f, 0.4f, 0.2f), M(Mat.Cloth));
            Util.Prim(PrimitiveType.Cube, pivot, new Vector3(0, -0.84f, 0.05f), new Vector3(0.22f, 0.2f, 0.34f), M(Mat.Boots));
            Util.Prim(PrimitiveType.Cube, pivot, new Vector3(0, -0.72f, 0), new Vector3(0.23f, 0.06f, 0.23f), M(Mat.Leather));
            return pivot;
        }

        static Transform Arm(Transform vis, float x)
        {
            var pivot = Util.Node(x < 0 ? "ArmL" : "ArmR", vis, new Vector3(x, 1.52f, 0)).transform;
            Util.Prim(PrimitiveType.Sphere, pivot, Vector3.zero, Vector3.one * 0.17f, M(Mat.Shirt));
            Util.Prim(PrimitiveType.Capsule, pivot, new Vector3(0, -0.28f, 0), new Vector3(0.14f, 0.28f, 0.14f), M(Mat.Shirt));
            Util.Prim(PrimitiveType.Sphere, pivot, new Vector3(0, -0.58f, 0), Vector3.one * 0.13f, M(Mat.Skin));
            return pivot;
        }
    }
}
