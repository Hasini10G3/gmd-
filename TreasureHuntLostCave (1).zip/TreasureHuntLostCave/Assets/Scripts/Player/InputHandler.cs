using UnityEngine;
using UnityEngine.EventSystems;

namespace TreasureHunt
{
    /// <summary>
    /// Keyboard (A/D/arrows, Space/Up, S/Down, Esc) and swipe input (touch on Android, mouse drag in the Editor).
    /// A swipe fires as soon as it passes the threshold, so it feels responsive; one action per touch.
    /// </summary>
    public class InputHandler : MonoBehaviour
    {
        [Tooltip("Minimum swipe distance as a fraction of the screen's shorter side.")]
        public float swipeThreshold = 0.05f;
        [Tooltip("Swipes slower than this (seconds) are ignored.")]
        public float maxSwipeTime = 0.6f;

        bool tracking, consumed;
        int fingerId = -1;
        Vector2 start;
        float startTime;

        float ThresholdPixels { get { return Mathf.Max(30f, Mathf.Min(Screen.width, Screen.height) * swipeThreshold); } }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (gm.State == GameState.Playing) gm.Pause();
                else if (gm.State == GameState.Paused) gm.Resume();
            }

            if (gm.State != GameState.Playing) { tracking = false; return; }
            var p = PlayerController.Instance;
            if (p == null) return;

            if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow)) p.MoveLeft();
            if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) p.MoveRight();
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) p.Jump();
            if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow)) p.Slide();

            if (Input.touchCount > 0) HandleTouches(p);
            else if (Application.isEditor || !Input.touchSupported) HandleMouse(p);
        }

        void HandleTouches(PlayerController p)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                var t = Input.GetTouch(i);
                if (t.phase == TouchPhase.Began)
                {
                    if (tracking) continue;
                    if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(t.fingerId)) continue;
                    Begin(t.position, t.fingerId);
                }
                else if (tracking && t.fingerId == fingerId)
                {
                    if (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary) Check(t.position, p);
                    else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) { Check(t.position, p); tracking = false; }
                }
            }
        }

        void HandleMouse(PlayerController p)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()) return;
                Begin(Input.mousePosition, -100);
            }
            else if (tracking && Input.GetMouseButton(0)) Check(Input.mousePosition, p);
            else if (tracking && Input.GetMouseButtonUp(0)) { Check(Input.mousePosition, p); tracking = false; }
        }

        void Begin(Vector2 pos, int id)
        {
            tracking = true; consumed = false; fingerId = id; start = pos; startTime = Time.unscaledTime;
        }

        void Check(Vector2 pos, PlayerController p)
        {
            if (consumed) return;
            Vector2 d = pos - start;
            if (d.magnitude < ThresholdPixels) return;
            if (Time.unscaledTime - startTime > maxSwipeTime) { consumed = true; return; }
            consumed = true;
            if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) { if (d.x > 0f) p.MoveRight(); else p.MoveLeft(); }
            else { if (d.y > 0f) p.Jump(); else p.Slide(); }
        }
    }
}
