using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Procedural animation for the low-poly explorer: run, jump, slide, idle, death.</summary>
    public class PlayerAnimator : MonoBehaviour
    {
        public Transform visual, body, legL, legR, armL, armR, head;
        Renderer[] renderers;
        float phase, deathT;
        bool dead, fell, visible = true;
        float lastStepSign = 1f;

        void EnsureRenderers()
        {
            if ((renderers == null || renderers.Length == 0) && visual != null) renderers = visual.GetComponentsInChildren<Renderer>(true);
        }

        public void ResetPose()
        {
            dead = false; fell = false; deathT = 0f;
            if (visual == null) return;
            visual.localPosition = Vector3.zero;
            visual.localRotation = Quaternion.identity;
            SetVisible(true);
        }

        public void PlayDeath(bool fall) { dead = true; fell = fall; deathT = 0f; }

        public void SetVisible(bool v)
        {
            if (visible == v) return;
            visible = v;
            EnsureRenderers();
            if (renderers == null) return;
            for (int i = 0; i < renderers.Length; i++) renderers[i].enabled = v;
        }

        static Quaternion X(float a) { return Quaternion.Euler(a, 0f, 0f); }

        /// <summary>Called by PlayerController every frame.</summary>
        public void Tick(float dt, bool running, bool grounded, bool sliding, float speed, float vy)
        {
            if (visual == null) return;
            float k = 1f - Mathf.Exp(-dt * 14f);
            if (dead)
            {
                deathT += dt;
                if (fell)
                {
                    visual.localRotation = Quaternion.Slerp(visual.localRotation, Quaternion.Euler(-20f, 0f, 25f), k);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-170f, 0f, -20f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-170f, 0f, 20f), k);
                }
                else
                {
                    visual.localRotation = Quaternion.Slerp(visual.localRotation, X(-85f), 1f - Mathf.Exp(-dt * 8f));
                    visual.localPosition = Vector3.Lerp(visual.localPosition, new Vector3(0f, 0.25f, -0.6f), k);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-120f, 0f, -30f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-120f, 0f, 30f), k);
                }
                return;
            }

            if (!running)
            {
                // idle breathing / looking around
                float t = Time.time;
                visual.localRotation = Quaternion.Slerp(visual.localRotation, Quaternion.identity, k);
                visual.localPosition = Vector3.Lerp(visual.localPosition, Vector3.zero, k);
                body.localScale = new Vector3(1f, 1f + Mathf.Sin(t * 2f) * 0.015f, 1f);
                legL.localRotation = Quaternion.Slerp(legL.localRotation, Quaternion.identity, k);
                legR.localRotation = Quaternion.Slerp(legR.localRotation, Quaternion.identity, k);
                armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(Mathf.Sin(t * 1.3f) * 4f, 0f, -6f), k);
                armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-Mathf.Sin(t * 1.3f) * 4f, 0f, 6f), k);
                head.localRotation = Quaternion.Euler(0f, Mathf.Sin(t * 0.6f) * 25f, 0f);
                return;
            }

            body.localScale = Vector3.one;
            head.localRotation = Quaternion.Slerp(head.localRotation, Quaternion.identity, k);
            if (sliding)
            {
                visual.localRotation = Quaternion.Slerp(visual.localRotation, X(-62f), k);
                visual.localPosition = Vector3.Lerp(visual.localPosition, new Vector3(0f, 0.18f, 0f), k);
                legL.localRotation = Quaternion.Slerp(legL.localRotation, X(-55f), k);
                legR.localRotation = Quaternion.Slerp(legR.localRotation, X(-35f), k);
                armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-30f, 0f, -50f), k);
                armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-30f, 0f, 50f), k);
                return;
            }
            if (!grounded)
            {
                float lean = Mathf.Clamp(vy * 1.2f, -15f, 15f);
                visual.localRotation = Quaternion.Slerp(visual.localRotation, X(10f - lean * 0.3f), k);
                visual.localPosition = Vector3.Lerp(visual.localPosition, Vector3.zero, k);
                legL.localRotation = Quaternion.Slerp(legL.localRotation, X(-70f), k);
                legR.localRotation = Quaternion.Slerp(legR.localRotation, X(-15f), k);
                armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-150f, 0f, -15f), k);
                armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-120f, 0f, 15f), k);
                return;
            }
            // run cycle
            phase += dt * (speed * 0.55f + 4f);
            float s = Mathf.Sin(phase);
            visual.localRotation = Quaternion.Slerp(visual.localRotation, X(8f), k);
            visual.localPosition = new Vector3(0f, Mathf.Abs(Mathf.Cos(phase)) * 0.09f, 0f);
            legL.localRotation = X(s * 48f);
            legR.localRotation = X(-s * 48f);
            armL.localRotation = Quaternion.Euler(-s * 42f, 0f, -6f);
            armR.localRotation = Quaternion.Euler(s * 42f, 0f, 6f);
            float sign = Mathf.Sign(s);
            if (sign != lastStepSign)
            {
                lastStepSign = sign;
                var au = AudioManager.Instance;
                if (au != null) au.Play(au.footstep, 0.35f, Random.Range(0.9f, 1.1f));
            }
        }
    }
}
