using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Auto-running explorer on a 3-lane track: lane switching, jumping (with fast-fall), sliding,
    /// collision handling (shield / speed-boost smash / death), revive.
    /// Movement is kinematic; hits are detected with trigger volumes.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    [RequireComponent(typeof(BoxCollider))]
    public class PlayerController : MonoBehaviour
    {
        public static PlayerController Instance { get; private set; }

        public int Lane { get; private set; }
        public bool IsGrounded { get; private set; }
        public bool IsSliding { get; private set; }
        public bool IsDead { get; private set; }
        public float InvulnerableTime { get; set; }
        /// <summary>Used by the automated smoke test only.</summary>
        public bool GodMode { get; set; }
        public float ColliderHeight { get { return box != null ? box.size.y : 0f; } }
        public float VerticalVelocity { get { return vy; } }
        public int JumpCount { get; private set; }
        public int SlideCount { get; private set; }
        public int LaneChanges { get; private set; }

        BoxCollider box;
        PlayerAnimator anim;
        float vy, xVel, slideTimer;
        bool queuedSlide, falling;

        static readonly Vector3 StandCenter = new Vector3(0f, 0.95f, 0f), StandSize = new Vector3(0.7f, 1.7f, 0.6f);
        static readonly Vector3 SlideCenter = new Vector3(0f, 0.45f, 0f), SlideSize = new Vector3(0.7f, 0.7f, 0.6f);

        void Awake()
        {
            Instance = this;
            var rb = GetComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            box = GetComponent<BoxCollider>();
            box.isTrigger = false;
            anim = GetComponent<PlayerAnimator>();
            ResetPlayer();
        }

        void Start()
        {
            if (PowerUpManager.Instance != null) PowerUpManager.Instance.Expired += OnPowerUpExpired;
        }

        void OnDestroy()
        {
            if (PowerUpManager.Instance != null) PowerUpManager.Instance.Expired -= OnPowerUpExpired;
        }

        void OnPowerUpExpired(PowerUpType t)
        {
            // grace period so the end of a speed boost never kills instantly
            if (t == PowerUpType.SpeedBoost) InvulnerableTime = Mathf.Max(InvulnerableTime, 1f);
        }

        public void ResetPlayer()
        {
            Lane = 1;
            transform.position = Vector3.zero;
            transform.rotation = Quaternion.identity;
            vy = 0f; xVel = 0f; slideTimer = 0f;
            IsGrounded = true; IsSliding = false; IsDead = false;
            queuedSlide = false; falling = false;
            InvulnerableTime = 0f;
            SetCollider(false);
            if (anim != null) anim.ResetPose();
        }

        bool CanControl
        {
            get { var gm = GameManager.Instance; return gm != null && gm.State == GameState.Playing && !IsDead; }
        }

        public void MoveLeft() { ChangeLane(-1); }
        public void MoveRight() { ChangeLane(1); }

        void ChangeLane(int dir)
        {
            if (!CanControl) return;
            int target = Mathf.Clamp(Lane + dir, 0, 2);
            if (target == Lane) return;
            Lane = target;
            LaneChanges++;
            var au = AudioManager.Instance;
            if (au != null) au.Play(au.swoosh, 0.35f, Random.Range(0.95f, 1.15f));
        }

        public void Jump()
        {
            if (!CanControl || !IsGrounded) return;
            if (IsSliding) EndSlide();
            IsGrounded = false;
            vy = GameConfig.JumpVelocity;
            JumpCount++;
            var au = AudioManager.Instance;
            if (au != null) au.Play(au.jump, 0.5f);
        }

        public void Slide()
        {
            if (!CanControl) return;
            if (!IsGrounded)
            {
                vy = Mathf.Min(vy, -GameConfig.JumpVelocity * 1.6f); // fast-fall
                queuedSlide = true;
                return;
            }
            StartSlide();
        }

        void StartSlide()
        {
            IsSliding = true;
            slideTimer = GameConfig.SlideDuration;
            SlideCount++;
            SetCollider(true);
            var au = AudioManager.Instance;
            if (au != null) au.Play(au.slide, 0.5f);
        }

        void EndSlide()
        {
            IsSliding = false;
            SetCollider(false);
        }

        void SetCollider(bool sliding)
        {
            if (box == null) return;
            box.center = sliding ? SlideCenter : StandCenter;
            box.size = sliding ? SlideSize : StandSize;
        }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;
            float dt = Time.deltaTime;

            if (gm.State == GameState.Dying || gm.State == GameState.GameOver)
            {
                if (falling)
                {
                    vy -= GameConfig.Gravity * 0.6f * dt;
                    var fp = transform.position;
                    fp.y = Mathf.Max(-12f, fp.y + vy * dt);
                    fp.z += 2f * dt;
                    transform.position = fp;
                }
                if (anim != null) anim.Tick(dt, true, IsGrounded, false, 0f, vy);
                return;
            }
            if (gm.State != GameState.Playing)
            {
                if (anim != null) anim.Tick(dt, gm.State == GameState.Countdown || gm.State == GameState.Paused, true, false, 0f, 0f);
                return;
            }

            float speed = gm.CurrentSpeed;
            Vector3 p = transform.position;
            float dz = speed * dt;
            p.z += dz;
            gm.AddDistance(dz);
            p.x = Mathf.SmoothDamp(p.x, GameConfig.LaneX(Lane), ref xVel, GameConfig.LaneSwitchSmooth, Mathf.Infinity, dt);

            if (!IsGrounded)
            {
                vy -= GameConfig.Gravity * dt;
                p.y += vy * dt;
                if (p.y <= 0f)
                {
                    p.y = 0f; vy = 0f; IsGrounded = true;
                    if (queuedSlide) { queuedSlide = false; StartSlide(); }
                }
            }
            if (IsSliding)
            {
                slideTimer -= dt;
                if (slideTimer <= 0f) EndSlide();
            }
            if (InvulnerableTime > 0f)
            {
                InvulnerableTime -= dt;
                if (anim != null) anim.SetVisible(InvulnerableTime <= 0f || Mathf.Repeat(Time.time * 10f, 1f) > 0.35f);
            }
            transform.position = p;
            if (anim != null) anim.Tick(dt, true, IsGrounded, IsSliding, speed, vy);
        }

        void OnTriggerEnter(Collider other) { HandleContact(other); }

        void HandleContact(Collider other)
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.State != GameState.Playing || IsDead) return;
            var c = other.GetComponent<Collectible>();
            if (c != null)
            {
                if (c.IsCollectable && CollectibleManager.Instance != null) CollectibleManager.Instance.Collect(c);
                return;
            }
            var o = other.GetComponentInParent<Obstacle>();
            if (o != null && o.IsArmed) HitObstacle(o);
        }

        public void HitObstacle(Obstacle o)
        {
            var pu = PowerUpManager.Instance;
            var cam = CameraFollow.Instance;
            var au = AudioManager.Instance;
            if (pu != null && pu.IsActive(PowerUpType.SpeedBoost))
            {
                o.Smash(true);
                if (cam != null) cam.Shake(0.15f, 0.15f);
                return;
            }
            if (GodMode || InvulnerableTime > 0f) return;
            if (pu != null && pu.IsActive(PowerUpType.CrystalShield))
            {
                pu.ConsumeShield();
                o.Smash(true);
                InvulnerableTime = 1f;
                if (cam != null) cam.Shake(0.35f, 0.3f);
                if (au != null) au.Play(au.shieldBreak, 0.9f);
                if (FXManager.Instance != null) FXManager.Instance.Burst(transform.position + Vector3.up, new Color(0.4f, 0.9f, 1f), 40);
                var gm = GameManager.Instance;
                if (gm != null) gm.ShowToast("SHIELD BROKEN!", new Color(0.4f, 0.9f, 1f));
                return;
            }
            Die(GameConfig.IsPit(o.kind) ? DeathCause.Fall : DeathCause.Crash, o);
        }

        void Die(DeathCause cause, Obstacle o)
        {
            IsDead = true;
            IsSliding = false;
            falling = cause == DeathCause.Fall;
            vy = falling ? 0f : vy;
            if (anim != null) { anim.SetVisible(true); anim.PlayDeath(falling); }
            var au = AudioManager.Instance;
            if (au != null) au.Play(au.collision, 1f);
            if (FXManager.Instance != null)
            {
                if (o != null && o.kind == ObstacleKind.WaterHazard) FXManager.Instance.Splash(transform.position, 30);
                else FXManager.Instance.Debris(transform.position + Vector3.up, 12);
            }
            if (CameraFollow.Instance != null) CameraFollow.Instance.Shake(0.6f, 0.5f);
            GameManager.Instance.PlayerDied(cause);
        }

        /// <summary>Kills the player regardless of power-ups (smoke test helper).</summary>
        public void ForceDeath() { if (!IsDead) Die(DeathCause.Crash, null); }

        /// <summary>Puts the player back on the track in the current lane, grounded, with temporary invulnerability.</summary>
        public void Revive()
        {
            IsDead = false;
            falling = false;
            IsSliding = false;
            queuedSlide = false;
            IsGrounded = true;
            vy = 0f;
            var p = transform.position;
            p.y = 0f;
            p.x = GameConfig.LaneX(Lane);
            transform.position = p;
            SetCollider(false);
            InvulnerableTime = 2.5f;
            if (anim != null) anim.ResetPose();
        }
    }
}
