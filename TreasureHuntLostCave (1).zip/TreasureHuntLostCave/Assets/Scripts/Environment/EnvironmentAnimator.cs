using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// One Update() that animates everything environmental: scrolling water, pulsing crystals/runes,
    /// flickering torches, biome fog/ambient colour blending, Ancient Vision brightening.
    /// </summary>
    public class EnvironmentAnimator : MonoBehaviour
    {
        public static EnvironmentAnimator Instance { get; private set; }

        static readonly List<Light> flickers = new List<Light>();
        static readonly List<float> flickerBase = new List<float>();

        Material water, waterfall, crystalB, crystalP, crystalT, runeB, runeO, biolum, fire;
        Color crystalBEm, crystalPEm, crystalTEm, runeBEm, runeOEm, biolumEm, fireEm;
        Color fogColor, ambient;
        Camera cam;

        public Biome CurrentBiome { get; private set; }

        public static void RegisterFlicker(Light l)
        {
            if (!Application.isPlaying || l == null) return;
            flickers.Add(l);
            flickerBase.Add(l.intensity);
        }

        public static void ResetRegistry() { flickers.Clear(); flickerBase.Clear(); }

        public static Color FogFor(Biome b)
        {
            switch (b)
            {
                case Biome.AncientRuins: return new Color(0.11f, 0.08f, 0.055f);
                case Biome.UndergroundRiver: return new Color(0.03f, 0.09f, 0.1f);
                case Biome.DarkTunnel: return new Color(0.035f, 0.032f, 0.04f);
                case Biome.TreasureChamber: return new Color(0.12f, 0.085f, 0.03f);
                default: return new Color(0.04f, 0.055f, 0.14f);
            }
        }

        public static Color AmbientFor(Biome b)
        {
            switch (b)
            {
                case Biome.AncientRuins: return new Color(0.44f, 0.37f, 0.3f);
                case Biome.UndergroundRiver: return new Color(0.28f, 0.42f, 0.42f);
                case Biome.DarkTunnel: return new Color(0.3f, 0.28f, 0.3f);
                case Biome.TreasureChamber: return new Color(0.5f, 0.42f, 0.28f);
                default: return new Color(0.3f, 0.34f, 0.52f);
            }
        }

        void Awake()
        {
            Instance = this;
            water = MaterialLibrary.Get(Mat.Water);
            waterfall = MaterialLibrary.Get(Mat.Waterfall);
            crystalB = MaterialLibrary.Get(Mat.CrystalBlue); crystalBEm = crystalB.GetColor("_EmissionColor");
            crystalP = MaterialLibrary.Get(Mat.CrystalPurple); crystalPEm = crystalP.GetColor("_EmissionColor");
            crystalT = MaterialLibrary.Get(Mat.CrystalTeal); crystalTEm = crystalT.GetColor("_EmissionColor");
            runeB = MaterialLibrary.Get(Mat.RuneBlue); runeBEm = runeB.GetColor("_EmissionColor");
            runeO = MaterialLibrary.Get(Mat.RuneOrange); runeOEm = runeO.GetColor("_EmissionColor");
            biolum = MaterialLibrary.Get(Mat.Biolum); biolumEm = biolum.GetColor("_EmissionColor");
            fire = MaterialLibrary.Get(Mat.Fire); fireEm = fire.GetColor("_EmissionColor");
            fogColor = FogFor(Biome.CrystalCave);
            ambient = AmbientFor(Biome.CrystalCave);
            ApplyRenderSettings(1f);
        }

        public void SetCamera(Camera c) { cam = c; }

        void ApplyRenderSettings(float visionBoost)
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 22f;
            RenderSettings.fogEndDistance = 125f;
            RenderSettings.fogColor = fogColor;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = ambient * visionBoost;
            if (cam != null) cam.backgroundColor = fogColor;
        }

        void Update()
        {
            float t = Time.time;
            water.mainTextureOffset = new Vector2(t * 0.03f, t * 0.35f);
            waterfall.mainTextureOffset = new Vector2(0f, t * 1.4f);

            float pulse = 0.85f + 0.25f * Mathf.Sin(t * 2.1f);
            crystalB.SetColor("_EmissionColor", crystalBEm * pulse);
            crystalP.SetColor("_EmissionColor", crystalPEm * (0.85f + 0.25f * Mathf.Sin(t * 1.7f + 1f)));
            crystalT.SetColor("_EmissionColor", crystalTEm * (0.85f + 0.25f * Mathf.Sin(t * 2.5f + 2f)));
            runeB.SetColor("_EmissionColor", runeBEm * (0.7f + 0.4f * Mathf.Sin(t * 1.3f)));
            runeO.SetColor("_EmissionColor", runeOEm * (0.75f + 0.35f * Mathf.Sin(t * 1.1f + 0.5f)));
            biolum.SetColor("_EmissionColor", biolumEm * (0.8f + 0.25f * Mathf.Sin(t * 0.9f)));
            fire.SetColor("_EmissionColor", fireEm * (0.85f + 0.3f * Mathf.PerlinNoise(t * 6f, 0f)));

            for (int i = 0; i < flickers.Count; i++)
            {
                var l = flickers[i];
                if (l == null || !l.isActiveAndEnabled) continue;
                l.intensity = flickerBase[i] * (0.78f + 0.4f * Mathf.PerlinNoise(t * 7f + i * 3.3f, i));
            }

            // Biome blending
            var gen = TrackGenerator.Instance;
            var player = PlayerController.Instance;
            if (gen != null && player != null)
            {
                float pz = player.transform.position.z;
                var seg = gen.SegmentAt(pz + 8f);
                if (seg != null) CurrentBiome = seg.biome;
                if (AudioManager.Instance != null)
                    AudioManager.Instance.SetWaterProximity(CurrentBiome == Biome.UndergroundRiver ? 1f : 0f, seg != null && seg.hasWaterfall);
            }
            float k = 1f - Mathf.Exp(-Time.deltaTime * 1.5f);
            fogColor = Color.Lerp(fogColor, FogFor(CurrentBiome), k);
            ambient = Color.Lerp(ambient, AmbientFor(CurrentBiome), k);
            bool vision = PowerUpManager.Instance != null && PowerUpManager.Instance.IsActive(PowerUpType.AncientVision);
            ApplyRenderSettings(vision ? 1.6f : 1f);
            if (vision) RenderSettings.fogEndDistance = 170f;
        }
    }
}
