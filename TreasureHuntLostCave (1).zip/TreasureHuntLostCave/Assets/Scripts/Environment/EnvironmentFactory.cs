using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Builds the five Lost Cave biomes from procedural geometry. Each biome has 3 variants:
    /// 0 = glowing entrance gate (first segment of a biome), 1 = standard passage, 2 = special set-piece
    /// (giant crystal cavern / ancient stone bridge over a pit / underground lake / collapsed mine / treasure hall).
    /// Static decoration is merged into one mesh per material for mobile performance.
    /// </summary>
    public static class EnvironmentFactory
    {
        const float L = GameConfig.SegmentLength;

        class Ctx
        {
            public Transform st, dy;
            public Biome biome;
            public int variant;
            public float ceil;
            public bool bridge, openLeft, openRight;
            public TrackSegment seg;
            public int lights;
        }

        static Material M(string k) { return MaterialLibrary.Get(k); }

        public static TrackSegment BuildSegment(Biome biome, int variant)
        {
            var root = new GameObject("Segment_" + biome + "_" + variant);
            var seg = root.AddComponent<TrackSegment>();
            seg.biome = biome;
            seg.variant = variant;
            var c = new Ctx
            {
                st = Util.Node("Static", root.transform, Vector3.zero).transform,
                dy = Util.Node("Dynamic", root.transform, Vector3.zero).transform,
                biome = biome, variant = variant, seg = seg
            };
            c.ceil = CeilingFor(biome, variant);
            c.bridge = (biome == Biome.AncientRuins && variant == 2) || (biome == Biome.UndergroundRiver && variant == 2);
            if (biome == Biome.UndergroundRiver && variant == 2) { if (Util.Chance(0.5f)) c.openLeft = true; else c.openRight = true; }
            if (biome == Biome.AncientRuins && variant == 2) { c.openLeft = true; c.openRight = true; }

            Floor(c);
            switch (biome)
            {
                case Biome.CrystalCave: CrystalCave(c); break;
                case Biome.AncientRuins: AncientRuins(c); break;
                case Biome.UndergroundRiver: UndergroundRiver(c); break;
                case Biome.DarkTunnel: DarkTunnel(c); break;
                default: TreasureChamber(c); break;
            }
            if (variant == 0) Gate(c);
            Util.CombineStatic(c.st);
            return seg;
        }

        static float CeilingFor(Biome b, int v)
        {
            switch (b)
            {
                case Biome.DarkTunnel: return 7.4f;
                case Biome.AncientRuins: return v == 2 ? 16f : 11f;
                case Biome.TreasureChamber: return v == 2 ? 14f : 12f;
                case Biome.CrystalCave: return v == 2 ? 15f : 10f;
                default: return 10.5f;
            }
        }

        // ------------------------------------------------------------------ common pieces
        static void Floor(Ctx c)
        {
            string floor = c.biome == Biome.AncientRuins || c.biome == Biome.TreasureChamber ? Mat.FloorRuins
                         : c.biome == Biome.DarkTunnel ? Mat.FloorDark : Mat.Floor;
            string edge = c.biome == Biome.CrystalCave ? Mat.EdgeBlue : c.biome == Biome.UndergroundRiver ? Mat.EdgeGreen : Mat.EdgeGold;
            float w = c.bridge ? 8.4f : 9.8f;
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, -0.5f, L / 2), new Vector3(w, 1f, L), M(floor));
            for (int i = -1; i <= 1; i += 2)
            {
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(i * 1.25f, 0.004f, L / 2), new Vector3(0.07f, 0.02f, L), M(Mat.LaneLine));
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(i * 3.9f, 0.03f, L / 2), new Vector3(0.12f, 0.06f, L), M(edge));
                if (c.bridge)
                {
                    // low broken parapet
                    for (float z = 1f; z < L; z += 3f)
                        if (Util.Chance(0.75f))
                            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(i * 4.0f, 0.35f, z), new Vector3(0.4f, Util.R(0.4f, 0.8f), Util.R(1.6f, 2.6f)), M(Mat.RuinStoneDark));
                }
                else
                    Util.Prim(PrimitiveType.Cube, c.st, new Vector3(i * 4.6f, 0.12f, L / 2), new Vector3(0.6f, 0.3f, L), M(Mat.RockDark));
            }
        }

        static GameObject Rock(Transform p, Vector3 pos, Vector3 scale, string mat)
        {
            return Util.MeshObj(MeshFactory.Rock(Util.Ri(0, 5)), p, pos, scale, M(mat), new Vector3(Util.R(-15, 15), Util.R(0, 360), Util.R(-15, 15)));
        }

        static void Walls(Ctx c, float inner, string mat)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                if ((s < 0 && c.openLeft) || (s > 0 && c.openRight)) continue;
                for (float z = -1f; z < L + 2f; z += Util.R(3.5f, 5f))
                    Rock(c.st, new Vector3(s * Util.R(inner, inner + 1.5f), Util.R(0f, 3.5f), z), new Vector3(Util.R(3f, 5f), Util.R(6f, 10f), Util.R(4f, 6.5f)), mat);
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * (inner + 3.2f), c.ceil * 0.5f, L / 2), new Vector3(1f, c.ceil + 2f, L + 1f), M(Mat.RockDark));
            }
        }

        static void Ceiling(Ctx c, float width)
        {
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, c.ceil + 1f, L / 2), new Vector3(width, 2f, L + 0.5f), M(Mat.RockDark));
            for (int i = 0; i < 6; i++)
                Rock(c.st, new Vector3(Util.R(-width / 2, width / 2), c.ceil, Util.R(0, L)), new Vector3(Util.R(2f, 4f), Util.R(1f, 2f), Util.R(2f, 4f)), Mat.RockDark);
            Stalactites(c, 7, width);
        }

        static void Stalactites(Ctx c, int count, float width)
        {
            for (int i = 0; i < count; i++)
            {
                float x = Util.R(-width / 2 + 1f, width / 2 - 1f);
                float maxLen = Mathf.Abs(x) < 4.6f ? Mathf.Max(0.8f, c.ceil - 5.6f) : c.ceil - 1.5f;
                float len = Util.R(0.8f, Mathf.Min(4f, maxLen));
                float r = Util.R(0.35f, 0.9f);
                Util.MeshObj(MeshFactory.Cone(7), c.st, new Vector3(x, c.ceil + 0.2f, Util.R(0, L)), new Vector3(r, len, r), M(Mat.RockWall), new Vector3(180f, Util.R(0, 360), 0));
            }
        }

        static void Stalagmites(Ctx c, int count, float minX, float maxX)
        {
            for (int i = 0; i < count; i++)
            {
                float s = Util.Side();
                if ((s < 0 && c.openLeft) || (s > 0 && c.openRight)) continue;
                float r = Util.R(0.4f, 1f);
                Util.MeshObj(MeshFactory.Cone(7), c.st, new Vector3(s * Util.R(minX, maxX), -0.1f, Util.R(0, L)), new Vector3(r, Util.R(1f, 3.5f), r), M(Mat.RockWall), new Vector3(Util.R(-6, 6), Util.R(0, 360), Util.R(-6, 6)));
            }
        }

        static void CrystalCluster(Transform p, Vector3 pos, float size, string mat)
        {
            int n = Util.Ri(3, 6);
            for (int i = 0; i < n; i++)
            {
                float s = size * Util.R(0.5f, 1.1f);
                Vector3 off = new Vector3(Util.R(-0.5f, 0.5f), 0, Util.R(-0.5f, 0.5f)) * size;
                Util.MeshObj(MeshFactory.Crystal(), p, pos + off, new Vector3(s * 0.7f, s * Util.R(1.4f, 2.6f), s * 0.7f), M(mat),
                    new Vector3(Util.R(-28, 28), Util.R(0, 360), Util.R(-28, 28)));
            }
        }

        static void Plants(Transform p, Vector3 pos)
        {
            int n = Util.Ri(3, 6);
            for (int i = 0; i < n; i++)
            {
                Vector3 o = pos + new Vector3(Util.R(-0.6f, 0.6f), 0, Util.R(-0.6f, 0.6f));
                float h = Util.R(0.2f, 0.6f);
                Util.Prim(PrimitiveType.Cylinder, p, o + Vector3.up * h * 0.5f, new Vector3(0.05f, h * 0.5f, 0.05f), M(Mat.Shirt));
                Util.Prim(PrimitiveType.Sphere, p, o + Vector3.up * h, new Vector3(0.28f, 0.14f, 0.28f) * Util.R(0.7f, 1.4f), M(Mat.Biolum));
            }
        }

        static void AddLight(Ctx c, Vector3 pos, Color col, float range, float intensity, bool flicker)
        {
            if (c.lights >= 2) return;
            c.lights++;
            var l = Util.PointLight(c.dy, pos, col, range, intensity);
            if (flicker) EnvironmentAnimator.RegisterFlicker(l);
        }

        static void Torch(Ctx c, Vector3 pos, bool light)
        {
            Util.Prim(PrimitiveType.Cylinder, c.st, pos + new Vector3(0, 0.6f, 0), new Vector3(0.25f, 0.6f, 0.25f), M(Mat.RuinStoneDark));
            Util.Prim(PrimitiveType.Cylinder, c.st, pos + new Vector3(0, 1.3f, 0), new Vector3(0.7f, 0.12f, 0.7f), M(Mat.Metal));
            Util.Prim(PrimitiveType.Sphere, c.st, pos + new Vector3(0, 1.42f, 0), new Vector3(0.45f, 0.18f, 0.45f), M(Mat.Fire));
            FXManager.CreateFlame(c.dy, pos + new Vector3(0, 1.45f, 0), 1.2f);
            if (light) AddLight(c, pos + new Vector3(0, 2.2f, 0), new Color(1f, 0.6f, 0.25f), 13f, 2.2f, true);
        }

        public static void Statue(Transform p, Vector3 pos, float scale, float rotY, string stone, bool glowEyes)
        {
            var g = Util.Node("Statue", p, pos);
            g.transform.localRotation = Quaternion.Euler(0, rotY, 0);
            g.transform.localScale = Vector3.one * scale;
            var t = g.transform;
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.25f, 0), new Vector3(1.2f, 0.5f, 1.2f), M(Mat.RuinStoneDark));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(-0.22f, 0.95f, 0), new Vector3(0.32f, 0.9f, 0.4f), M(stone));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0.22f, 0.95f, 0), new Vector3(0.32f, 0.9f, 0.4f), M(stone));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 1.85f, 0), new Vector3(0.9f, 1f, 0.5f), M(stone));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(-0.6f, 1.8f, 0.05f), new Vector3(0.25f, 0.9f, 0.3f), M(stone), new Vector3(0, 0, -8));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0.6f, 1.8f, 0.05f), new Vector3(0.25f, 0.9f, 0.3f), M(stone), new Vector3(0, 0, 8));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 2.6f, 0), new Vector3(0.55f, 0.55f, 0.5f), M(stone));
            Util.MeshObj(MeshFactory.Cone(4), t, new Vector3(0, 2.85f, 0), new Vector3(0.8f, 0.6f, 0.8f), M(stone), new Vector3(0, 45, 0));
            if (glowEyes)
            {
                Util.Prim(PrimitiveType.Cube, t, new Vector3(-0.12f, 2.65f, 0.26f), new Vector3(0.1f, 0.06f, 0.02f), M(Mat.GuardEyes));
                Util.Prim(PrimitiveType.Cube, t, new Vector3(0.12f, 2.65f, 0.26f), new Vector3(0.1f, 0.06f, 0.02f), M(Mat.GuardEyes));
            }
        }

        public static void Cart(Transform p, Vector3 pos, float rotY, float tiltZ, bool withOre)
        {
            var g = Util.Node("MineCart", p, pos);
            g.transform.localRotation = Quaternion.Euler(0, rotY, tiltZ);
            var t = g.transform;
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.45f, 0), new Vector3(1.6f, 0.12f, 2.1f), M(Mat.Rust));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(-0.78f, 0.9f, 0), new Vector3(0.08f, 0.9f, 2.1f), M(Mat.Rust));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0.78f, 0.9f, 0), new Vector3(0.08f, 0.9f, 2.1f), M(Mat.Rust));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.9f, -1.02f), new Vector3(1.6f, 0.9f, 0.08f), M(Mat.Rust));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.9f, 1.02f), new Vector3(1.6f, 0.9f, 0.08f), M(Mat.Rust));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 1.36f, 1.02f), new Vector3(1.7f, 0.08f, 0.12f), M(Mat.Metal));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 1.36f, -1.02f), new Vector3(1.7f, 0.08f, 0.12f), M(Mat.Metal));
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sz = -1; sz <= 1; sz += 2)
                    Util.Prim(PrimitiveType.Cylinder, t, new Vector3(sx * 0.85f, 0.28f, sz * 0.65f), new Vector3(0.5f, 0.06f, 0.5f), M(Mat.Metal), new Vector3(0, 0, 90));
            if (withOre)
            {
                Util.MeshObj(MeshFactory.Rock(1), t, new Vector3(0, 1.3f, 0), new Vector3(1.4f, 0.9f, 1.8f), M(Mat.RockDark), Vector3.zero);
                CrystalCluster(t, new Vector3(0, 1.5f, 0), 0.35f, Mat.CrystalBlue);
            }
        }

        static void Waterfall(Ctx c, float side, float z, float wallX)
        {
            float h = c.ceil + 1f;
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(side * wallX, h * 0.5f - 0.3f, z), new Vector3(0.3f, h, 3.2f), M(Mat.Waterfall));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(side * (wallX - 0.6f), h * 0.5f - 0.3f, z), new Vector3(0.15f, h, 2.4f), M(Mat.Waterfall));
            Rock(c.st, new Vector3(side * (wallX + 0.3f), h - 1f, z - 2.2f), new Vector3(2.5f, 3f, 2f), Mat.RockWall);
            Rock(c.st, new Vector3(side * (wallX + 0.3f), h - 1f, z + 2.2f), new Vector3(2.5f, 3f, 2f), Mat.RockWall);
            FXManager.CreateAmbient(c.dy, new Vector3(side * (wallX - 0.8f), 0.3f, z), new Vector3(2f, 0.5f, 3f), new Color(0.75f, 0.9f, 1f, 0.35f),
                10f, 0.8f, 1.6f, -0.05f, 2.2f, M(Mat.Particle));
            c.seg.hasWaterfall = true;
        }

        static void WaterChannel(Ctx c, float side)
        {
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(side * 6.4f, -0.35f, L / 2), new Vector3(3.6f, 0.08f, L), M(Mat.Water));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(side * 6.4f, -1.2f, L / 2), new Vector3(3.6f, 0.2f, L), M(Mat.Pit));
            for (float z = 2f; z < L; z += Util.R(4f, 7f))
            {
                Plants(c.st, new Vector3(side * 4.95f, 0.25f, z));
                if (Util.Chance(0.5f)) Util.Prim(PrimitiveType.Sphere, c.st, new Vector3(side * Util.R(5.5f, 7.5f), -0.3f, z + 1f), new Vector3(0.6f, 0.06f, 0.6f), M(Mat.Biolum));
            }
        }

        // ------------------------------------------------------------------ biomes
        static void CrystalCave(Ctx c)
        {
            bool cavern = c.variant == 2;
            float inner = cavern ? 12f : 7.2f;
            Walls(c, inner, Mat.RockWall);
            Ceiling(c, inner * 2f + 6f);
            Stalagmites(c, 5, 5.2f, inner - 0.5f);
            int clusters = cavern ? 10 : 7;
            for (int i = 0; i < clusters; i++)
            {
                float s = Util.Side();
                CrystalCluster(c.st, new Vector3(s * Util.R(4.9f, inner - 0.5f), 0f, Util.R(0, L)), Util.R(0.8f, cavern ? 2.6f : 1.8f),
                    Util.Chance(0.55f) ? Mat.CrystalBlue : Mat.CrystalPurple);
            }
            for (int i = 0; i < 4; i++)
                Util.MeshObj(MeshFactory.Crystal(), c.st, new Vector3(Util.R(-inner, inner), c.ceil + 0.2f, Util.R(0, L)), new Vector3(0.6f, Util.R(1.2f, 2.2f), 0.6f),
                    M(Util.Chance(0.5f) ? Mat.CrystalPurple : Mat.CrystalTeal), new Vector3(180f + Util.R(-20, 20), Util.R(0, 360), 0));
            for (int i = 0; i < 4; i++) Plants(c.st, new Vector3(Util.Side() * Util.R(4.9f, 6f), 0.1f, Util.R(0, L)));
            if (cavern)
            {
                // giant crystal arch over the track
                for (int s = -1; s <= 1; s += 2)
                    Util.MeshObj(MeshFactory.Crystal(), c.st, new Vector3(s * 6f, 0f, L * 0.5f), new Vector3(1.6f, 9f, 1.6f), M(Mat.CrystalPurple), new Vector3(0, 0, -s * 28f));
                FXManager.CreateAmbient(c.dy, new Vector3(0, 4f, L * 0.5f), new Vector3(16f, 6f, L), new Color(0.6f, 0.7f, 1f, 0.6f), 8f, 0.2f, 0.12f, -0.01f, 4f, M(Mat.Particle));
            }
            AddLight(c, new Vector3(Util.Side() * 5.5f, 2.5f, L * 0.5f), Util.Chance(0.5f) ? new Color(0.35f, 0.6f, 1f) : new Color(0.7f, 0.35f, 1f), 18f, 2.4f, false);
        }

        static void AncientRuins(Ctx c)
        {
            bool bridge = c.variant == 2;
            if (bridge)
            {
                // stone bridge across a bottomless chasm
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, -14f, L / 2), new Vector3(70f, 0.5f, L + 1f), M(Mat.Pit));
                for (float z = 4f; z < L; z += 15f)
                    for (int s = -1; s <= 1; s += 2)
                        Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(s * 3f, -7.5f, z), new Vector3(1.6f, 7f, 1.6f), M(Mat.RuinStoneDark));
                for (int i = 0; i < 8; i++)
                    CrystalCluster(c.st, new Vector3(Util.Side() * Util.R(8f, 25f), -10f, Util.R(0, L)), Util.R(1.5f, 3f), Mat.CrystalTeal);
                for (int s = -1; s <= 1; s += 2)
                    for (float z = 0; z < L; z += 6f)
                        Rock(c.st, new Vector3(s * Util.R(22f, 26f), Util.R(-6f, 6f), z), new Vector3(8f, 18f, 7f), Mat.RockDark);
                for (int s = -1; s <= 1; s += 2)
                {
                    float z = Util.R(5f, L - 5f);
                    Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(s * 12f, 2f, z), new Vector3(1.8f, 9f, 1.8f), M(Mat.RuinStone));
                }
                Ceiling(c, 60f);
                AddLight(c, new Vector3(0, -6f, L * 0.5f), new Color(0.3f, 1f, 0.9f), 20f, 2f, false);
                FXManager.CreateAmbient(c.dy, new Vector3(0, -4f, L * 0.5f), new Vector3(20f, 4f, L), new Color(0.5f, 1f, 0.9f, 0.5f), 10f, 1f, 0.15f, -0.05f, 4f, M(Mat.Particle));
                return;
            }
            Walls(c, 8f, Mat.RuinStoneDark);
            Ceiling(c, 24f);
            // pillar colonnade
            for (float z = 3.75f; z < L; z += 7.5f)
                for (int s = -1; s <= 1; s += 2)
                {
                    bool broken = Util.Chance(0.3f);
                    float h = broken ? Util.R(1.5f, 3f) : 7f;
                    Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 5.3f, 0.25f, z), new Vector3(1.6f, 0.5f, 1.6f), M(Mat.RuinStoneDark));
                    Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(s * 5.3f, h * 0.5f, z), new Vector3(1.1f, h * 0.5f, 1.1f), M(Mat.RuinStone));
                    if (!broken) Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 5.3f, h + 0.2f, z), new Vector3(1.6f, 0.4f, 1.6f), M(Mat.RuinStoneDark));
                    else Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(s * 6.4f, 0.5f, z + 1.5f), new Vector3(1f, 1.2f, 1f), M(Mat.RuinStone), new Vector3(90, Util.R(-40, 40), 0));
                }
            // carved arch with glowing runes
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, 7.6f, L * 0.5f), new Vector3(12f, 1.1f, 1.5f), M(Mat.RuinStoneDark));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, 7.0f, L * 0.5f + 0.78f), new Vector3(8f, 0.15f, 0.05f), M(Mat.RuneOrange));
            for (int i = 0; i < 6; i++)
            {
                float s = Util.Side();
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 7.4f, Util.R(1.5f, 4f), Util.R(1, L - 1)), new Vector3(0.05f, Util.R(0.5f, 0.9f), Util.R(0.5f, 0.9f)), M(Mat.RuneBlue));
            }
            // broken archaeological blocks
            for (int i = 0; i < 4; i++)
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(Util.Side() * Util.R(4.9f, 6.8f), 0.3f, Util.R(0, L)), new Vector3(Util.R(0.6f, 1.4f), Util.R(0.4f, 0.9f), Util.R(0.6f, 1.4f)), M(Mat.RuinStone), new Vector3(0, Util.R(0, 90), Util.R(-10, 10)));
            float sideStatue = Util.Side();
            Statue(c.st, new Vector3(sideStatue * 6.8f, 0f, Util.R(8f, 22f)), 1.3f, sideStatue > 0 ? -90f : 90f, Mat.Guard, true);
            Torch(c, new Vector3(-4.8f, 0f, 1f), true);
            Torch(c, new Vector3(4.8f, 0f, 16f), false);
            if (c.variant == 1 && Util.Chance(0.6f)) HiddenDoorway(c, -sideStatue);
        }

        static void HiddenDoorway(Ctx c, float side)
        {
            float z = Util.R(6f, 24f);
            float x = side * 7.3f;
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(x, 1.7f, z), new Vector3(0.2f, 3.4f, 2.4f), M(Mat.Pit));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(x - side * 0.1f, 3.55f, z), new Vector3(0.3f, 0.3f, 3f), M(Mat.RuneBlue));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(x - side * 0.1f, 1.7f, z - 1.35f), new Vector3(0.3f, 3.4f, 0.3f), M(Mat.RuinStoneDark));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(x - side * 0.1f, 1.7f, z + 1.35f), new Vector3(0.3f, 3.4f, 0.3f), M(Mat.RuinStoneDark));
            FXManager.CreateAmbient(c.dy, new Vector3(x - side * 0.4f, 1.5f, z), new Vector3(0.3f, 3f, 2f), new Color(0.4f, 0.9f, 1f, 0.6f), 6f, 0.3f, 0.12f, -0.02f, 2f, M(Mat.Particle));
        }

        static void UndergroundRiver(Ctx c)
        {
            bool lake = c.variant == 2;
            if (!lake)
            {
                WaterChannel(c, -1f); WaterChannel(c, 1f);
                Walls(c, 9f, Mat.RockWall);
                Ceiling(c, 26f);
                float s = Util.Side();
                Waterfall(c, s, Util.R(8f, 22f), 9f);
                if (c.variant == 0 || Util.Chance(0.4f)) Waterfall(c, -s, Util.R(5f, 25f), 9f);
                AddLight(c, new Vector3(s * 6.5f, 3f, L * 0.5f), new Color(0.3f, 1f, 0.8f), 16f, 2f, false);
            }
            else
            {
                float open = c.openLeft ? -1f : 1f;
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(open * 22f, -0.6f, L / 2), new Vector3(36f, 0.1f, L + 0.5f), M(Mat.Water));
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(open * 22f, -3f, L / 2), new Vector3(36f, 0.2f, L + 0.5f), M(Mat.Pit));
                for (int i = 0; i < 5; i++)
                {
                    var pos = new Vector3(open * Util.R(9f, 36f), -0.8f, Util.R(0, L));
                    float r = Util.R(0.8f, 2f);
                    Util.MeshObj(MeshFactory.Cone(7), c.st, pos, new Vector3(r, Util.R(2f, 7f), r), M(Mat.RockWall), new Vector3(0, Util.R(0, 360), 0));
                    Plants(c.st, pos + new Vector3(r, 0.2f, 0));
                }
                for (float z = 0; z < L; z += 6f) Rock(c.st, new Vector3(open * Util.R(38f, 42f), Util.R(-2f, 6f), z), new Vector3(8f, 16f, 8f), Mat.RockDark);
                // closed side: waterfall + channel
                WaterChannel(c, -open);
                Walls(c, 9f, Mat.RockWall);
                Waterfall(c, -open, L * 0.5f, 9f);
                Ceiling(c, 80f);
                for (float z = 4f; z < L; z += 15f)
                    for (int s = -1; s <= 1; s += 2)
                        Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 3.5f, -2f, z), new Vector3(1.4f, 4f, 1.4f), M(Mat.RuinStoneDark));
                AddLight(c, new Vector3(open * 12f, 2f, L * 0.5f), new Color(0.3f, 0.9f, 1f), 24f, 2.2f, false);
            }
        }

        static void DarkTunnel(Ctx c)
        {
            bool collapsed = c.variant == 2;
            Walls(c, 6.6f, Mat.RockDark);
            Ceiling(c, 18f);
            // timber supports
            for (float z = 3f; z < L; z += 7.5f)
            {
                bool brokenBeam = collapsed && Util.Chance(0.5f);
                for (int s = -1; s <= 1; s += 2)
                    Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 4.95f, c.ceil * 0.5f, z), new Vector3(0.35f, c.ceil, 0.35f), M(Mat.Wood));
                if (!brokenBeam) Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, c.ceil - 0.25f, z), new Vector3(10.4f, 0.4f, 0.4f), M(Mat.Wood));
                else Util.Prim(PrimitiveType.Cube, c.st, new Vector3(Util.Side() * 5.6f, 1.6f, z), new Vector3(5f, 0.4f, 0.4f), M(Mat.WoodDark), new Vector3(0, Util.R(-20, 20), Util.R(25, 40)));
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(Util.Side() * 3.2f, c.ceil - 0.9f, z), new Vector3(0.25f, 0.35f, 0.25f), M(Mat.Fire));
            }
            // rails along the edges
            for (int s = -1; s <= 1; s += 2)
            {
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 5.55f, 0.08f, L / 2), new Vector3(0.08f, 0.1f, L), M(Mat.Metal));
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 6.25f, 0.08f, L / 2), new Vector3(0.08f, 0.1f, L), M(Mat.Metal));
                for (float z = 0.5f; z < L; z += 1.5f)
                    Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 5.9f, 0.03f, z), new Vector3(1.1f, 0.06f, 0.25f), M(Mat.WoodDark));
            }
            // abandoned mining equipment
            float side = Util.Side();
            Cart(c.st, new Vector3(side * 5.9f, 0f, Util.R(4f, 26f)), Util.R(-10, 10), collapsed ? Util.R(10, 30) : 0f, true);
            for (int i = 0; i < 4; i++)
            {
                var p = new Vector3(Util.Side() * Util.R(5.2f, 6.2f), 0f, Util.R(0, L));
                if (Util.Chance(0.5f)) Util.Prim(PrimitiveType.Cube, c.st, p + Vector3.up * 0.4f, Vector3.one * 0.8f, M(Mat.Wood), new Vector3(0, Util.R(0, 90), 0));
                else Util.Prim(PrimitiveType.Cylinder, c.st, p + Vector3.up * 0.5f, new Vector3(0.7f, 0.5f, 0.7f), M(Mat.WoodDark));
            }
            Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(-side * 5.2f, 0.8f, Util.R(5, 25)), new Vector3(0.06f, 0.8f, 0.06f), M(Mat.Wood), new Vector3(0, 0, -side * 20f));
            for (int i = 0; i < 3; i++) CrystalCluster(c.st, new Vector3(Util.Side() * Util.R(5.5f, 6.4f), 0.5f, Util.R(0, L)), 0.4f, Mat.CrystalBlue);
            if (collapsed)
                for (int i = 0; i < 6; i++)
                    Rock(c.st, new Vector3(Util.Side() * Util.R(5f, 6.5f), 0.2f, Util.R(0, L)), Vector3.one * Util.R(0.8f, 2f), Mat.RockWall);
            AddLight(c, new Vector3(0f, c.ceil - 1.2f, L * 0.5f), new Color(1f, 0.65f, 0.3f), 12f, 1.6f, true);
        }

        static void TreasureChamber(Ctx c)
        {
            bool hall = c.variant == 2;
            float inner = hall ? 11f : 8f;
            Walls(c, inner, Mat.RuinStoneDark);
            Ceiling(c, inner * 2f + 6f);
            for (float z = 5f; z < L; z += 10f)
                for (int s = -1; s <= 1; s += 2)
                {
                    float x = s * (inner - 2.2f);
                    Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(x, 4.5f, z), new Vector3(1.2f, 4.5f, 1.2f), M(Mat.RuinStone));
                    Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(x, 1.2f, z), new Vector3(1.35f, 0.08f, 1.35f), M(Mat.Gold));
                    Util.Prim(PrimitiveType.Cylinder, c.st, new Vector3(x, 7.8f, z), new Vector3(1.35f, 0.08f, 1.35f), M(Mat.Gold));
                }
            int piles = hall ? 8 : 5;
            for (int i = 0; i < piles; i++)
            {
                float s = Util.Side();
                var p = new Vector3(s * Util.R(5f, inner - 1f), 0f, Util.R(0, L));
                float sz = Util.R(1f, hall ? 3.5f : 2.2f);
                Util.Prim(PrimitiveType.Sphere, c.st, p, new Vector3(sz * 1.6f, sz * 0.7f, sz * 1.6f), M(Mat.GoldPile));
                for (int k = 0; k < 4; k++)
                    Util.Prim(PrimitiveType.Cylinder, c.st, p + new Vector3(Util.R(-sz, sz), Util.R(0.05f, sz * 0.3f), Util.R(-sz, sz)), new Vector3(0.35f, 0.02f, 0.35f), M(Mat.Gold), new Vector3(Util.R(-40, 40), 0, Util.R(-40, 40)));
            }
            for (int i = 0; i < 2; i++)
            {
                float s = i == 0 ? -1f : 1f;
                ChestDecor(c.st, new Vector3(s * Util.R(5f, 6.5f), 0f, Util.R(3f, 27f)), s > 0 ? -90f : 90f);
            }
            float st = Util.Side();
            Statue(c.st, new Vector3(st * (inner - 1.2f), 0f, L * 0.5f), hall ? 2.2f : 1.5f, st > 0 ? -90f : 90f, Mat.GoldPile, true);
            if (hall) Statue(c.st, new Vector3(-st * (inner - 1.2f), 0f, L * 0.5f), 2.2f, st > 0 ? 90f : -90f, Mat.GoldPile, true);
            for (int i = 0; i < 4; i++)
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(Util.Side() * (inner - 0.4f), Util.R(2f, 6f), Util.R(1, L - 1)), new Vector3(0.05f, 1.2f, 1.2f), M(Mat.RuneOrange), new Vector3(45f, 0, 0));
            Torch(c, new Vector3(-4.8f, 0f, 8f), true);
            Torch(c, new Vector3(4.8f, 0f, 22f), false);
            AddLight(c, new Vector3(0, 6f, L * 0.5f), new Color(1f, 0.8f, 0.4f), 18f, 1.6f, false);
        }

        public static void ChestDecor(Transform p, Vector3 pos, float rotY)
        {
            var g = Util.Node("ChestDecor", p, pos);
            g.transform.localRotation = Quaternion.Euler(0, rotY, 0);
            var t = g.transform;
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.4f, 0), new Vector3(1.4f, 0.8f, 0.9f), M(Mat.ChestWood));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0, 0.82f, -0.35f), new Vector3(1.45f, 0.1f, 0.9f), M(Mat.ChestWood), new Vector3(-60, 0, 0));
            Util.Prim(PrimitiveType.Sphere, t, new Vector3(0, 0.8f, 0), new Vector3(1.2f, 0.35f, 0.7f), M(Mat.GoldPile));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(-0.6f, 0.4f, 0), new Vector3(0.08f, 0.82f, 0.95f), M(Mat.Gold));
            Util.Prim(PrimitiveType.Cube, t, new Vector3(0.6f, 0.4f, 0), new Vector3(0.08f, 0.82f, 0.95f), M(Mat.Gold));
        }

        static void Gate(Ctx c)
        {
            string rune = c.biome == Biome.CrystalCave ? Mat.RuneBlue : c.biome == Biome.UndergroundRiver ? Mat.Biolum : Mat.RuneOrange;
            string stone = c.biome == Biome.DarkTunnel ? Mat.Wood : Mat.RuinStoneDark;
            float h = Mathf.Min(8f, c.ceil - 0.5f);
            for (int s = -1; s <= 1; s += 2)
            {
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 5.6f, h * 0.5f, 1.5f), new Vector3(1.6f, h, 1.6f), M(stone));
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(s * 4.75f, h * 0.5f, 1.5f), new Vector3(0.1f, h - 0.5f, 0.5f), M(rune));
            }
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, h + 0.6f, 1.5f), new Vector3(13.5f, 1.4f, 1.9f), M(stone));
            Util.Prim(PrimitiveType.Cube, c.st, new Vector3(0, h - 0.15f, 0.55f), new Vector3(9.5f, 0.12f, 0.05f), M(rune));
            for (int i = -2; i <= 2; i++)
                Util.Prim(PrimitiveType.Cube, c.st, new Vector3(i * 1.6f, h + 0.6f, 0.53f), new Vector3(0.5f, 0.5f, 0.05f), M(rune), new Vector3(0, 0, 45));
            Color lc = c.biome == Biome.CrystalCave ? new Color(0.3f, 0.7f, 1f) : c.biome == Biome.UndergroundRiver ? new Color(0.3f, 1f, 0.5f) : new Color(1f, 0.6f, 0.2f);
            AddLight(c, new Vector3(0, h - 1f, 0.5f), lc, 16f, 2.6f, false);
            FXManager.CreateAmbient(c.dy, new Vector3(0, h * 0.5f, 1.5f), new Vector3(9f, h, 0.5f), new Color(lc.r, lc.g, lc.b, 0.7f), 14f, 0.3f, 0.15f, -0.02f, 2.5f, M(Mat.Particle));
        }
    }
}
