using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>One 30 m piece of cave. Owns the obstacles/collectibles spawned on it so they recycle together.</summary>
    public class TrackSegment : MonoBehaviour
    {
        public Biome biome;
        public int variant;
        public bool hasWaterfall;
        [System.NonSerialized] public readonly List<PooledItem> spawned = new List<PooledItem>();

        public float StartZ { get { return transform.position.z; } }
        public float EndZ { get { return transform.position.z + GameConfig.SegmentLength; } }
        public int PoolKey { get { return (int)biome * 10 + variant; } }

        public void Track(PooledItem item)
        {
            item.owner = this;
            spawned.Add(item);
        }

        public void ReleaseSpawned()
        {
            for (int i = 0; i < spawned.Count; i++)
            {
                var it = spawned[i];
                if (it != null && it.inUse && it.owner == this) it.pool.Release(it);
            }
            spawned.Clear();
        }
    }
}
