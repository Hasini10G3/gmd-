using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Endless track: spawns pooled cave segments ahead of the player, recycles them behind,
    /// cycles through the five biomes and fills each segment with obstacle rows and treasure.
    ///
    /// Fairness rule: every row has a "safe lane" that is empty or passable by a jump/slide,
    /// and the safe lane moves at most one lane between rows. Row spacing grows with speed so
    /// there is always time to react, therefore an unavoidable combination can never be generated.
    /// </summary>
    public class TrackGenerator : MonoBehaviour
    {
        public static TrackGenerator Instance { get; private set; }

        const float L = GameConfig.SegmentLength;

        readonly Dictionary<int, Stack<TrackSegment>> segmentPool = new Dictionary<int, Stack<TrackSegment>>();
        readonly List<TrackSegment> active = new List<TrackSegment>();
        KeyedPool obstaclePool, collectiblePool;
        Transform segmentRoot;

        float nextSegZ, nextRowZ, lastRowZ;
        int safeLane = 1, prevSafe = 1, segsLeftInBiome, rowsSincePowerUp = 10;
        Biome biome = Biome.CrystalCave;
        bool firstOfBiome;

        public IList<TrackSegment> ActiveSegments { get { return active; } }
        public int SegmentsBuilt { get; private set; }
        public int SegmentsRecycled { get; private set; }
        public int SegmentsReused { get; private set; }
        public int ObstaclesSpawned { get; private set; }
        public KeyedPool ObstaclePool { get { return obstaclePool; } }
        public KeyedPool CollectiblePool { get { return collectiblePool; } }
        /// <summary>When false no random obstacles are generated (used by the smoke test).</summary>
        public bool SpawnHazards { get; set; }

        // Obstacle sets per biome: [0] = lane blockers, [1] = jump/slide hazards
        static readonly ObstacleKind[][][] Sets =
        {
            new[] { new[] { ObstacleKind.CaveCrystal, ObstacleKind.Stalagmite, ObstacleKind.FallingBoulder },
                    new[] { ObstacleKind.Stalactite, ObstacleKind.FallingDebris, ObstacleKind.Gap } },
            new[] { new[] { ObstacleKind.AncientGuard, ObstacleKind.RollingRock, ObstacleKind.Stalagmite },
                    new[] { ObstacleKind.SpikeTrap, ObstacleKind.CollapsingBridge, ObstacleKind.Stalactite } },
            new[] { new[] { ObstacleKind.Stalagmite, ObstacleKind.RollingRock, ObstacleKind.CaveCrystal },
                    new[] { ObstacleKind.WaterHazard, ObstacleKind.CollapsingBridge, ObstacleKind.Gap, ObstacleKind.Stalactite } },
            new[] { new[] { ObstacleKind.MineCart, ObstacleKind.FallingBoulder, ObstacleKind.Stalagmite },
                    new[] { ObstacleKind.Gap, ObstacleKind.Stalactite, ObstacleKind.FallingDebris } },
            new[] { new[] { ObstacleKind.AncientGuard, ObstacleKind.FallingBoulder, ObstacleKind.RollingRock },
                    new[] { ObstacleKind.SpikeTrap, ObstacleKind.Stalactite, ObstacleKind.Gap } },
        };

        void Awake()
        {
            Instance = this;
            SpawnHazards = true;
            segmentRoot = new GameObject("Segments").transform;
            segmentRoot.SetParent(transform, false);
            obstaclePool = new KeyedPool("ObstaclePool", k => ObstacleFactory.Create((ObstacleKind)k).gameObject, transform);
            collectiblePool = new KeyedPool("CollectiblePool", CollectibleFactory.CreateFromKey, transform);
        }

        void Start() { ResetTrack(); }

        public void ResetTrack()
        {
            for (int i = 0; i < active.Count; i++) ReturnSegment(active[i]);
            active.Clear();
            nextSegZ = -L;
            nextRowZ = GameConfig.SafeStartSegments * L;
            lastRowZ = 6f;
            safeLane = 1; prevSafe = 1;
            biome = Biome.CrystalCave;
            segsLeftInBiome = Random.Range(5, 8);
            firstOfBiome = false;
            rowsSincePowerUp = 3;
            float pz = PlayerController.Instance != null ? PlayerController.Instance.transform.position.z : 0f;
            Fill(pz);
        }

        void Update()
        {
            var p = PlayerController.Instance;
            if (p == null) return;
            float pz = p.transform.position.z;
            Fill(pz);
            while (active.Count > 0 && active[0].EndZ < pz - 20f)
            {
                var s = active[0];
                active.RemoveAt(0);
                ReturnSegment(s);
                SegmentsRecycled++;
            }
        }

        void Fill(float pz)
        {
            int guard = 0;
            while (nextSegZ < pz + GameConfig.SegmentsAhead * L && guard++ < 20) SpawnSegment();
        }

        public void ShiftOrigin(float d)
        {
            nextSegZ -= d; nextRowZ -= d; lastRowZ -= d;
        }

        public TrackSegment SegmentAt(float z)
        {
            for (int i = 0; i < active.Count; i++)
                if (z >= active[i].StartZ && z < active[i].EndZ) return active[i];
            return null;
        }

        // ------------------------------------------------------------------ segments
        void SpawnSegment()
        {
            int variant;
            if (segsLeftInBiome <= 0)
            {
                Biome next = biome;
                while (next == biome) next = (Biome)Random.Range(0, 5);
                biome = next;
                segsLeftInBiome = Random.Range(6, 10);
                firstOfBiome = true;
            }
            if (firstOfBiome) { variant = 0; firstOfBiome = false; }
            else variant = Random.value < 0.3f ? 2 : 1;
            segsLeftInBiome--;

            var seg = TakeSegment(biome, variant);
            seg.transform.position = new Vector3(0f, 0f, nextSegZ);
            seg.gameObject.SetActive(true);
            active.Add(seg);
            nextSegZ += L;

            while (nextRowZ < seg.EndZ - 1f)
            {
                if (nextRowZ > seg.StartZ) GenerateRow(seg, nextRowZ);
                lastRowZ = Mathf.Max(lastRowZ, nextRowZ);
                float speed = GameManager.SpeedAtDistance(Mathf.Max(0f, (GameManager.Instance != null ? GameManager.Instance.Distance : 0f) + (nextRowZ - CurrentPlayerZ())));
                float d = Difficulty;
                nextRowZ += Mathf.Max(GameConfig.MinRowSpacing, speed * GameConfig.RowSpacingPerSpeed) + Random.Range(0f, 7f * (1f - d) + 1.5f);
            }
        }

        static float CurrentPlayerZ() { var p = PlayerController.Instance; return p != null ? p.transform.position.z : 0f; }
        float Difficulty { get { return GameManager.Instance != null ? GameManager.Instance.Difficulty : 0f; } }

        TrackSegment TakeSegment(Biome b, int variant)
        {
            int key = (int)b * 10 + variant;
            Stack<TrackSegment> stack;
            if (segmentPool.TryGetValue(key, out stack) && stack.Count > 0)
            {
                SegmentsReused++;
                return stack.Pop();
            }
            var seg = EnvironmentFactory.BuildSegment(b, variant);
            seg.transform.SetParent(segmentRoot, false);
            SegmentsBuilt++;
            return seg;
        }

        void ReturnSegment(TrackSegment s)
        {
            s.ReleaseSpawned();
            s.gameObject.SetActive(false);
            Stack<TrackSegment> stack;
            if (!segmentPool.TryGetValue(s.PoolKey, out stack))
            {
                stack = new Stack<TrackSegment>();
                segmentPool[s.PoolKey] = stack;
            }
            stack.Push(s);
        }

        // ------------------------------------------------------------------ content
        PooledItem SpawnObstacle(TrackSegment seg, ObstacleKind kind, int lane, float z)
        {
            var it = obstaclePool.Spawn((int)kind, seg.transform, new Vector3(GameConfig.LaneX(lane), 0f, z));
            seg.Track(it);
            ObstaclesSpawned++;
            return it;
        }

        public PooledItem SpawnCollectible(TrackSegment seg, CollectibleType type, PowerUpType pu, int lane, float y, float z)
        {
            var it = collectiblePool.Spawn(Collectible.PoolKey(type, pu), seg.transform, new Vector3(GameConfig.LaneX(lane), y, z));
            seg.Track(it);
            return it;
        }

        void GenerateRow(TrackSegment seg, float z)
        {
            float d = Difficulty;
            prevSafe = safeLane;
            safeLane = Mathf.Clamp(safeLane + Random.Range(-1, 2), 0, 2);
            var set = Sets[(int)seg.biome];
            Requirement safeReq = Requirement.ChangeLane; // ChangeLane here means "nothing in the safe lane"
            bool safeHasHazard = false;

            if (SpawnHazards)
            {
                for (int lane = 0; lane < 3; lane++)
                {
                    if (lane == safeLane)
                    {
                        if (Random.value < 0.25f + 0.35f * d)
                        {
                            var k = Pick(set[1]);
                            SpawnObstacle(seg, k, lane, z);
                            safeReq = GameConfig.RequirementOf(k);
                            safeHasHazard = true;
                        }
                    }
                    else if (Random.value < 0.45f + 0.4f * d)
                    {
                        var k = Random.value < 0.72f ? Pick(set[0]) : Pick(set[1]);
                        SpawnObstacle(seg, k, lane, z);
                    }
                }
            }

            // coin trail along the safe path (arcs over jump hazards, low under slide hazards)
            float mid = (lastRowZ + z) * 0.5f;
            bool trail = Random.value < 0.8f;
            bool powerUp = rowsSincePowerUp >= 3 && Random.value < 0.12f;
            float powerZ = mid + 1f;
            rowsSincePowerUp++;
            if (powerUp)
            {
                rowsSincePowerUp = 0;
                SpawnCollectible(seg, CollectibleType.PowerUp, (PowerUpType)Random.Range(0, 6), safeLane, 1.1f, powerZ);
            }
            if (trail)
            {
                for (float cz = lastRowZ + 4.5f; cz <= z + 4f; cz += 2.2f)
                {
                    if (powerUp && Mathf.Abs(cz - powerZ) < 1.6f) continue;
                    int lane = cz < mid ? prevSafe : safeLane;
                    float y = 0.85f;
                    float rel = cz - z;
                    if (lane == safeLane && safeHasHazard && Mathf.Abs(rel) < 3.6f)
                    {
                        if (safeReq == Requirement.Jump) { float u = rel / 3.6f; y = 0.7f + 2.1f * (1f - u * u); }
                        else if (safeReq == Requirement.Slide) y = 0.45f;
                    }
                    SpawnCollectible(seg, CollectibleType.Coin, PowerUpType.CoinMagnet, lane, y, cz);
                }
            }

            // treasure placed just beyond the row, outside the coin lane
            int otherLane = (safeLane + Random.Range(1, 3)) % 3;
            float tz = z + 6.5f;
            float r = Random.value;
            float chestChance = seg.biome == Biome.TreasureChamber ? 0.12f : 0.035f;
            if (r < 0.012f) SpawnCollectible(seg, CollectibleType.Artifact, 0, otherLane, 1.1f, tz);
            else if (r < 0.012f + chestChance) SpawnCollectible(seg, CollectibleType.TreasureChest, 0, otherLane, 0.75f, tz);
            else if (r < 0.06f + chestChance) SpawnCollectible(seg, CollectibleType.AncientKey, 0, otherLane, 1.1f, tz);
            else if (r < 0.10f + chestChance) SpawnCollectible(seg, CollectibleType.HiddenRelic, 0, otherLane, 1.2f, tz);
            else if (r < 0.32f + chestChance)
                SpawnCollectible(seg, Random.value < 0.65f ? CollectibleType.BlueCrystal : CollectibleType.PurpleGem, 0, otherLane, 1f, tz);
        }

        static ObstacleKind Pick(ObstacleKind[] arr) { return arr[Random.Range(0, arr.Length)]; }

        /// <summary>Used by revive: disarms and hides every obstacle in [fromZ, toZ].</summary>
        public void ClearObstaclesBetween(float fromZ, float toZ)
        {
            for (int s = 0; s < active.Count; s++)
            {
                var list = active[s].spawned;
                for (int i = 0; i < list.Count; i++)
                {
                    var it = list[i];
                    if (it == null || !it.inUse) continue;
                    float z = it.transform.position.z;
                    if (z < fromZ || z > toZ) continue;
                    var o = it.GetComponent<Obstacle>();
                    if (o != null) o.Smash(false);
                }
            }
        }

        /// <summary>Test helper: spawns an obstacle at an exact position on the segment containing z.</summary>
        public Obstacle TestSpawnObstacle(ObstacleKind kind, int lane, float z)
        {
            var seg = SegmentAt(z);
            if (seg == null) return null;
            return SpawnObstacle(seg, kind, lane, z).GetComponent<Obstacle>();
        }

        public Collectible TestSpawnCollectible(CollectibleType type, PowerUpType pu, int lane, float y, float z)
        {
            var seg = SegmentAt(z);
            if (seg == null) return null;
            return SpawnCollectible(seg, type, pu, lane, y, z).GetComponent<Collectible>();
        }
    }
}
