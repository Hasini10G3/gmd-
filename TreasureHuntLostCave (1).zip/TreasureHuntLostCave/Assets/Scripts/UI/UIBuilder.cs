using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace TreasureHunt
{
    /// <summary>Helpers that build the cave-themed uGUI (dark stone panels, crystal-glow borders, gold text) from code.</summary>
    public static class UIBuilder
    {
        public static readonly Color Stone = new Color(0.12f, 0.11f, 0.13f, 0.93f);
        public static readonly Color StoneLight = new Color(0.2f, 0.18f, 0.2f, 0.95f);
        public static readonly Color GoldText = new Color(1f, 0.82f, 0.36f);
        public static readonly Color Crystal = new Color(0.3f, 0.85f, 1f, 0.85f);
        public static readonly Color GreenBtn = new Color(0.25f, 0.6f, 0.22f);
        public static readonly Color BlueBtn = new Color(0.2f, 0.4f, 0.75f);
        public static readonly Color OrangeBtn = new Color(0.85f, 0.42f, 0.12f);
        public static readonly Color GoldBtn = new Color(0.78f, 0.55f, 0.12f);

        static Sprite rounded, circle;

        public static Sprite Rounded
        {
            get { if (rounded == null) rounded = MakeSprite(64, 20, true); return rounded; }
        }

        public static Sprite Circle
        {
            get { if (circle == null) circle = MakeSprite(64, 32, false); return circle; }
        }

        static Sprite MakeSprite(int size, int radius, bool sliced)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            var px = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float cx = Mathf.Clamp(x + 0.5f, radius, size - radius);
                    float cy = Mathf.Clamp(y + 0.5f, radius, size - radius);
                    float d = Mathf.Sqrt((x + 0.5f - cx) * (x + 0.5f - cx) + (y + 0.5f - cy) * (y + 0.5f - cy));
                    float a = Mathf.Clamp01(radius - d + 0.5f);
                    px[y * size + x] = new Color(1f, 1f, 1f, a);
                }
            tex.SetPixels(px);
            tex.Apply();
            var border = sliced ? new Vector4(radius + 2, radius + 2, radius + 2, radius + 2) : Vector4.zero;
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
        }

        public static RectTransform Rect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return (RectTransform)go.transform;
        }

        /// <summary>Anchored at one point with a fixed size in reference pixels.</summary>
        public static RectTransform Place(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = pivot;
            rt.anchoredPosition = pos; rt.sizeDelta = size;
            return rt;
        }

        public static RectTransform Stretch(RectTransform rt, Vector2 min, Vector2 max)
        {
            rt.anchorMin = min; rt.anchorMax = max;
            rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
            return rt;
        }

        public static Image Image(Transform parent, string name, Color c, Sprite sprite)
        {
            var rt = Rect(name, parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.color = c;
            img.sprite = sprite;
            if (sprite != null && sprite == rounded) img.type = UnityEngine.UI.Image.Type.Sliced;
            img.raycastTarget = false;
            return img;
        }

        /// <summary>Stone panel with glowing crystal frame and a thin gold edge.</summary>
        public static RectTransform Panel(Transform parent, string name, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            var frame = Image(parent, name + "_Glow", Crystal, Rounded);
            Place(frame.rectTransform, anchor, new Vector2(0.5f, 0.5f), pos, size + new Vector2(16f, 16f));
            var panel = Image(frame.transform, name, Stone, Rounded);
            Stretch(panel.rectTransform, Vector2.zero, Vector2.one);
            panel.rectTransform.offsetMin = new Vector2(8f, 8f);
            panel.rectTransform.offsetMax = new Vector2(-8f, -8f);
            var o = panel.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(0.85f, 0.65f, 0.25f, 0.9f);
            o.effectDistance = new Vector2(2f, -2f);
            panel.raycastTarget = true;
            return panel.rectTransform;
        }

        public static Text Label(Transform parent, string text, int size, Color c, TextAnchor align)
        {
            var rt = Rect("Text", parent);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = Util.UIFont;
            t.text = text;
            t.fontSize = size;
            t.color = c;
            t.alignment = align;
            t.fontStyle = FontStyle.Bold;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            var sh = rt.gameObject.AddComponent<Shadow>();
            sh.effectColor = new Color(0f, 0f, 0f, 0.8f);
            sh.effectDistance = new Vector2(2f, -3f);
            return t;
        }

        public static Text Label(Transform parent, string text, int size, Color c, TextAnchor align, Vector2 anchor, Vector2 pos, Vector2 boxSize)
        {
            var t = Label(parent, text, size, c, align);
            Place(t.rectTransform, anchor, new Vector2(0.5f, 0.5f), pos, boxSize);
            return t;
        }

        public static Button Button(Transform parent, string label, Color c, Vector2 anchor, Vector2 pos, Vector2 size, UnityAction onClick, out Text text)
        {
            var img = Image(parent, "Button_" + label, c, Rounded);
            img.raycastTarget = true;
            Place(img.rectTransform, anchor, new Vector2(0.5f, 0.5f), pos, size);
            var o = img.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(0f, 0f, 0f, 0.6f);
            o.effectDistance = new Vector2(3f, -3f);
            var b = img.gameObject.AddComponent<Button>();
            b.targetGraphic = img;
            var colors = b.colors;
            colors.highlightedColor = new Color(1.1f, 1.1f, 1.1f);
            colors.pressedColor = new Color(0.75f, 0.75f, 0.75f);
            b.colors = colors;
            b.onClick.AddListener(() =>
            {
                var au = AudioManager.Instance;
                if (au != null) au.Play(au.click, 0.7f);
            });
            if (onClick != null) b.onClick.AddListener(onClick);
            text = Label(img.transform, label, Mathf.RoundToInt(size.y * 0.42f), Color.white, TextAnchor.MiddleCenter);
            Stretch(text.rectTransform, Vector2.zero, Vector2.one);
            return b;
        }

        public static Button Button(Transform parent, string label, Color c, Vector2 anchor, Vector2 pos, Vector2 size, UnityAction onClick)
        {
            Text t;
            return Button(parent, label, c, anchor, pos, size, onClick, out t);
        }

        public static Image Icon(Transform parent, Color c, Vector2 anchor, Vector2 pos, float size)
        {
            var img = Image(parent, "Icon", c, Circle);
            Place(img.rectTransform, anchor, new Vector2(0.5f, 0.5f), pos, new Vector2(size, size));
            var o = img.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(1f, 1f, 1f, 0.5f);
            o.effectDistance = new Vector2(2f, -2f);
            return img;
        }
    }
}
