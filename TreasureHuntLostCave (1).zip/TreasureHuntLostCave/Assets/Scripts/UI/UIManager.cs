using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TreasureHunt
{
    /// <summary>Main menu, HUD, pause menu, settings, game-over screen, countdown and toasts — all built from code.</summary>
    public class UIManager : MonoBehaviour
    {
        public static UIManager Instance { get; private set; }

        Canvas canvas;
        GameObject menu, hud, pause, gameOver, settings;
        Text coinText, gemText, keyText, scoreText, distText, multText, countdownText, toastText;
        Text menuBest, menuCoins, menuGems, menuSound, pauseSound, settingsSound, settingsShake;
        Text goScore, goBest, goCoins, goGems, goDistance, goNewBest, goGemBank, reviveText;
        RectTransform titleRt;
        Button reviveButton;
        Image reviveImage;
        GameObject[] bars = new GameObject[6];
        Image[] barFills = new Image[6];
        float toastTime, countdownTime;
        int lastCoins = -1, lastGems = -1, lastKeys = -1, lastScore = -1, lastDist = -1;

        public GameObject MenuPanel { get { return menu; } }
        public GameObject HudPanel { get { return hud; } }
        public GameObject PausePanel { get { return pause; } }
        public GameObject GameOverPanel { get { return gameOver; } }

        void Awake()
        {
            Instance = this;
            Build();
        }

        void Start()
        {
            var gm = GameManager.Instance;
            gm.StateChanged += OnState;
            gm.CountdownTick += OnCountdown;
            gm.ToastRequested += OnToast;
            OnState(gm.State);
        }

        void OnDestroy()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;
            gm.StateChanged -= OnState;
            gm.CountdownTick -= OnCountdown;
            gm.ToastRequested -= OnToast;
        }

        // ------------------------------------------------------------------ construction
        void Build()
        {
            var cgo = new GameObject("UI Canvas");
            canvas = cgo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            var scaler = cgo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080f, 1920f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            cgo.AddComponent<GraphicRaycaster>();
            if (FindObjectOfType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem");
                es.AddComponent<EventSystem>();
                es.AddComponent<StandaloneInputModule>();
            }
            var root = cgo.transform;
            BuildHud(root);
            BuildMenu(root);
            BuildPause(root);
            BuildSettings(root);
            BuildGameOver(root);

            countdownText = UIBuilder.Label(root, "", 220, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.55f), Vector2.zero, new Vector2(600, 300));
            var co = countdownText.gameObject.AddComponent<Outline>();
            co.effectColor = new Color(0.3f, 0.15f, 0f, 1f); co.effectDistance = new Vector2(4, -4);
            toastText = UIBuilder.Label(root, "", 46, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.74f), Vector2.zero, new Vector2(1000, 90));
            var to = toastText.gameObject.AddComponent<Outline>();
            to.effectColor = new Color(0f, 0f, 0f, 0.9f); to.effectDistance = new Vector2(3, -3);
        }

        GameObject MakeScreen(Transform root, string name)
        {
            var rt = UIBuilder.Rect(name, root);
            UIBuilder.Stretch(rt, Vector2.zero, Vector2.one);
            return rt.gameObject;
        }

        void BuildHud(Transform root)
        {
            hud = MakeScreen(root, "HUD");
            var t = hud.transform;
            // treasure counters (top-left) — like the design sheet
            var box = UIBuilder.Panel(t, "Counters", new Vector2(0f, 1f), new Vector2(205f, -150f), new Vector2(340f, 230f));
            UIBuilder.Icon(box, new Color(1f, 0.8f, 0.25f), new Vector2(0f, 1f), new Vector2(48f, -42f), 46f);
            coinText = UIBuilder.Label(box, "0", 48, Color.white, TextAnchor.MiddleLeft, new Vector2(0f, 1f), new Vector2(190f, -42f), new Vector2(220f, 60f));
            UIBuilder.Icon(box, new Color(0.45f, 0.7f, 1f), new Vector2(0f, 1f), new Vector2(48f, -110f), 46f).rectTransform.localRotation = Quaternion.Euler(0, 0, 45);
            gemText = UIBuilder.Label(box, "0", 48, Color.white, TextAnchor.MiddleLeft, new Vector2(0f, 1f), new Vector2(190f, -110f), new Vector2(220f, 60f));
            UIBuilder.Icon(box, new Color(0.95f, 0.75f, 0.3f), new Vector2(0f, 1f), new Vector2(48f, -178f), 34f);
            keyText = UIBuilder.Label(box, "0", 48, Color.white, TextAnchor.MiddleLeft, new Vector2(0f, 1f), new Vector2(190f, -178f), new Vector2(220f, 60f));
            UIBuilder.Label(box, "COINS", 22, UIBuilder.GoldText, TextAnchor.MiddleRight, new Vector2(1f, 1f), new Vector2(-55f, -42f), new Vector2(100f, 40f));
            UIBuilder.Label(box, "GEMS", 22, UIBuilder.GoldText, TextAnchor.MiddleRight, new Vector2(1f, 1f), new Vector2(-55f, -110f), new Vector2(100f, 40f));
            UIBuilder.Label(box, "KEYS", 22, UIBuilder.GoldText, TextAnchor.MiddleRight, new Vector2(1f, 1f), new Vector2(-55f, -178f), new Vector2(100f, 40f));

            // score (top centre-right) + pause button (top-right)
            var sb = UIBuilder.Panel(t, "Score", new Vector2(1f, 1f), new Vector2(-330f, -105f), new Vector2(330f, 150f));
            UIBuilder.Label(sb, "SCORE", 24, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -24f), new Vector2(300f, 36f));
            scoreText = UIBuilder.Label(sb, "0", 56, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0f, -2f), new Vector2(320f, 70f));
            distText = UIBuilder.Label(sb, "0 m", 28, new Color(0.7f, 0.9f, 1f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0f), new Vector2(0f, 24f), new Vector2(300f, 36f));
            multText = UIBuilder.Label(sb, "x2", 44, new Color(1f, 0.9f, 0.3f), TextAnchor.MiddleCenter, new Vector2(0f, 0.5f), new Vector2(-40f, 0f), new Vector2(80f, 60f));
            UIBuilder.Button(t, "II", UIBuilder.StoneLight, new Vector2(1f, 1f), new Vector2(-85f, -95f), new Vector2(120f, 120f), () => GameManager.Instance.Pause());

            // power-up indicators (bottom-left)
            for (int i = 0; i < 6; i++)
            {
                var type = (PowerUpType)i;
                var bg = UIBuilder.Image(t, "PowerUp_" + type, new Color(0f, 0f, 0f, 0.6f), UIBuilder.Rounded);
                UIBuilder.Place(bg.rectTransform, new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(30f, 40f + i * 78f), new Vector2(420f, 66f));
                var fill = UIBuilder.Image(bg.transform, "Fill", GameConfig.PowerUpColor(type) * new Color(1f, 1f, 1f, 0.55f), null);
                fill.rectTransform.anchorMin = new Vector2(0f, 0f); fill.rectTransform.anchorMax = new Vector2(0f, 1f);
                fill.rectTransform.pivot = new Vector2(0f, 0.5f);
                fill.rectTransform.anchoredPosition = new Vector2(8f, 0f);
                fill.rectTransform.sizeDelta = new Vector2(404f, -16f);
                barFills[i] = fill;
                var lbl = UIBuilder.Label(bg.transform, GameConfig.PowerUpName(type), 30, Color.white, TextAnchor.MiddleLeft);
                UIBuilder.Stretch(lbl.rectTransform, Vector2.zero, Vector2.one);
                lbl.rectTransform.offsetMin = new Vector2(22f, 0f);
                bars[i] = bg.gameObject;
                bg.gameObject.SetActive(false);
            }
            UIBuilder.Label(t, "Swipe / Arrows: move · Up/Space: jump · Down/S: slide", 26, new Color(1f, 1f, 1f, 0.45f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0f), new Vector2(0f, 20f), new Vector2(1000f, 40f)).name = "ControlsHint";
        }

        void BuildMenu(Transform root)
        {
            menu = MakeScreen(root, "MainMenu");
            var t = menu.transform;
            var shade = UIBuilder.Image(t, "Shade", new Color(0f, 0f, 0f, 0.35f), null);
            UIBuilder.Stretch(shade.rectTransform, Vector2.zero, Vector2.one);

            var title = UIBuilder.Label(t, "TREASURE HUNT", 120, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.8f), Vector2.zero, new Vector2(1060f, 150f));
            var o = title.gameObject.AddComponent<Outline>(); o.effectColor = new Color(0.35f, 0.18f, 0.02f); o.effectDistance = new Vector2(5, -5);
            titleRt = title.rectTransform;
            var sub = UIBuilder.Label(t, "LOST CAVE", 84, new Color(0.45f, 0.9f, 1f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.8f), new Vector2(0f, -120f), new Vector2(900f, 110f));
            var so = sub.gameObject.AddComponent<Outline>(); so.effectColor = new Color(0.1f, 0.25f, 0.5f, 0.9f); so.effectDistance = new Vector2(4, -4);

            var info = UIBuilder.Panel(t, "Stats", new Vector2(0.5f, 0.56f), Vector2.zero, new Vector2(760f, 170f));
            menuBest = UIBuilder.Label(info, "BEST  0", 46, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -42f), new Vector2(700f, 60f));
            UIBuilder.Icon(info, new Color(1f, 0.8f, 0.25f), new Vector2(0.5f, 0f), new Vector2(-250f, 50f), 40f);
            menuCoins = UIBuilder.Label(info, "0", 40, Color.white, TextAnchor.MiddleLeft, new Vector2(0.5f, 0f), new Vector2(-110f, 50f), new Vector2(220f, 50f));
            UIBuilder.Icon(info, new Color(0.45f, 0.7f, 1f), new Vector2(0.5f, 0f), new Vector2(90f, 50f), 40f).rectTransform.localRotation = Quaternion.Euler(0, 0, 45);
            menuGems = UIBuilder.Label(info, "0", 40, Color.white, TextAnchor.MiddleLeft, new Vector2(0.5f, 0f), new Vector2(230f, 50f), new Vector2(220f, 50f));

            UIBuilder.Button(t, "PLAY", UIBuilder.GoldBtn, new Vector2(0.5f, 0.42f), Vector2.zero, new Vector2(560f, 150f), () => GameManager.Instance.StartRun());
            UIBuilder.Button(t, "SETTINGS", UIBuilder.BlueBtn, new Vector2(0.5f, 0.42f), new Vector2(-145f, -170f), new Vector2(270f, 105f), () => ShowSettings(true));
            Text st;
            UIBuilder.Button(t, "SOUND ON", UIBuilder.StoneLight, new Vector2(0.5f, 0.42f), new Vector2(145f, -170f), new Vector2(270f, 105f), ToggleSound, out st);
            menuSound = st;
            UIBuilder.Label(t, "Explore the ancient cave · dodge traps · collect lost treasure", 30, new Color(1f, 1f, 1f, 0.7f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0.12f), Vector2.zero, new Vector2(1040f, 50f));
        }

        void BuildPause(Transform root)
        {
            pause = MakeScreen(root, "PauseMenu");
            var t = pause.transform;
            var shade = UIBuilder.Image(t, "Shade", new Color(0f, 0f, 0f, 0.55f), null);
            shade.raycastTarget = true;
            UIBuilder.Stretch(shade.rectTransform, Vector2.zero, Vector2.one);
            var p = UIBuilder.Panel(t, "Panel", new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(640f, 760f));
            UIBuilder.Label(p, "PAUSED", 84, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -80f), new Vector2(600f, 110f));
            UIBuilder.Button(p, "RESUME", UIBuilder.GreenBtn, new Vector2(0.5f, 1f), new Vector2(0f, -210f), new Vector2(460f, 110f), () => GameManager.Instance.Resume());
            UIBuilder.Button(p, "RESTART", UIBuilder.OrangeBtn, new Vector2(0.5f, 1f), new Vector2(0f, -340f), new Vector2(460f, 110f), () => GameManager.Instance.Retry());
            UIBuilder.Button(p, "HOME", UIBuilder.BlueBtn, new Vector2(0.5f, 1f), new Vector2(0f, -470f), new Vector2(460f, 110f), () => GameManager.Instance.GoHome());
            Text st;
            UIBuilder.Button(p, "SOUND ON", UIBuilder.StoneLight, new Vector2(0.5f, 1f), new Vector2(0f, -600f), new Vector2(460f, 110f), ToggleSound, out st);
            pauseSound = st;
        }

        void BuildSettings(Transform root)
        {
            settings = MakeScreen(root, "Settings");
            var t = settings.transform;
            var shade = UIBuilder.Image(t, "Shade", new Color(0f, 0f, 0f, 0.6f), null);
            shade.raycastTarget = true;
            UIBuilder.Stretch(shade.rectTransform, Vector2.zero, Vector2.one);
            var p = UIBuilder.Panel(t, "Panel", new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(660f, 760f));
            UIBuilder.Label(p, "SETTINGS", 76, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -80f), new Vector2(600f, 100f));
            Text st;
            UIBuilder.Button(p, "SOUND ON", UIBuilder.StoneLight, new Vector2(0.5f, 1f), new Vector2(0f, -210f), new Vector2(480f, 110f), ToggleSound, out st);
            settingsSound = st;
            UIBuilder.Button(p, "SHAKE ON", UIBuilder.StoneLight, new Vector2(0.5f, 1f), new Vector2(0f, -340f), new Vector2(480f, 110f), () =>
            {
                SaveSystem.ShakeOn = !SaveSystem.ShakeOn; SaveSystem.Save(); RefreshToggles();
            }, out st);
            settingsShake = st;
            UIBuilder.Button(p, "RESET PROGRESS", new Color(0.55f, 0.15f, 0.12f), new Vector2(0.5f, 1f), new Vector2(0f, -470f), new Vector2(480f, 110f), () =>
            {
                SaveSystem.ResetProgress(); RefreshMenu(); OnToast("PROGRESS RESET", Color.white);
            });
            UIBuilder.Button(p, "BACK", UIBuilder.BlueBtn, new Vector2(0.5f, 1f), new Vector2(0f, -620f), new Vector2(480f, 110f), () => ShowSettings(false));
            settings.SetActive(false);
        }

        void BuildGameOver(Transform root)
        {
            gameOver = MakeScreen(root, "GameOver");
            var t = gameOver.transform;
            var shade = UIBuilder.Image(t, "Shade", new Color(0.05f, 0f, 0f, 0.55f), null);
            shade.raycastTarget = true;
            UIBuilder.Stretch(shade.rectTransform, Vector2.zero, Vector2.one);
            var p = UIBuilder.Panel(t, "Panel", new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(820f, 1060f));
            var title = UIBuilder.Label(p, "GAME OVER", 104, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -90f), new Vector2(780f, 130f));
            var o = title.gameObject.AddComponent<Outline>(); o.effectColor = new Color(0.35f, 0.1f, 0.02f); o.effectDistance = new Vector2(4, -4);
            UIBuilder.Label(p, "SCORE", 34, new Color(0.8f, 0.8f, 0.8f), TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -190f), new Vector2(400f, 50f));
            goScore = UIBuilder.Label(p, "0", 96, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -265f), new Vector2(700f, 110f));
            goNewBest = UIBuilder.Label(p, "NEW BEST!", 40, new Color(0.4f, 1f, 0.5f), TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -335f), new Vector2(500f, 50f));
            UIBuilder.Label(p, "BEST SCORE", 30, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -390f), new Vector2(400f, 44f));
            goBest = UIBuilder.Label(p, "0", 64, UIBuilder.GoldText, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -445f), new Vector2(600f, 80f));

            UIBuilder.Icon(p, new Color(1f, 0.8f, 0.25f), new Vector2(0.5f, 1f), new Vector2(-300f, -540f), 44f);
            goCoins = UIBuilder.Label(p, "0", 44, Color.white, TextAnchor.MiddleLeft, new Vector2(0.5f, 1f), new Vector2(-170f, -540f), new Vector2(200f, 60f));
            UIBuilder.Icon(p, new Color(0.45f, 0.7f, 1f), new Vector2(0.5f, 1f), new Vector2(-40f, -540f), 44f).rectTransform.localRotation = Quaternion.Euler(0, 0, 45);
            goGems = UIBuilder.Label(p, "0", 44, Color.white, TextAnchor.MiddleLeft, new Vector2(0.5f, 1f), new Vector2(90f, -540f), new Vector2(200f, 60f));
            goDistance = UIBuilder.Label(p, "0 m", 40, new Color(0.7f, 0.9f, 1f), TextAnchor.MiddleRight, new Vector2(0.5f, 1f), new Vector2(250f, -540f), new Vector2(200f, 60f));

            reviveButton = UIBuilder.Button(p, "REVIVE", UIBuilder.GreenBtn, new Vector2(0.5f, 1f), new Vector2(0f, -660f), new Vector2(600f, 120f), OnRevive, out reviveText);
            reviveImage = reviveButton.GetComponent<Image>();
            goGemBank = UIBuilder.Label(p, "", 28, new Color(0.75f, 0.85f, 1f), TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -740f), new Vector2(700f, 40f));
            UIBuilder.Button(p, "HOME", UIBuilder.BlueBtn, new Vector2(0.5f, 1f), new Vector2(-155f, -860f), new Vector2(290f, 120f), () => GameManager.Instance.GoHome());
            UIBuilder.Button(p, "RETRY", UIBuilder.OrangeBtn, new Vector2(0.5f, 1f), new Vector2(155f, -860f), new Vector2(290f, 120f), () => GameManager.Instance.Retry());
        }

        // ------------------------------------------------------------------ behaviour
        void ToggleSound()
        {
            if (AudioManager.Instance != null) AudioManager.Instance.ToggleSound();
            else { SaveSystem.SoundOn = !SaveSystem.SoundOn; SaveSystem.Save(); }
            RefreshToggles();
        }

        void RefreshToggles()
        {
            string s = SaveSystem.SoundOn ? "SOUND ON" : "SOUND OFF";
            if (menuSound != null) menuSound.text = s;
            if (pauseSound != null) pauseSound.text = s;
            if (settingsSound != null) settingsSound.text = s;
            if (settingsShake != null) settingsShake.text = SaveSystem.ShakeOn ? "SHAKE ON" : "SHAKE OFF";
        }

        void ShowSettings(bool show)
        {
            settings.SetActive(show);
            RefreshToggles();
        }

        void RefreshMenu()
        {
            menuBest.text = "BEST  " + SaveSystem.BestScore.ToString("N0");
            menuCoins.text = SaveSystem.Coins.ToString("N0");
            menuGems.text = SaveSystem.Gems.ToString("N0");
        }

        void OnRevive()
        {
            var gm = GameManager.Instance;
            if (!gm.Revive()) OnToast("NOT ENOUGH GEMS", new Color(1f, 0.5f, 0.4f));
        }

        void OnState(GameState s)
        {
            menu.SetActive(s == GameState.Menu);
            hud.SetActive(s == GameState.Playing || s == GameState.Countdown || s == GameState.Paused || s == GameState.Dying);
            pause.SetActive(s == GameState.Paused);
            gameOver.SetActive(s == GameState.GameOver);
            if (s != GameState.Menu) settings.SetActive(false);
            if (s != GameState.Countdown) { countdownText.text = ""; }
            RefreshToggles();
            if (s == GameState.Menu) RefreshMenu();
            if (s == GameState.GameOver) RefreshGameOver();
            lastCoins = lastGems = lastKeys = lastScore = lastDist = -1;
        }

        void RefreshGameOver()
        {
            var gm = GameManager.Instance;
            goScore.text = gm.ScoreInt.ToString("N0");
            goBest.text = SaveSystem.BestScore.ToString("N0");
            goNewBest.gameObject.SetActive(gm.NewBest);
            goCoins.text = gm.RunCoins.ToString();
            goGems.text = gm.RunGems.ToString();
            goDistance.text = Mathf.FloorToInt(gm.Distance) + " m";
            bool can = gm.CanRevive;
            reviveText.text = "REVIVE  (" + gm.ReviveCost + " GEMS)";
            reviveButton.interactable = can;
            reviveImage.color = can ? UIBuilder.GreenBtn : new Color(0.3f, 0.32f, 0.3f);
            goGemBank.text = "You have " + SaveSystem.Gems + " gems" + (can ? "" : " — collect more crystals to revive");
        }

        void OnCountdown(int n)
        {
            countdownText.text = n > 0 ? n.ToString() : "GO!";
            countdownTime = 0f;
            if (n == 0) countdownTime = -0.6f;
        }

        void OnToast(string msg, Color c)
        {
            toastText.text = msg;
            toastText.color = c;
            toastTime = 2.2f;
        }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;
            float dt = Time.unscaledDeltaTime;

            if (toastTime > 0f)
            {
                toastTime -= dt;
                var c = toastText.color; c.a = Mathf.Clamp01(toastTime / 0.4f); toastText.color = c;
                toastText.rectTransform.localScale = Vector3.one * (1f + Mathf.Max(0f, toastTime - 1.9f) * 0.8f);
                if (toastTime <= 0f) toastText.text = "";
            }
            if (countdownTime < 0f)
            {
                countdownTime += dt;
                if (countdownTime >= 0f && gm.State != GameState.Countdown) countdownText.text = "";
            }
            if (countdownText.text.Length > 0)
                countdownText.rectTransform.localScale = Vector3.one * (1f + 0.15f * Mathf.Sin(Time.unscaledTime * 10f));

            if (gm.State == GameState.Menu && titleRt != null)
                titleRt.localScale = Vector3.one * (1f + 0.03f * Mathf.Sin(Time.unscaledTime * 2f));

            if (!hud.activeSelf) return;
            if (gm.RunCoins != lastCoins) { lastCoins = gm.RunCoins; coinText.text = lastCoins.ToString(); }
            if (gm.RunGems != lastGems) { lastGems = gm.RunGems; gemText.text = lastGems.ToString(); }
            if (gm.RunKeys != lastKeys) { lastKeys = gm.RunKeys; keyText.text = lastKeys.ToString(); }
            int sc = gm.ScoreInt;
            if (sc != lastScore) { lastScore = sc; scoreText.text = sc.ToString("N0"); }
            int di = Mathf.FloorToInt(gm.Distance);
            if (di != lastDist) { lastDist = di; distText.text = di + " m"; }

            var pu = PowerUpManager.Instance;
            if (pu == null) return;
            multText.gameObject.SetActive(pu.IsActive(PowerUpType.ScoreMultiplier));
            int slot = 0;
            for (int i = 0; i < 6; i++)
            {
                var type = (PowerUpType)i;
                bool on = pu.IsActive(type);
                if (bars[i].activeSelf != on) bars[i].SetActive(on);
                if (!on) continue;
                ((RectTransform)bars[i].transform).anchoredPosition = new Vector2(30f, 70f + slot * 78f);
                barFills[i].rectTransform.sizeDelta = new Vector2(404f * pu.Normalized(type), -16f);
                slot++;
            }
        }
    }
}
