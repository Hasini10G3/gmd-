using UnityEngine;

namespace TreasureHunt
{
    /// <summary>On-player feedback: shield bubble, magnet ring, multiplier sparkles, speed lines.</summary>
    public class PowerUpVisuals : MonoBehaviour
    {
        GameObject shield, magnetRing;
        Transform magnetSpin;
        float sparkleTimer;

        public void Build()
        {
            shield = Util.Prim(PrimitiveType.Sphere, transform, new Vector3(0, 1f, 0), new Vector3(1.9f, 2.3f, 1.9f), MaterialLibrary.Get(Mat.Shield));
            shield.name = "ShieldBubble";
            shield.SetActive(false);
            magnetRing = Util.Node("MagnetRing", transform, new Vector3(0, 0.05f, 0));
            magnetSpin = magnetRing.transform;
            for (int i = 0; i < 8; i++)
            {
                float a = i * 45f * Mathf.Deg2Rad;
                Util.Prim(PrimitiveType.Cube, magnetSpin, new Vector3(Mathf.Cos(a) * 1.1f, 0, Mathf.Sin(a) * 1.1f), new Vector3(0.35f, 0.04f, 0.12f),
                    MaterialLibrary.Get(i % 2 == 0 ? Mat.PowerMagnet : Mat.Silver), new Vector3(0, -i * 45f + 90f, 0));
            }
            magnetRing.SetActive(false);
        }

        void Update()
        {
            var pu = PowerUpManager.Instance;
            if (pu == null || shield == null) return;
            float t = Time.time;
            bool sh = pu.IsActive(PowerUpType.CrystalShield);
            if (shield.activeSelf != sh) shield.SetActive(sh);
            if (sh)
            {
                bool expiring = pu.Remaining(PowerUpType.CrystalShield) < 2.5f;
                float s = 1f + 0.05f * Mathf.Sin(t * 6f);
                shield.transform.localScale = new Vector3(1.9f * s, 2.3f * s, 1.9f * s);
                if (expiring) shield.SetActive(Mathf.Repeat(t * 6f, 1f) > 0.35f);
            }
            bool mg = pu.IsActive(PowerUpType.CoinMagnet);
            if (magnetRing.activeSelf != mg) magnetRing.SetActive(mg);
            if (mg) magnetSpin.Rotate(0f, 240f * Time.deltaTime, 0f);

            var fx = FXManager.Instance;
            if (fx == null) return;
            fx.SetSpeedLines(pu.IsActive(PowerUpType.SpeedBoost));
            if (pu.IsActive(PowerUpType.ScoreMultiplier) || pu.IsActive(PowerUpType.AncientVision))
            {
                sparkleTimer -= Time.deltaTime;
                if (sparkleTimer <= 0f)
                {
                    sparkleTimer = 0.12f;
                    Color c = pu.IsActive(PowerUpType.ScoreMultiplier) ? new Color(1f, 0.9f, 0.3f) : new Color(0.4f, 1f, 0.6f);
                    fx.Sparkle(transform.position + new Vector3(Random.Range(-0.6f, 0.6f), Random.Range(0.4f, 2f), Random.Range(-0.3f, 0.6f)), c, 2);
                }
            }
        }
    }
}
