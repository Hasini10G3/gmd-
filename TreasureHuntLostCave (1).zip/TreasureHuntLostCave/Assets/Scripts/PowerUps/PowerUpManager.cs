using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Timers for the six power-ups: activation, duration, expiration events.</summary>
    public class PowerUpManager : MonoBehaviour
    {
        public static PowerUpManager Instance { get; private set; }

        readonly float[] remaining = new float[6];
        public event System.Action<PowerUpType> Activated;
        public event System.Action<PowerUpType> Expired;
        public int ActivationCount { get; private set; }
        public int ExpirationCount { get; private set; }

        public const int TreasureBonusCoins = 50, TreasureBonusGems = 5;

        void Awake() { Instance = this; }

        public bool IsActive(PowerUpType t) { return remaining[(int)t] > 0f; }
        public float Remaining(PowerUpType t) { return remaining[(int)t]; }
        public float Duration(PowerUpType t) { return GameConfig.PowerUpDurations[(int)t] * GameConfig.DurationScale; }
        public float Normalized(PowerUpType t) { float d = Duration(t); return d <= 0f ? 0f : Mathf.Clamp01(remaining[(int)t] / d); }

        public float SpeedFactor { get { return IsActive(PowerUpType.SpeedBoost) ? GameConfig.SpeedBoostMultiplier : 1f; } }
        public float ScoreFactor { get { return IsActive(PowerUpType.ScoreMultiplier) ? 2f : 1f; } }

        public void Activate(PowerUpType t)
        {
            remaining[(int)t] = Duration(t);
            ActivationCount++;
            var gm = GameManager.Instance;
            if (t == PowerUpType.TreasureBonus && gm != null)
            {
                gm.AddCoins(TreasureBonusCoins);
                gm.AddGems(TreasureBonusGems);
                gm.AddScore(300);
            }
            if (AudioManager.Instance != null) AudioManager.Instance.Play(AudioManager.Instance.powerUp, 0.8f);
            if (gm != null)
            {
                string msg = t == PowerUpType.TreasureBonus
                    ? "TREASURE BONUS!  +" + TreasureBonusCoins + " COINS  +" + TreasureBonusGems + " GEMS"
                    : GameConfig.PowerUpName(t) + "!";
                gm.ShowToast(msg, GameConfig.PowerUpColor(t));
            }
            if (Activated != null) Activated(t);
        }

        public void ConsumeShield()
        {
            if (!IsActive(PowerUpType.CrystalShield)) return;
            remaining[(int)PowerUpType.CrystalShield] = 0f;
            ExpirationCount++;
            if (Expired != null) Expired(PowerUpType.CrystalShield);
        }

        public void ClearAll()
        {
            for (int i = 0; i < remaining.Length; i++) remaining[i] = 0f;
        }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.State != GameState.Playing) return;
            float dt = Time.deltaTime;
            for (int i = 0; i < remaining.Length; i++)
            {
                if (remaining[i] <= 0f) continue;
                remaining[i] -= dt;
                if (remaining[i] <= 0f)
                {
                    remaining[i] = 0f;
                    ExpirationCount++;
                    if (Expired != null) Expired((PowerUpType)i);
                }
            }
        }
    }
}
