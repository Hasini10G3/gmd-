Materials are exported to Materials/Resources/TH by the builder (loaded at runtime so Android builds include the right shader variants).
