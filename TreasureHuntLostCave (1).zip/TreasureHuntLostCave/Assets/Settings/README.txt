TreasureHuntGenerated.txt is written here after the first generation; delete it to force regeneration on next open.
